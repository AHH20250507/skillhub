<#
  One-shot: output a JS snippet to paste into the Skill Hub browser console.
  Usage: cd "D:/桌面/skill hub" ; powershell -File ./apply-config.ps1
#>
$ErrorActionPreference = 'Stop'

$repo   = (git config --local --get skill-hub.repo)
$branch = (git config --local --get skill-hub.branch)
$root   = (git config --local --get skill-hub.root)
$token  = (git config --local --get skill-hub.token)

if (-not $token) {
  Write-Host "[!] token not found. run: git config --local skill-hub.token YOUR_TOKEN" -ForegroundColor Yellow
  exit 1
}

$cfg = @{
  repo   = $repo
  branch = $branch
  root   = $root
  token  = $token
} | ConvertTo-Json -Compress

$js = "localStorage.setItem('skill_hub_cfg_v1', $(ConvertTo-Json $cfg)); location.reload();"

Write-Host ""
Write-Host "===== COPY THE LINE BELOW INTO BROWSER F12 CONSOLE =====" -ForegroundColor Cyan
Write-Host ""
Write-Host $js
Write-Host ""
Write-Host "=========================================================" -ForegroundColor Cyan
Write-Host "after paste+enter, page reloads and shows [connected $repo] badge." -ForegroundColor Green
