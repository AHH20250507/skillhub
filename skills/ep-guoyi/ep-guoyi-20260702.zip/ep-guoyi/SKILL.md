---
name: ep-guoyi
description: "Generate \"过壹招\" promotional HTML section for WeChat Official Account. Use when user provides phone recycling prices and asks to create the formatted HTML with phone trade-in calculation. Handles Excel file parsing, precise phone model matching, cross-sheet lookup, and standardized table styling."
---

# WeChat Article Curator

Create professional WeChat Official Account "过壹招" promotional section with phone trade-in information.

## CRITICAL RULES (MUST FOLLOW)

### 1. Excel File Parsing Rules

When user provides an Excel file path:

**Multi-Sheet Handling:**
- Excel files may contain multiple sheets (e.g., "苹果手机", "安卓手机")
- ALWAYS check all sheets for the requested phone models
- iPhone data is typically in "苹果手机" sheet
- Android phones (华为, 小米, OPPO, vivo, etc.) are typically in "安卓手机" sheet

**Precise Model Matching:**
- Use EXACT match (`==`) NOT substring match (`contains`)
- WRONG: `df[df["机型"].str.contains("iPhone 16 Pro", na=False)]` - This matches both "iPhone 16 Pro" and "iPhone 16 Pro Max"
- CORRECT: `df[df["机型"] == "iPhone 16 Pro"]` - This matches only exact model

**Column Names by Sheet:**
- 苹果手机 sheet: `["detailId", "品牌", "机型", "苹果小型号", "ROM", "购买渠道", "手机颜色", "回收价", "上市时间"]`
- 安卓手机 sheet: `["detailId", "品牌", "机型", "型号（副名称）", "ROM", "RAM", "购买渠道", "手机颜色", "网络制式", "靓机价格", "上市时间"]`
- Note: iPhone uses `回收价` column, Android uses `靓机价格` column

### 2. Trade-in Calculation Rules

**Old Phone Selection:**
- Use the FIRST iPhone model from user's list as the old phone (trade-in)
- If first model is "iPhone XX Pro", old phone = "iPhone XX Pro"
- If first model is "iPhone XX Pro Max", old phone = "iPhone XX Pro Max"

**New Phone Selection:**
- Find the LATEST iPhone model in the Excel file
- If old phone is "Pro" version, new phone = latest "Pro" version
- If old phone is "Pro Max" version, new phone = latest "Pro Max" version
- Examples:
  - Old: iPhone 16 Pro → New: iPhone 17 Pro
  - Old: iPhone 14 Pro Max → New: iPhone 17 Pro Max

**New Phone Price:**
- iPhone Pro 256GB: 8999元
- iPhone Pro Max 256GB: 9999元

### 3. Table Image Generation Specification

**CRITICAL: Generate price table as IMAGE, not HTML table**

The price table must be generated as an image file and uploaded to catbox.moe or litterbox.catbox.moe, then referenced via `<img>` tag in HTML. If upload fails, use base64 data URI as fallback.

**Color Scheme:**
- Header background: `#4a9c5e` (RGB: 74, 156, 94)
- Bottom bar background: `#4a9c5e`
- Button background: `#ffffff` (white)
- Button text color: `#4a9c5e`
- Table borders: `#e8e8e8`
- Content background: `#ffffff` (white)
- Text color: `#333333`

**Image Structure:**
1. **Header Row**: Green background (#4a9c5e), two columns with white text
   - Left: "热门回收机型"
   - Right: "回收最高价/元"
   - Vertical divider in header

2. **Data Rows**: White background, centered text
   - Each phone model and price in separate row
   - Horizontal divider lines (#e8e8e8)
   - Vertical divider between columns

3. **Bottom Bar**: Green background (#4a9c5e)
   - Left text: "更多回收机型" (white)
   - Right button: White rounded rectangle with "点击去询价" text in green
   - Button must include TWO small right-pointing triangles (arrows) drawn using polygon

**Arrow Drawing (CRITICAL - do NOT use Unicode characters):**
```python
# Draw two small triangles as arrows using polygon
triangle_size = 6
triangle_y = button_y + button_padding_y + 3
triangle_x1 = button_x + button_width - 18
triangle_x2 = triangle_x1 + 5

# First triangle
draw.polygon([(triangle_x1, triangle_y),
              (triangle_x1, triangle_y + triangle_size),
              (triangle_x1 + triangle_size * 0.6, triangle_y + triangle_size / 2)],
             fill=header_color)

# Second triangle
draw.polygon([(triangle_x2, triangle_y),
              (triangle_x2, triangle_y + triangle_size),
              (triangle_x2 + triangle_size * 0.6, triangle_y + triangle_size / 2)],
             fill=header_color)
```

**Image Upload:**
1. First try `https://litterbox.catbox.moe/resources/internals/api.php` with `reqtype=fileupload` and `time=1h`
2. If that fails, try `https://catbox.moe/user/api.php`
3. If both fail, embed image as base64 data URI in HTML

**HTML Output:**
```html
<!-- 价格表格图片 -->
<img src="{IMAGE_URL}" alt="手机回收价格表" style="width: 100%; max-width: 100%; display: block; margin-top: 15px;">
```

## "过壹招" Section - Fixed Layout Specification

### Input Data Required
- **Phone List**: List of phones with prices (e.g., "iPhone 16 Pro:5220;iPhone 15 Pro:3817;...")
- **Trade-in Info**:
  - 旧手机型号 (old phone model) - Use first iPhone from list
  - 旧机回收价 (old phone price)
  - 新手机型号 (new phone model) - Use latest iPhone matching Pro/Pro Max pattern
  - 存储容量 (storage capacity) - 256GB
  - 新机价格 (new phone price) - 8999 for Pro, 9999 for Pro Max
- **Date**: Quote date (YYYY/MM/DD format)

### Output HTML Structure

```html
<!-- 过壹招部分 -->
<div style="margin-top: 40px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'PingFang SC', 'Hiragino Sans GB', 'Microsoft YaHei', sans-serif; line-height: 1.8; color: #333; padding: 0 8px;">

    <!-- 绿色头部横幅 -->
    <div style="background: #07c160; padding: 12px 20px; border-radius: 8px;">
        <span style="font-size: 18px; color: #fff; font-weight: bold; letter-spacing: 4px;">￥「 过 壹 招 」</span>
    </div>

    <!-- 每周更新市场报价 -->
    <div style="font-size: 14px; color: #666; text-align: center; margin-top: 15px;">每周更新市场报价（{DATE}）</div>

    <!-- 价格表格图片 -->
    <img src="{IMAGE_URL}" alt="手机回收价格表" style="width: 100%; max-width: 100%; display: block; margin-top: 15px;">

    <!-- 注释说明 -->
    <div style="font-size: 12px; color: #999; line-height: 1.6; margin-top: 10px;">
        *注：最高回收价为手机无任何瑕疵及功能问题时的价格，最终回收价请以EPBox对手机检测的实际结果为准。回收市场的价格天天波动，尽早回收，避免手机越来越贬值哦~
    </div>

    <!-- 过招计算 -->
    <div style="font-size: 15px; color: #333; line-height: 1.8; margin-top: 15px;">
        <span style="color: #333;">过招：现使用</span><span style="color: #07c160;">{旧手机型号}</span><span style="color: #333;">的用户，通过以旧换新购买</span><span style="color: #07c160;">{新手机型号} {存储容量}</span><span style="color: #333;">最低支付</span><span style="color: #07c160;">{新机价格} - {旧机回收价}*（1+10%）={最终支付金额}元，折抵比例超过{折抵比例}%。</span><br><span style="color: #333; font-weight: bold;">购新机，无压力！</span>
    </div>

</div>
```

### Key Layout Requirements (MUST FOLLOW)

1. **Green Header Banner**
   - Background: `#07c160`
   - Text: `￥「 过 壹 招 」` (white, 18px, bold, letter-spacing: 4px)
   - Left-aligned, border-radius: 8px

2. **Date Line**
   - Center-aligned
   - Text: `每周更新市场报价（YYYY/MM/DD）`
   - Color: `#666`, 14px
   - margin-top: 15px

3. **Price Table**
   - MUST generate as IMAGE, not HTML table
   - Generate using Python PIL/Pillow with exact color specifications
   - Upload to catbox.moe or litterbox.catbox.moe and use `<img>` tag
   - If upload fails, use base64 data URI
   - Header background: `#4a9c5e`
   - Bottom bar background: `#4a9c5e`
   - Table borders: `#e8e8e8`
   - White background for content rows
   - "点击去询价" button with two triangle arrows (drawn using polygon, NOT Unicode)

4. **Note Text**
   - margin-top: 10px
   - Font: 12px, color: #999
   - Full disclaimer text

5. **Calculation Text**
   - Black text: `过招：现使用`、`的用户，通过以旧换新购买`、`最低支付`
   - Green text: phone models, prices, calculation result, percentage
   - "购新机，无压力！" - black, bold, no space before it

6. **Container**
   - padding: 0 8px (8px side margins)
   - margin-top: 40px

### Calculation Formula

```
最终支付金额 = 新机价格 - 旧机回收价 × 1.1
折抵比例 = (旧机回收价 × 1.1) / 新机价格 × 100%
```

### Example Output

For input:
- Phones: iPhone 16 Pro:5220, iPhone 15 Pro:3817, iPhone 14 Pro Max:3417, Pura 80 Pro:2249, 小米 15 Pro:1887
- First iPhone: iPhone 16 Pro (this becomes old phone)
- Latest iPhone in file: iPhone 17 Pro and iPhone 17 Pro Max
- Since old is "Pro", new = iPhone 17 Pro 256GB
- New price: 8999
- Date: 2025/05/15

Output:
- 旧手机型号: iPhone 16 Pro
- 旧机回收价: 5220
- 新手机型号: iPhone 17 Pro
- 存储容量: 256GB
- 新机价格: 8999
- 最终支付金额 = 8999 - 5220*1.1 = 3257
- 折抵比例 = (5220*1.1)/8999*100% ≈ 63%
