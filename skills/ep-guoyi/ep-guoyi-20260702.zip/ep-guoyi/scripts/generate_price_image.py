#!/usr/bin/env python3
"""
Generate phone price table image and upload to catbox.moe
Usage: python generate_price_image.py "iPhone 16:3708,iPhone 15:3200" "2026/2/27"
"""

import sys
import io
import base64
import requests
from PIL import Image, ImageDraw, ImageFont

def create_price_image(phone_data, date):
    """
    Create a phone price table image
    phone_data: list of tuples [(phone_name, price), ...]
    date: str, e.g., "2026/2/27"
    """
    # Image dimensions
    width = 800
    row_height = 80
    header_height = 100
    footer_height = 60
    padding = 30

    # Calculate total height
    total_height = header_height + len(phone_data) * row_height + footer_height

    # Create image with white background
    img = Image.new('RGB', (width, total_height), color='#FFFFFF')
    draw = ImageDraw.Draw(img)

    # Try to load fonts (fallback to default if not available)
    try:
        title_font = ImageFont.truetype("msyh.ttc", 36)
        header_font = ImageFont.truetype("msyh.ttc", 28)
        price_font = ImageFont.truetype("msyhbd.ttc", 32)
        note_font = ImageFont.truetype("msyh.ttc", 20)
    except:
        title_font = ImageFont.load_default()
        header_font = ImageFont.load_default()
        price_font = ImageFont.load_default()
        note_font = ImageFont.load_default()

    # Colors
    header_bg = '#1A1A1A'
    text_dark = '#333333'
    text_red = '#E53935'
    border_color = '#E0E0E0'

    # Draw header background
    draw.rectangle([0, 0, width, header_height], fill=header_bg)

    # Draw header text
    title_text = "「 过 壹 招 」每周市场报价"
    bbox = draw.textbbox((0, 0), title_text, font=title_font)
    text_width = bbox[2] - bbox[0]
    draw.text(((width - text_width) // 2, 30), title_text, font=title_font, fill='#FFFFFF')

    # Draw date
    date_text = f"({date})"
    bbox = draw.textbbox((0, 0), date_text, font=note_font)
    text_width = bbox[2] - bbox[0]
    draw.text(((width - text_width) // 2, 75), date_text, font=note_font, fill='#CCCCCC')

    # Draw table rows
    y = header_height
    for i, (phone_name, price) in enumerate(phone_data):
        draw.line([(padding, y), (width - padding, y)], fill=border_color, width=1)
        draw.text((padding + 20, y + 25), phone_name, font=header_font, fill=text_dark)
        price_text = f"¥{price}"
        bbox = draw.textbbox((0, 0), price_text, font=price_font)
        text_width = bbox[2] - bbox[0]
        draw.text((width - padding - 20 - text_width, y + 22), price_text, font=price_font, fill=text_red)
        y += row_height

    # Draw bottom border
    draw.line([(padding, y), (width - padding, y)], fill=border_color, width=1)

    # Draw footer note
    note_text = "*价格仅供参考，以实际检测为准"
    bbox = draw.textbbox((0, 0), note_text, font=note_font)
    text_width = bbox[2] - bbox[0]
    draw.text(((width - text_width) // 2, y + 20), note_text, font=note_font, fill='#999999')

    return img

def upload_to_catbox(image):
    """Upload image to catbox.moe and return URL"""
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='PNG')
    img_byte_arr.seek(0)

    # Try litterbox first
    url = "https://litterbox.catbox.moe/resources/internals/api.php"
    files = {'fileToUpload': ('price_table.png', img_byte_arr, 'image/png')}
    data = {'reqtype': 'fileupload', 'time': '1h'}

    try:
        response = requests.post(url, files=files, data=data, timeout=30)
        if response.status_code == 200:
            return response.text.strip()
    except Exception as e:
        print(f"Litterbox upload error: {e}", file=sys.stderr)

    # Fallback to catbox
    img_byte_arr.seek(0)
    url = "https://catbox.moe/user/api.php"
    files = {'fileToUpload': ('price_table.png', img_byte_arr, 'image/png')}
    data = {'reqtype': 'fileupload'}

    try:
        response = requests.post(url, files=files, data=data, timeout=30)
        if response.status_code == 200:
            return response.text.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}", file=sys.stderr)

    return None

def main():
    if len(sys.argv) < 3:
        print("Usage: python generate_price_image.py 'iPhone 16:3708,iPhone 15:3200' '2026/2/27'")
        sys.exit(1)

    phone_str = sys.argv[1]
    date = sys.argv[2]

    phone_data = []
    for item in phone_str.split(','):
        parts = item.split(':')
        if len(parts) == 2:
            phone_data.append((parts[0].strip(), parts[1].strip()))

    img = create_price_image(phone_data, date)
    image_url = upload_to_catbox(img)

    if image_url:
        print(image_url)
    else:
        buffer = io.BytesIO()
        img.save(buffer, format='PNG')
        img_base64 = base64.b64encode(buffer.getvalue()).decode()
        print(f"data:image/png;base64,{img_base64}")

if __name__ == "__main__":
    main()
