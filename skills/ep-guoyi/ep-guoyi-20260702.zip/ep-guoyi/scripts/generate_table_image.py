#!/usr/bin/env python3
"""
Generate phone price table image with uniform background
Usage: python generate_table_image.py "iPhone 16:3708,iPhone 15 Plus:2717,..."
"""

import sys
import io
import requests
from PIL import Image, ImageDraw, ImageFont

def create_table_image(phone_data):
    """
    Create a phone price table image with uniform light green background
    phone_data: list of tuples [(phone_name, price), ...]
    """
    width = 700
    header_height = 45
    row_height = 42

    total_height = header_height + (len(phone_data) + 1) * row_height

    bg_color = (184, 230, 211)
    border_color = (129, 199, 132)
    text_color = (51, 51, 51)

    img = Image.new('RGB', (width, total_height), color=bg_color)
    draw = ImageDraw.Draw(img)

    try:
        font = ImageFont.truetype("msyh.ttc", 20)
        header_font = ImageFont.truetype("msyh.ttc", 20)
    except:
        font = ImageFont.load_default()
        header_font = ImageFont.load_default()

    col1_width = width // 2
    col2_width = width // 2

    # Draw header row
    y = 0
    draw.rectangle([0, y, width, y + header_height], fill=bg_color, outline=border_color, width=1)

    bbox = draw.textbbox((0, 0), "热门回收机型", font=header_font)
    text_width = bbox[2] - bbox[0]
    draw.text(((col1_width - text_width) // 2, y + 10), "热门回收机型", font=header_font, fill=text_color)

    bbox = draw.textbbox((0, 0), "回收最高价/元", font=header_font)
    text_width = bbox[2] - bbox[0]
    draw.text((col1_width + (col2_width - text_width) // 2, y + 10), "回收最高价/元", font=header_font, fill=text_color)

    draw.line([(col1_width, 0), (col1_width, total_height)], fill=border_color, width=1)

    y += header_height

    # Draw data rows
    for i, (phone_name, price) in enumerate(phone_data):
        draw.line([(0, y), (width, y)], fill=border_color, width=1)

        bbox = draw.textbbox((0, 0), phone_name, font=font)
        text_width = bbox[2] - bbox[0]
        draw.text(((col1_width - text_width) // 2, y + 8), phone_name, font=font, fill=text_color)

        price_text = str(price)
        bbox = draw.textbbox((0, 0), price_text, font=font)
        text_width = bbox[2] - bbox[0]
        draw.text((col1_width + (col2_width - text_width) // 2, y + 8), price_text, font=font, fill=text_color)

        y += row_height

    # Draw "更多回收机型" row
    draw.line([(0, y), (width, y)], fill=border_color, width=1)

    bbox = draw.textbbox((0, 0), "更多回收机型", font=font)
    text_width = bbox[2] - bbox[0]
    draw.text(((col1_width - text_width) // 2, y + 8), "更多回收机型", font=font, fill=text_color)

    bbox = draw.textbbox((0, 0), "→点击去询价", font=font)
    text_width = bbox[2] - bbox[0]
    draw.text((col1_width + (col2_width - text_width) // 2, y + 8), "→点击去询价", font=font, fill=(7, 193, 96))

    y += row_height

    draw.line([(0, y), (width, y)], fill=border_color, width=1)
    draw.rectangle([0, 0, width - 1, total_height - 1], outline=border_color, width=1)

    return img

def upload_to_catbox(image):
    """Upload image to catbox.moe and return URL"""
    img_byte_arr = io.BytesIO()
    image.save(img_byte_arr, format='PNG')
    img_byte_arr.seek(0)

    url = "https://litterbox.catbox.moe/resources/internals/api.php"
    files = {'fileToUpload': ('price_table.png', img_byte_arr, 'image/png')}
    data = {'reqtype': 'fileupload', 'time': '1h'}

    try:
        response = requests.post(url, files=files, data=data, timeout=30)
        if response.status_code == 200:
            return response.text.strip()
    except Exception as e:
        print(f"Litterbox upload error: {e}", file=sys.stderr)

    img_byte_arr.seek(0)
    url = "https://catbox.moe/user/api.php"
    files = {'fileToUpload': ('price_table.png', img_byte_arr, 'image/png')}
    data = {'reqtype': 'fileupload'}

    try:
        response = requests.post(url, files=files, data=data, timeout=30)
        if response.status_code == 200:
            return response.text.strip()
    except Exception as e:
        print(f"Catbox upload error: {e}", file=sys.stderr)

    return None

def main():
    if len(sys.argv) < 2:
        print("Usage: python generate_table_image.py 'iPhone 16:3708,iPhone 15 Plus:2717,...'")
        sys.exit(1)

    phone_str = sys.argv[1]

    phone_data = []
    for item in phone_str.split(','):
        parts = item.split(':')
        if len(parts) == 2:
            phone_data.append((parts[0].strip(), parts[1].strip()))

    img = create_table_image(phone_data)
    image_url = upload_to_catbox(img)

    if image_url:
        print(image_url)
    else:
        print("Upload failed")

if __name__ == "__main__":
    main()
