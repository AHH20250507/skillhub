# -*- coding: utf-8 -*-
"""render_and_send_email.py — Apple 风格日报 HTML 邮件
从 email-payload.json（当前工作目录）读取数据，渲染后通过 SMTP 发送。
环境变量：SMTP_USER, SMTP_PASS, SMTP_HOST(可选), SMTP_PORT(可选), SMTP_TO(可选)
"""
import json, os, smtplib, sys, io, datetime as _dt
import html as _html
from email.mime.text import MIMEText
from email.utils import formatdate, formataddr

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

# payload 来自当前工作目录
PAYLOAD_PATH = os.path.join(os.getcwd(), "email-payload.json")
if not os.path.isfile(PAYLOAD_PATH):
    print(f"[fatal] not found: {PAYLOAD_PATH}", file=sys.stderr)
    sys.exit(2)

with open(PAYLOAD_PATH, "r", encoding="utf-8") as f:
    p = json.load(f)

date_str   = p["date"]
pages_url  = p["pages_url"]
total      = p["total"]
sections   = p["sections"]
highlights = p["highlights"]
all_items  = p["all_items"]
sections_full = p.get("sections_full", sections)

_d = _dt.datetime.strptime(date_str, "%Y-%m-%d")
_w_cn  = ["周一","周二","周三","周四","周五","周六","周日"][_d.weekday()]
_w_en  = ["MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY"][_d.weekday()]
_month = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"][_d.month-1]

SUBJECT = f"AI HOT 日报 · {date_str} · {total} 条动态"

SECTION_COLORS = {
    "行业动态":      "#ff3b30",
    "模型发布/更新":  "#af52de",
    "产品发布/更新":  "#007aff",
    "论文研究":      "#34c759",
    "技巧与观点":    "#ff9500",
}
SECTION_ICON = {
    "行业动态":      "🏢",
    "模型发布/更新":  "🧠",
    "产品发布/更新":  "🚀",
    "论文研究":      "📄",
    "技巧与观点":    "💡",
}

def esc(s):
    return _html.escape(s or "", quote=True)

# ── 1. Hero ──
stat_cells = ""
for s in sections:
    label = s["label"].replace("发布/更新","").replace("发布","").replace("更新","")
    stat_cells += f'''<td align="center" valign="middle" style="padding:14px 4px;border-left:1px solid #ececec;width:20%">
  <div style="font-size:22px;font-weight:700;color:#0071e3;line-height:1;letter-spacing:-0.02em">{s["count"]}</div>
  <div style="font-size:10px;color:#86868b;margin-top:4px;letter-spacing:0.03em">{esc(label)}</div>
</td>'''
stat_cells = stat_cells.replace('<td align="center"', '<td class="stat-td" align="center"', 1)

hero = f'''<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:#fbfbfd">
<tr><td align="center" style="padding:32px 16px 24px 16px">
  <div style="display:inline-block;background:rgba(0,113,227,0.06);border:1px solid rgba(0,113,227,0.1);border-radius:20px;padding:5px 14px;font-size:10px;font-weight:600;color:#86868b;letter-spacing:0.18em;margin-bottom:14px">● AI HOT</div>
  <div style="font-size:11px;color:#86868b;letter-spacing:0.12em;font-weight:500;margin-bottom:4px">{_w_en}</div>
  <div style="font-size:28px;font-weight:700;color:#1d1d1f;letter-spacing:-0.03em;line-height:1.1;margin-bottom:18px">{_month} {_d.day}, {_d.year}</div>
  <div style="font-size:90px;font-weight:800;line-height:0.9;letter-spacing:-0.05em;background:linear-gradient(175deg,#0059b3,#0071e3 30%,#39f 60%,#0071e3);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;margin-bottom:6px">{total}</div>
  <div style="font-size:14px;color:#86868b;font-weight:500;letter-spacing:0.04em;margin-bottom:20px">今日 AI 动态</div>
</td></tr>
<tr><td style="padding:0 16px 28px 16px">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;background:#f5f5f7;border-radius:12px;overflow:hidden">
  <tr>{stat_cells}</tr>
</table>
</td></tr>
</table>'''

# ── 2. Highlight ──
HL_TAGS = [("🔴 重磅", "#ff3b30"), ("🔵 值得看", "#007aff")]
hl_html = ""
for i, h in enumerate(highlights[:2]):
    tag, color = HL_TAGS[i]
    hl_html += f'''<tr><td style="padding:0 16px 8px 16px">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:separate;border-spacing:0">
<tr><td style="background:#ffffff;border:1px solid #ececec;border-radius:10px;padding:12px 14px;border-left:3px solid {color}">
  <div style="font-size:11px;font-weight:700;color:{color};margin:0 0 5px 0;letter-spacing:0.3px">{tag}</div>
  <div style="font-size:14px;font-weight:600;color:#1d1d1f;line-height:1.45;margin:0 0 5px 0">{esc(h["title"])}</div>
  <div style="font-size:12.5px;color:#6e6e73;line-height:1.65;margin:0">{esc(h["summary"])}</div>
</td></tr>
</table>
</td></tr>'''

# ── 3. 全量条目 ──
items_html = ""
global_idx = 0
for sec in sections_full:
    label = sec["label"]
    color = SECTION_COLORS.get(label, "#86868b")
    icon  = SECTION_ICON.get(label, "•")
    items = sec["items"]
    cnt   = len(items)
    items_html += f'''<tr><td style="padding:18px 16px 10px 16px">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;border-bottom:1px solid rgba(0,0,0,0.06)">
<tr>
  <td style="padding:0 0 10px 0"><span style="font-size:16px;font-weight:700;color:#1d1d1f;letter-spacing:-0.01em">{icon} {esc(label)}</span></td>
  <td align="right" style="padding:0 0 10px 0"><span style="font-size:12px;color:#86868b;font-weight:500">{cnt} 条</span></td>
</tr>
</table>
</td></tr>'''
    for it in items:
        global_idx += 1
        url = esc(it.get("url", ""))
        items_html += f'''<tr><td style="padding:0 16px 0 16px">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse;border-bottom:1px solid rgba(0,0,0,0.04)">
<tr>
  <td valign="top" width="36" style="padding:14px 10px 14px 0;font-size:18px;font-weight:700;color:#d2d2d7;letter-spacing:-0.02em;text-align:right;line-height:1.2">{global_idx:02d}</td>
  <td valign="top" style="padding:14px 0 14px 0">
    <a href="{url}" target="_blank" style="text-decoration:none;color:inherit">
      <div style="font-size:14.5px;font-weight:600;color:#1d1d1f;line-height:1.4;margin:0 0 5px 0">{esc(it["title"])}</div>
      <div style="font-size:12.5px;color:#86868b;line-height:1.7;margin:0 0 6px 0">{esc(it["summary"])}</div>
      <div style="font-size:11px;color:#aeaeb2;line-height:1.4;margin:0">
        {esc(it.get("source",""))[:24]} <span style="color:#0071e3"> →</span>
      </div>
    </a>
  </td>
</tr>
</table>
</td></tr>'''

# ── 4. HTML 主体 ──
html = f'''<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  @media screen and (max-width:480px){{.total-num{{font-size:72px!important}}.date-big{{font-size:22px!important}}}}
</style>
</head>
<body style="margin:0;padding:0;background:#fbfbfd;font-family:-apple-system,BlinkMacSystemFont,'SF Pro Display','PingFang SC','Microsoft YaHei','Segoe UI',sans-serif;color:#1d1d1f;-webkit-font-smoothing:antialiased">

<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" bgcolor="#fbfbfd" style="border-collapse:collapse">
<tr><td align="center" style="padding:0">
<table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="max-width:640px;border-collapse:collapse;background:#fbfbfd">
  {hero}
  <tr><td style="padding:0 0 6px 0">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse">{hl_html}</table>
  </td></tr>
  <tr><td style="padding:0">
    <table role="presentation" cellpadding="0" cellspacing="0" border="0" width="100%" style="border-collapse:collapse">{items_html}</table>
  </td></tr>
  <tr><td style="padding:36px 16px 28px 16px;text-align:center;border-top:1px solid rgba(0,0,0,0.04)">
    <div style="width:1px;height:24px;background:rgba(0,0,0,0.08);margin:0 auto 18px"></div>
    <div style="font-size:13px;color:#86868b;font-weight:500">共计 {total} 条 AI 动态 · {date_str}</div>
    <div style="font-size:11px;color:#aeaeb2;margin-top:6px">数据来源 <a href="https://aihot.virxact.com" target="_blank" style="color:#0071e3;text-decoration:none">AI HOT</a> · 每天 08:22 自动推送</div>
  </td></tr>
</table>
</td></tr>
</table>
</body>
</html>'''

# 调试副本
dbg_path = os.path.join(os.getcwd(), "debug-email.html")
with open(dbg_path, "w", encoding="utf-8") as f:
    f.write(html)

# ── 5. 发送 ──
SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.qq.com")
SMTP_PORT = int(os.environ.get("SMTP_PORT", "465"))
SMTP_USER = os.environ.get("SMTP_USER", "")
SMTP_PASS = os.environ.get("SMTP_PASS", "")
TO_ADDR   = os.environ.get("SMTP_TO", SMTP_USER)

if not (SMTP_USER and SMTP_PASS):
    print("[fatal] SMTP_USER / SMTP_PASS not set", file=sys.stderr)
    sys.exit(2)

msg = MIMEText(html, "html", "utf-8")
msg["Subject"] = SUBJECT
msg["From"]    = formataddr(("AI HOT Daily", SMTP_USER))
msg["To"]      = TO_ADDR
msg["Date"]    = formatdate(localtime=True)

print(f"[info] {SUBJECT}")
print(f"[info] html size: {len(html):,} bytes")
try:
    with smtplib.SMTP_SSL(SMTP_HOST, SMTP_PORT, timeout=30) as s:
        s.login(SMTP_USER, SMTP_PASS)
        s.sendmail(SMTP_USER, [TO_ADDR], msg.as_string())
    print(f"[ok] sent to {TO_ADDR}")
except Exception as e:
    print(f"[fail] {type(e).__name__}: {e}", file=sys.stderr)
    sys.exit(1)
