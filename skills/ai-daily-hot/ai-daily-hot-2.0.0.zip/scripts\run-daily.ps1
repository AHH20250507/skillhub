# AI HOT 日报自动运行脚本（由 cron 8:22 调用）
$ErrorActionPreference = "Continue"
$env:PYTHONIOENCODING = "utf-8"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

$envFile = "C:\Users\EDY\.qclaw\workspace-agent-bb31d4af\.env-ai-daily"
if (-not (Test-Path $envFile)) {
    Write-Output "[ERROR] .env-ai-daily not found at $envFile"
    exit 1
}

Get-Content $envFile -Encoding UTF8 | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith("#") -and $line -match '^([^=]+)=(.*)$') {
        $name = $matches[1].Trim()
        $value = $matches[2].Trim()
        [Environment]::SetEnvironmentVariable($name, $value, 'Process')
        Write-Output "[env] $name=<set>"
    }
}

& python "C:\Users\EDY\.qclaw\skills\ai-daily-hot\scripts\ai-daily.py"
exit $LASTEXITCODE
