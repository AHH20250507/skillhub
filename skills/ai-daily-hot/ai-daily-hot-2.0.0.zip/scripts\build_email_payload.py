# -*- coding: utf-8 -*-
"""build_email_payload.py — 拉数据 + 选重点 + 全量条目，输出 JSON
给 HTML 邮件模板用。直接用 AI HOT API 源摘要，不补断。
路径相对 _script_dir_ 解析，通用。
"""
import json, os, sys, io

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

_script_dir = os.path.dirname(os.path.abspath(__file__))
_skill_dir  = os.path.dirname(_script_dir)  # ai-daily-hot/

import importlib.util
ai_daily_path = os.path.join(_script_dir, "ai-daily.py")
_spec = importlib.util.spec_from_file_location("ai_daily", ai_daily_path)
ai_daily = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ai_daily)

# ── 1. 拉数据 ──
data = ai_daily.fetch_data()
date_str = data["date"]

# ── 2. 总数 + 全量条目 ──
total = 0
sections_full = []
all_items = []
for s in data.get("sections", []):
    items = []
    for it in s["items"]:
        items.append({
            "title": it["title"],
            "summary": it["summary"],
            "source": (it.get("sourceName", "") or "")[:24],
            "url": it.get("sourceUrl", ""),
        })
    if items:
        sections_full.append({"label": s["label"], "items": items})
        total += len(items)
        for i, it in enumerate(items, 1):
            all_items.append({
                "n": len(all_items) + 1,
                "title": it["title"],
                "summary": it["summary"],
                "source": it["source"],
                "url": it["url"],
                "section": s["label"],
            })

# ── 3. 2 条重点 ──
highlights = ai_daily.pick_highlights(data)

# ── 4. 拼输出 ──
payload = {
    "date": date_str,
    "pages_url": ai_daily.PAGES_URL,
    "total": total,
    "sections": [{"label": s["label"], "count": len(s["items"])} for s in sections_full],
    "highlights": highlights,
    "all_items": all_items,
    "sections_full": sections_full,
}
out_path = os.path.join(os.getcwd(), "email-payload.json")
with open(out_path, "w", encoding="utf-8") as f:
    json.dump(payload, f, ensure_ascii=False, indent=2)
print(f"[ok] wrote {out_path} ({total} items, {len(sections_full)} sections)")
