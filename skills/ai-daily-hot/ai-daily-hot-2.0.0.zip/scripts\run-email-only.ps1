# run-email-only.ps1 — AI HOT 日报纯邮件推送（主入口）
# 用法：从 workspace（含 .env-qq-mail）执行：
#   powershell -ExecutionPolicy Bypass -File path\to\scripts\run-email-only.ps1
$ErrorActionPreference = "Stop"
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$cwd    = Get-Location
$script = $PSScriptRoot

# Step 1: 拉数据 → email-payload.json
Write-Host "=== Step 1: fetch data ==="
& python (Join-Path $script "build_email_payload.py")
if ($LASTEXITCODE -ne 0) { Write-Error "build_email_payload.py failed"; exit 1 }

# Step 2: 发邮件（send-daily-email.ps1 负责加载 .env-qq-mail）
Write-Host "=== Step 2: render & send ==="
& powershell -ExecutionPolicy Bypass (Join-Path $script "send-daily-email.ps1")
if ($LASTEXITCODE -ne 0) { Write-Error "send-daily-email.ps1 failed"; exit 1 }

Write-Host "=== Done ==="
