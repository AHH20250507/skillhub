---
name: ai-daily-hot
description: "AI HOT 日报自动化推送 — 从 aihot.virxact.com 拉取每日 AI 资讯，生成 Apple 风格 HTML 邮件推送。支持纯邮件或 GitHub Pages 两种输出方式。关键词：AI日报、AI早报、每日AI、邮件推送"
version: "2.0.0"
author: "EDY"
created: "2026-06-29"
---

# AI HOT 日报自动化推送

> **Goal**: 每天自动从 [AI HOT](https://aihot.virxact.com) 拉取最新 AI 资讯，生成 Apple 风格日报，通过邮件送达。

## When to Use

- 用户要求「推送 AI 日报」「拉取今日 AI 资讯」「每天早上推送到邮箱」
- 用户说「帮我看看今天 AI 圈发生了什么」
- 创建 AI HOT 日报的定时推送任务

## 前置条件

1. **Python 3.11+** — 脚本依赖标准库，无需额外安装包
2. **QQ 邮箱 SMTP 授权码** — 用于发送 HTML 邮件（或以 `imap-smtp-email` skill 的方式）
3. **（可选）GitHub 仓库 + Token** — 如果同时推送到 Pages

### 文件说明

```
scripts/
├── ai-daily.py                  # 核心：拉取 + 生成 HTML + Git push
├── build_email_payload.py       # 拉数据 → email-payload.json（复用 ai-daily.fetch_data）
├── render_and_send_email.py     # email-payload.json → Apple 风格 HTML 邮件 → SMTP 发送
├── run-daily.ps1                # 旧版：推 GitHub Pages + 纯文本邮件（已弃用）
├── run-email-only.ps1           # [推荐] 新版：纯邮件推送（两步脚本）
├── build-email-payload.ps1      # 调 build_email_payload.py
└── send-daily-email.ps1         # 读取 .env-qq-mail → 调 render_and_send_email.py
templates/
├── .env-qq-mail.example         # QQ 邮箱 SMTP 凭证模板
└── .env-ai-daily.example        # GitHub Token 凭证模板（Pages 用）
```

## 使用方式

### 方式一：纯邮件推送（推荐）

1. 在 workspace 下创建 `.env-qq-mail`（或用 template 复制）：

```bash
SMTP_HOST=smtp.qq.com
SMTP_PORT=465
SMTP_USER=123456789@qq.com
SMTP_PASS=你的SMTP授权码
# SMTP_TO 可选，默认同 SMTP_USER
```

2. 手动执行一次：

```powershell
# 两步走
& ".\build-email-payload.ps1"           # 拉数据 → email-payload.json
restart??   # 需要 Python 3 在 PATH 中
.\scripts\run-email-only.ps1
```

或组装后执行：

```powershell
# 从 workspace 运行
powershell -ExecutionPolicy Bypass -File path\to\scripts\run-email-only.ps1
```

### 方式二：旧版推 GitHub Pages

设置环境变量 `GITHUB_TOKEN`、`GITHUB_USER`、`GITHUB_REPO`（见 templates/.env-ai-daily.example），然后：

```bash
python scripts/ai-daily.py
```

### 方式三：创建定时任务

在 OpenClaw 中创建 cron（agentTurn, isolated），payload 内容参照下方：

```json
{
  "kind": "agentTurn",
  "message": "请执行 AI HOT 日报邮件推送流程：
    1. 调用本 skill 的 build_email_payload.py 拉取今日 AI 热点，输出 email-payload.json
    2. 调用 render_and_send_email.py 渲染 Apple 风格 HTML 并发送
    3. 用 3-5 句话汇报：今日条数、2 条重点、发送状态"
}
```

cron 配置参考：
- `schedule`: `{ "kind": "cron", "expr": "22 8 * * *", "tz": "Asia/Shanghai" }`
- `sessionTarget`: `isolated`
- `delivery`: `{ "mode": "none" }` (日志不回传主会话)

## 邮件模板说明

`render_and_send_email.py` 输出的 HTML 邮件特点：
- Apple 风格设计语言 — #fbfbfd 底色、SF Pro 字体、#0071e3 蓝色点缀
- Hero 区：巨数字日期 + 5 分类统计条
- 2 条 Highlight 卡片（🔴 重磅 / 🔵 值得看）
- 编号全量条目（01-26），按分类分组，每项可点击源链接
- 响应式 max-width 640px，适配手机
- 无跳转按钮，邮件即日报本体

样式微调直接改 `render_and_send_email.py` 中的 HTML 模板。

## 数据来源

数据来自 [AI HOT](https://aihot.virxact.com) 平台，涵盖以下分类：
- 模型发布/更新
- 产品发布/更新
- 论文研究
- 行业动态
- 技巧与观点
