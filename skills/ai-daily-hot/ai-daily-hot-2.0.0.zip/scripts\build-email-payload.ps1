# build-email-payload.ps1 — 调 scripts 下的 build_email_payload.py
# 读取当前目录的 .env-ai-daily（有的试一下，非必需）
$ErrorActionPreference = "Stop"
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

# 当前工作目录 = workspace
$cwd = Get-Location
$envFile = Join-Path $cwd ".env-ai-daily"
if (Test-Path $envFile) {
    Get-Content $envFile | ForEach-Object {
        $line = $_.Trim()
        if ($line -and -not $line.StartsWith("#")) {
            $idx = $line.IndexOf("=")
            if ($idx -gt 0) {
                $name  = $line.Substring(0, $idx).Trim()
                $value = $line.Substring($idx + 1).Trim()
                Set-Item -Path "Env:$name" -Value $value
            }
        }
    }
}

# 脚本路径用 PSScriptRoot
$pyScript = Join-Path $PSScriptRoot "build_email_payload.py"
if (-not (Test-Path $pyScript)) { Write-Error "missing $pyScript"; exit 2 }
Set-Location $cwd
& python $pyScript
exit $LASTEXITCODE
