# send-daily-email.ps1 — 加载当前目录下的 .env-qq-mail → 调 render_and_send_email.py
$ErrorActionPreference = "Stop"
chcp 65001 | Out-Null
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$env:PYTHONIOENCODING = "utf-8"
$env:PYTHONUTF8 = "1"

$cwd = Get-Location
$envFile = Join-Path $cwd ".env-qq-mail"
if (-not (Test-Path $envFile)) { Write-Error "missing .env-qq-mail in $cwd"; exit 2 }
Get-Content $envFile | ForEach-Object {
    $line = $_.Trim()
    if ($line -and -not $line.StartsWith("#")) {
        $idx = $line.IndexOf("=")
        if ($idx -gt 0) {
            $name  = $line.Substring(0, $idx).Trim()
            $value = $line.Substring($idx + 1).Trim()
            Set-Item -Path "Env:$name" -Value $value
        }
    }
}

# render_and_send_email.py 和本脚本同目录
$pyScript = Join-Path $PSScriptRoot "render_and_send_email.py"
if (-not (Test-Path $pyScript)) { Write-Error "missing $pyScript"; exit 2 }
Set-Location $cwd
& python $pyScript
exit $LASTEXITCODE
