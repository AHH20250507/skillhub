# 公众号HTML助手 (wechat-html-helper)

## 项目概述

单文件 Web 工具，用于微信公众号文章 HTML 处理，部署在 GitHub Pages。

- 线上地址：https://ahh20250507.github.io/wechat-html-helper/
- 仓库地址：https://github.com/AHH20250507/wechat-html-helper

## 功能说明

### 第一步：HTML 编辑
- 颜色替换：#006fff → #00b050
- 头图替换：旧 GIF 头图 → 新 GIF 头图
- 追加结尾：可上传/粘贴 HTML 片段拼接到末尾

### 第二步：图片处理
- 4 个槽位，支持上传、裁剪、文字覆盖、蒙层透明度调节
- 输出映射：选择哪两个槽位作为"图片1"和"图片2"
- 图片上传到 GitHub 仓库 images/ 目录（固定文件名 cover1~4.png，覆盖式）
- 本地 localStorage 持久化记录，下次打开自动恢复
- 每个槽位可单独清除

### 第三步：融合生成
- 3 个 HTML 模板（EPBox、壹站收、酷换机）
- 模板中 （图片1）（图片2）占位符自动替换为上传后的图片 URL
- 快捷复制：按模板分组管理文本片段，支持备注
- 设为默认 / 恢复默认 / 重置模板

## 部署方式

本地编辑 `index.html` → 推送到 GitHub 仓库 main 分支 → GitHub Pages 自动部署。

```bash
# 克隆仓库
git clone https://github.com/AHH20250507/wechat-html-helper.git

# 修改 index.html 后推送
git add index.html
git commit -m "update"
git push
```

## GitHub 凭证

- 仓库：AHH20250507/wechat-html-helper
- Token：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
- 用途：页面内通过 GitHub Contents API 上传图片（images/cover1~4.png）
- 注意：Token 无 workflow scope，不能通过 API 推送 .github/workflows 文件

## 技术要点

- 纯单文件 HTML/CSS/JS，无框架依赖
- Canvas API 渲染 1280×360 封面图
- GitHub Contents API 上传图片（GET 获取 SHA → PUT 覆盖）
- localStorage 持久化模板、快捷复制、图片记录
- 图片 URL 追加 ?t=timestamp 防 CDN 缓存
- meta http-equiv Cache-Control no-cache 防浏览器缓存

## 文件结构

```
index.html          ← 主文件（全部代码）
images/             ← GitHub 仓库中的图片目录（cover1~4.png）
README.md           ← 本文件
```

## 已知注意事项

- GitHub raw 图片 URL 有 CDN 缓存（~10分钟），覆盖同名文件后需加 ?t= 参数
- GitHub Pages 默认 Cache-Control: max-age=600（Fastly CDN）
- 从国内访问 GitHub API 延迟 2~6 秒属正常现象
- localStorage 存储图片缩略图（JPEG 0.6 质量），4 张约占 400~800KB
