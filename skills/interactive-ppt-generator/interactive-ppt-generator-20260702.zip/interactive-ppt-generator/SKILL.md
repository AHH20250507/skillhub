---
name: interactive-ppt-generator
description: Generates a fully interactive, draggable, and animatable HTML presentation based on user provided themes, content, and style. Outputs a self-contained HTML file.
---

# Interactive PPT Generator Skill

When the user requests to create or generate a birthday HTML, interactive PPT, or presentation based on a theme (e.g., "Cyberpunk", "Ocean Theme", "Forest Theme"), follow these precise instructions to generate a fully functional HTML presentation.

## 1. Understand the Goal
You will be taking an existing template (`C:\Users\EDY\.gemini\config\skills\interactive-ppt-generator\resources\template.html`) which contains a highly advanced JavaScript presentation engine (supporting dragging, scaling, rotating, undo, cross-page copying, music management, and exporting). Your job is to inject custom CSS and HTML slides into it to match the user's requested theme.

## 2. Process
1. **Read the Template**: Read the template file using the `view_file` tool at `C:\Users\EDY\.gemini\config\skills\interactive-ppt-generator\resources\template.html`.
2. **Design the Theme CSS**:
   - Determine the theme colors (e.g., `--pop-primary: #ff00ff;`, `--dark-border: #111;`).
   - Design a beautiful `background-image` for the `body` (e.g., CSS gradients, patterns).
   - Design custom CSS classes for the slides (e.g., `.slide-cover`, `.slide-game`, `.slide-stars`). Ensure fonts and shadows match the requested theme.
3. **Design the Slides (HTML)**:
   - Create the `<div class="slide ...">...</div>` blocks for the presentation.
   - You MUST include the `active` class on the very first slide (e.g., `<div class="slide slide-cover active">`).
   - Use `data-base-rotate="X"` and `contenteditable="true"` on textual or visual elements to make them interactive.
4. **Assemble**:
   - Replace `/* THEME_COLORS_HERE */` with your CSS variables.
   - Replace `/* THEME_BODY_BACKGROUND_HERE */` with your body background CSS.
   - Replace `/* SLIDE_STYLES_HERE */` with your custom CSS classes for slides.
   - Replace `<!-- SLIDES_CONTENT_HERE -->` with your generated HTML slides.
5. **Output**: Write the final assembled HTML to a new file in the user's workspace (e.g., `D:\AI工作区间\srh\xxx_presentation.html`). Do not use `tmp` or `.gemini` for the final output unless requested.

## 3. Strict Rules
- **NEVER** modify or remove the `<script>` section or any of the existing CSS related to `.media-controls`, `.nav-controls`, `#toast`, `#presentation-container`, `#music-toolbar`, etc.
- **ALWAYS** include the `contenteditable="true"` attribute on textual elements that the user might want to edit.
- **ALWAYS** wrap your slides in `<div class="slide [your-custom-class]">`. Only the first slide should have the `active` class.
- Elements that should be absolutely positioned and freely draggable over everything must have the class `custom-text` or `custom-img`.
- Elements that are part of the layout but should have an initial tilt can use `data-base-rotate="10"`.
- Make sure to use high-quality aesthetics! The presentation should look premium and visually stunning.
