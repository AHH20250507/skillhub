---
name: 知识库创建skill
description: >-
  把一批本地文档（默认 PDF）一键变成一个可调用的本地知识库 skill（RAG）。当用户说"把XX内容变成skill"
  "把PDF变成知识库""构建本地知识库skill""做个基于XXX的问答skill"，并给出资料文件夹与技能名称时使用。
  生成的 skill 会先检索原文片段、再据片段作答并标注来源，不胡编。触发词：变成skill、知识库skill、
  文档变skill、PDF转skill、构建问答skill、本地知识库。
agent_created: true
---

# 知识库创建skill —— 把文档变成可调用的知识库 skill

把"建本地 RAG 知识库 skill"这件事本身做成可复用能力。用户给出**资料文件夹**和**技能名称**，
即可像搭"XD"那样自动生成一个知识库 skill，放在桌面并可被直接调用。

## 何时使用

- 用户说"把 `<某文件夹>` 的内容变成 skill，名字叫 `<XXX>`"。
- 用户说"把 PDF 变成知识库""做个基于 XXX 资料的问答 skill""构建本地知识库 skill"。
- 资料可以是 PDF 合集（首选），未来可扩展到 txt/md/docx。

## 需要向用户确认的信息（若用户没给）

1. **资料文件夹绝对路径**（必填，如 `D:\docs\pdfs`）。
2. **技能名称**（必填，如 `XD`、`法律库`）。
3. **输出位置**（默认桌面 `C:\Users\21010\Desktop`；用户可指定）。
4. **是否扫描图片型 PDF**：文本型直接提取；扫描型需 OCR（更慢更重），
   若资料里疑似有扫描件，先建好文本型部分，再问用户要不要加 OCR。

## 执行流程（照做即可，不要重写脚本）

直接调用脚手架，它会自动完成 venv、复制模板、生成 SKILL.md、共享模型、建索引、安装、验证：

```bash
C:/Users/21010/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe \
  "C:/Users/21010/Desktop/知识库创建skill/scripts/create_kb_skill.py" \
  --source-dir "资料文件夹绝对路径" \
  --name "技能名称" \
  --output-dir "输出位置(默认桌面)"
```

- 若同名技能已存在：加 `--force` 覆盖，否则脚本会报错提示。
- 脚手架会自动确保 Python venv 与中文嵌入模型（`~/.workbuddy/kb_models/BAAI_bge-small-zh-v1.5`），
  多个知识库 skill **共享同一份模型**，不会重复下载。

## 脚手架完成后，如何验证"真的能用"

用 Skill 工具直接调用刚生成的技能名，跑一个示例问题：

```
Skill(skill="技能名称", args="测试问题")
```

若返回"检索模式: hybrid ..."并带来源片段，说明成功。再把基于检索的回答呈现给用户。

## 关键踩坑（重要，复用经验）

1. **Windows HuggingFace 缓存靠符号链接**，本环境无符号链接权限 → snapshot 目录为空。
   → 解决：`snapshot_download(local_dir=..., local_dir_use_symlinks=False)` 下成普通文件夹（脚手架已封装）。
2. **huggingface_hub 新版默认 xet 协议**下载权重会打 `cas-server.xethub.hf.co` 报 401。
   → 解决：`HF_HUB_DISABLE_XET=1`（脚手架已设）。
3. **官方 huggingface.co 在本环境超时**，用 `HF_ENDPOINT=https://hf-mirror.com` 镜像（脚手架已设）。
4. **chunks 用 JSON Lines 存储**（`kb_data/chunks.jsonl`），不是 pickle——检查索引时要读 jsonl。
5. **扫描图片型 PDF 无文本**，会被跳过；如需纳入要加 OCR（paddleocr/tesseract）。
6. **venv 已建好**于 `C:\Users\21010\.workbuddy\binaries\python\envs\pdfkb`，依赖通用，新技能直接复用。

## 生成的 skill 如何维护（告诉用户）

- **增/删 PDF**：改动资料文件夹后，跑一次（增量，只处理变动文件）：
  ```bash
  C:/Users/21010/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe \
    "输出位置/技能名称/scripts/build_index.py" --pdf-dir "资料文件夹"
  ```
- **全量重建**：上面命令加 `--rebuild`。

## 设计要点（保证"增删干净"）

- 每个片段记录来源文件名 + 页码；删除某 PDF 时按来源清除其全部片段，不误伤别的。
- 索引与源文件分离：原始 PDF 在资料文件夹，索引在 `技能目录/kb_data/`。
- 混合检索：BM25（jieba 中文分词）+ 语义向量（bge-small-zh）；向量缺失自动回退纯 BM25。
