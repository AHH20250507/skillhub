"""Shared helpers for a PDF knowledge-base skill (TEMPLATE — copy-paste ready).

All paths are derived from this file's location, so the skill works wherever it
is copied. Chunks are stored as JSON Lines (kb_data/chunks.jsonl).
"""
import os
import sys
import json
import hashlib

APP_DATA = os.path.expanduser("~/.workbuddy")

# All KB skills share ONE embedding model to avoid re-downloading ~100MB each time.
SHARED_MODEL_DIR = os.path.join(APP_DATA, "kb_models", "BAAI_bge-small-zh-v1.5")

# Skill root = parent of the 'scripts' dir that holds this file.
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
KB_DIR = os.path.join(BASE_DIR, "kb_data")

# Source PDF folder: override via env XD_PDF_DIR or the build script's --pdf-dir arg.
DEFAULT_PDF_DIR = os.environ.get("XD_PDF_DIR", "")

# Use the shared local model if present; otherwise let sentence-transformers fetch it.
EMB_MODEL_NAME = SHARED_MODEL_DIR if os.path.isdir(SHARED_MODEL_DIR) else "BAAI/bge-small-zh-v1.5"

BM25_PATH = os.path.join(KB_DIR, "bm25.pkl")
EMB_PATH = os.path.join(KB_DIR, "embeddings.npy")
EMB_META_PATH = os.path.join(KB_DIR, "emb_meta.json")
CHUNKS_PATH = os.path.join(KB_DIR, "chunks.jsonl")
MANIFEST_PATH = os.path.join(KB_DIR, "manifest.json")


def file_md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return h.hexdigest()


def tokenize(text):
    import jieba
    return [w for w in jieba.lcut(text) if w.strip()]


def load_chunks():
    if not os.path.exists(CHUNKS_PATH):
        return []
    out = []
    with open(CHUNKS_PATH, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def save_chunks(chunks):
    os.makedirs(KB_DIR, exist_ok=True)
    with open(CHUNKS_PATH, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")


def load_manifest():
    if not os.path.exists(MANIFEST_PATH):
        return {}
    with open(MANIFEST_PATH, encoding="utf-8") as f:
        return json.load(f)


def save_manifest(m):
    os.makedirs(KB_DIR, exist_ok=True)
    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
