"""Hybrid retrieval for a PDF knowledge-base skill (TEMPLATE — copy-paste ready).

Usage:
    python query.py "你的问题" --k 6 [--json]
Prints Top-K chunks with source file + page; auto-falls back to BM25 if no vectors.
"""
import os
import sys
import json
import pickle
import argparse
import warnings

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import KB_DIR, BM25_PATH, EMB_PATH, EMB_META_PATH, CHUNKS_PATH, tokenize


def load_chunks():
    out = []
    if not os.path.exists(CHUNKS_PATH):
        return out
    with open(CHUNKS_PATH, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def _norm(a):
    import numpy as np
    a = np.asarray(a, dtype=float)
    if a.max() == a.min():
        return np.zeros_like(a)
    return (a - a.min()) / (a.max() - a.min())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("question")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    chunks = load_chunks()
    if not chunks:
        print("知识库为空，请先运行 build_index.py 构建索引。")
        return

    with open(BM25_PATH, "rb") as f:
        bm = pickle.load(f)["bm25"]
    qtok = tokenize(args.question)
    bm_scores = bm.get_scores(qtok) if bm else [0.0] * len(chunks)

    vec_scores = None
    mode = "bm25-only"
    if os.path.exists(EMB_PATH) and os.path.exists(EMB_META_PATH):
        try:
            import numpy as np
            from sentence_transformers import SentenceTransformer
            from common import EMB_MODEL_NAME
            emb = np.load(EMB_PATH)
            model = SentenceTransformer(EMB_MODEL_NAME)
            q = model.encode([args.question], normalize_embeddings=True)[0]
            vec_scores = (emb @ q).astype("float32")
            mode = "hybrid (bm25+vector)"
        except Exception as e:
            print(f"[warn] vector load failed ({e}); using BM25 only",
                  file=sys.stderr)

    nb = _norm(bm_scores)
    if vec_scores is not None:
        nv = _norm(vec_scores)
        final = 0.5 * nb + 0.5 * nv
    else:
        final = nb

    order = sorted(range(len(chunks)), key=lambda i: final[i], reverse=True)[:args.k]

    if args.json:
        out = [{"source": chunks[i]["source"], "page": chunks[i]["page"],
                "score": round(float(final[i]), 4), "text": chunks[i]["text"]}
               for i in order]
        print(json.dumps(out, ensure_ascii=False, indent=2))
    else:
        print(f"# 检索模式: {mode} | 问题: {args.question}\n")
        for rank, i in enumerate(order, 1):
            c = chunks[i]
            print(f"--- [{rank}] 来源: {c['source']} · 第 {c['page']} 页 "
                  f"(score {float(final[i]):.4f}) ---")
            print(c["text"])
            print()


if __name__ == "__main__":
    main()
