---
name: {{SKILL_NAME}}
description: >-
  基于本地 PDF 文档构建的私有知识库问答技能。当用户想从这批 PDF 中查资料、提问、求证、检索概念、
  查找出处，或明确调用 "{{SKILL_NAME}}" 时使用。回答必须严格依据知识库检索到的原文片段，不得凭空编造。
  触发词：{{SKILL_NAME}}、知识库、这些PDF、我的资料、文档里说、查一下、根据文档、出处。
agent_created: true
---

# {{SKILL_NAME}} —— 本地 PDF 知识库问答

检索增强（RAG）技能。知识库源文件与索引位于：`{{SKILL_DIR}}`。
回答问题时**先检索、再依据检索到的原文作答**，避免胡编，并标注来源文件与页码。

## 何时使用

- 用户明确说"用 {{SKILL_NAME}}"/"查知识库"/"根据这些 PDF"/"文档里怎么说"。
- 用户的问题应由这批资料回答，而非模型的通用知识。

## 回答流程（务必遵守）

1. **先检索**。运行检索脚本取回最相关的原文片段（问题用引号包起来）：

   ```bash
   C:/Users/21010/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe \
     "{{SKILL_DIR}}/scripts/query.py" "用户的问题" --k 6
   ```

   - `--k` 控制返回片段数（默认 5，复杂问题可加大到 8）；需要结构化输出加 `--json`。

2. **只依据检索结果作答**。仅使用返回片段中的信息，可综合归纳，但不得引入片段之外的知识。

3. **标注来源**。每个关键结论注明来自哪个 PDF、第几页，例如：
   `（来源：xxx.pdf 第 N 页）`

4. **检索不到就如实说明**。返回为空或明显不相关时，直接告诉用户"知识库中没有找到相关内容"，
   不要编造。

## 维护知识库（增 / 删 / 改 PDF）

源 PDF 文件夹：`{{PDF_DIR}}`。改动后运行更新脚本即可。

- **增量更新**（只处理新增/变化/删除的文件，快）：

  ```bash
  C:/Users/21010/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe \
    "{{SKILL_DIR}}/scripts/build_index.py" --pdf-dir "{{PDF_DIR}}"
  ```

- **全量重建**（忽略缓存从头重建）：在上面命令后加 `--rebuild`。

## 检索机制

- 混合检索：BM25 关键词（jieba 分词）+ 语义向量（BAAI/bge-small-zh 中文模型，共享于 ~/.workbuddy/kb_models）。
- 若环境缺少向量模型，自动回退为纯 BM25，功能不受影响。检索输出首行的"检索模式"会标明当前方式。
- 索引数据在 `{{SKILL_DIR}}/kb_data\`。
- 扫描版（图片型）PDF 无法提取文字，会被跳过；如需纳入需额外 OCR。
