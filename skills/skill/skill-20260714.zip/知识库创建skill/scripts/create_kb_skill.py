"""One-shot scaffolder: turn a folder of PDFs into a callable knowledge-base skill.

Usage:
    python create_kb_skill.py --source-dir "D:/docs/pdfs" --name MyKB --output-dir "C:/Users/21010/Desktop"
    python create_kb_skill.py --source-dir "..." --name MyKB          # output defaults to Desktop

What it does (the whole "XD-style" pipeline):
  1. Ensures the Python venv with pdfplumber/jieba/BM25/sentence-transformers exists.
  2. Copies the template scripts (build_index.py / query.py / common.py) into the new skill.
  3. Renders SKILL.md from the template (fills name / source dir / skill dir),
     installs it both on the Desktop and into ~/.workbuddy/skills/<name>/.
  4. Ensures a shared bge-small-zh embedding model (reuse XD's if present, else download).
  5. Builds the index (chunks + BM25 + vectors).
  6. Runs one probe query to verify retrieval works.
"""
import os
import sys
import shutil
import argparse
import subprocess

# ---- fixed environment paths (this machine) ----
APP_DATA = os.path.expanduser("~/.workbuddy")
PY_EXE = "C:/Users/21010/.workbuddy/binaries/python/versions/3.13.12/python.exe"
VENV_DIR = os.path.join(APP_DATA, "binaries", "python", "envs", "pdfkb")
VENV_PY = os.path.join(VENV_DIR, "Scripts", "python.exe")
PIP = os.path.join(VENV_DIR, "Scripts", "pip.exe")
SHARED_MODEL_DIR = os.path.join(APP_DATA, "kb_models", "BAAI_bge-small-zh-v1.5")
XD_MODEL_ALT = "C:/Users/21010/Desktop/XD/models/bge-small-zh-v1.5"

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATES_DIR = os.path.join(os.path.dirname(SCRIPT_DIR), "templates")


# ---------------------------------------------------------------- venv
def ensure_venv():
    if os.path.exists(VENV_PY):
        print(f"[venv] using existing {VENV_DIR}")
        return
    print(f"[venv] creating {VENV_DIR} ...")
    subprocess.run([PY_EXE, "-m", "venv", VENV_DIR], check=True)
    subprocess.run([PIP, "install", "-q", "pdfplumber", "jieba",
                    "rank_bm25", "numpy", "tqdm", "sentence-transformers"],
                   check=True)
    print("[venv] dependencies installed.")


# ---------------------------------------------------------------- model
def ensure_model():
    if os.path.isdir(SHARED_MODEL_DIR):
        print(f"[model] shared model present: {SHARED_MODEL_DIR}")
        return
    os.makedirs(os.path.dirname(SHARED_MODEL_DIR), exist_ok=True)
    # Reuse the model bundled with the XD skill if it exists (no re-download).
    if os.path.isdir(XD_MODEL_ALT):
        print(f"[model] reusing XD's model -> {SHARED_MODEL_DIR}")
        shutil.copytree(XD_MODEL_ALT, SHARED_MODEL_DIR)
        return
    # Otherwise download once via the venv python (mirror + xet disabled).
    print("[model] downloading BAAI/bge-small-zh-v1.5 (mirror) ...")
    code = (
        "import os;"
        "os.environ['HF_ENDPOINT']='https://hf-mirror.com';"
        "os.environ['HF_HUB_DISABLE_XET']='1';"
        "from huggingface_hub import snapshot_download;"
        "p=snapshot_download(repo_id='BAAI/bge-small-zh-v1.5', "
        f"local_dir=r'{SHARED_MODEL_DIR}', local_dir_use_symlinks=False);"
        "print('DOWNLOADED_TO', p)"
    )
    subprocess.run([VENV_PY, "-c", code], check=True)
    print("[model] downloaded.")


# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source-dir", required=True, help="folder of PDFs to ingest")
    ap.add_argument("--name", required=True, help="skill name (ascii/中文均可)")
    ap.add_argument("--output-dir", default="C:/Users/21010/Desktop",
                    help="where to drop the skill folder (default: Desktop)")
    ap.add_argument("--force", action="store_true",
                    help="overwrite an existing skill folder of the same name")
    args = ap.parse_args()

    src = os.path.abspath(args.source_dir)
    if not os.path.isdir(src):
        print(f"ERROR: source dir not found: {src}"); sys.exit(1)
    pdfs = [f for f in os.listdir(src) if f.lower().endswith(".pdf")]
    if not pdfs:
        print(f"ERROR: no PDF files in {src}"); sys.exit(1)
    print(f"[init] source: {src}  ({len(pdfs)} PDFs)  name: {args.name}")

    target = os.path.join(os.path.abspath(args.output_dir), args.name)
    if os.path.exists(target) and not args.force:
        print(f"ERROR: {target} already exists. Use --force to overwrite, "
              f"or just run build_index.py there to update.")
        sys.exit(1)

    ensure_venv()
    ensure_model()

    # 1) copy template scripts
    os.makedirs(os.path.join(target, "scripts"), exist_ok=True)
    os.makedirs(os.path.join(target, "kb_data"), exist_ok=True)
    for fn in ("build_index.py", "query.py", "common.py"):
        shutil.copy2(os.path.join(TEMPLATES_DIR, fn),
                     os.path.join(target, "scripts", fn))
    print(f"[scaffold] copied template scripts -> {target}/scripts")

    # 2) render SKILL.md (template -> instance), install in two places
    tpl = open(os.path.join(TEMPLATES_DIR, "SKILL_template.md"),
               encoding="utf-8").read()
    rendered = (tpl
                .replace("{{SKILL_NAME}}", args.name)
                .replace("{{SKILL_DIR}}", target)
                .replace("{{PDF_DIR}}", src))
    skill_md = os.path.join(target, "SKILL.md")
    with open(skill_md, "w", encoding="utf-8") as f:
        f.write(rendered)
    user_skill_dir = os.path.join(APP_DATA, "skills", args.name)
    os.makedirs(user_skill_dir, exist_ok=True)
    shutil.copy2(skill_md, os.path.join(user_skill_dir, "SKILL.md"))
    print(f"[install] SKILL.md -> {skill_md}")
    print(f"[install] skill registered -> {user_skill_dir}")

    # 3) build index
    print("\n[build] building index (chunks + BM25 + vectors) ...")
    build = os.path.join(target, "scripts", "build_index.py")
    subprocess.run([VENV_PY, build, "--pdf-dir", src], check=True)

    # 4) verify with a probe query
    print("\n[verify] probe query ...")
    q = os.path.join(target, "scripts", "query.py")
    probe = pdfs[0].replace(".pdf", "")[:20]
    r = subprocess.run([VENV_PY, q, probe, "--k", "2"],
                       capture_output=True, text=True)
    if r.returncode == 0 and "来源" in r.stdout:
        print("[verify] OK — retrieval returned sourced chunks.")
    else:
        print("[verify] WARNING: probe query returned no sourced chunks.")
        print(r.stdout[:500])

    print("\n=== DONE ===")
    print(f"Skill folder : {target}")
    print(f"Callable as  : {args.name}  (say '用 {args.name} 查 ...')")
    print(f"Update later : {VENV_PY} \"{target}/scripts/build_index.py\" --pdf-dir \"{src}\"")


if __name__ == "__main__":
    main()
