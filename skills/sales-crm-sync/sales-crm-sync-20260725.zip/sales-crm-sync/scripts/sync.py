#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
sales-crm-sync 同步脚本（仅用 Python 标准库，无需 pip 安装）。
读取分类结果 payload 文件，注入 token，POST 到云端 CRM 的 /api/customer。

用法：
  python3 sync.py --api-base <URL> --token <KEY> --payload <file.json> [--timeout 30]

后端契约：POST {api_base}/api/customer，请求体 JSON 含 `token` 字段鉴权。
"""
import sys
import json
import argparse
import urllib.request
import urllib.error


def main():
    parser = argparse.ArgumentParser(description="Sync a customer classification payload to the cloud CRM.")
    parser.add_argument("--api-base", default="https://openxin-d4g2wm7v431a4bbbf.service.tcloudbase.com",
                        help="Cloud CRM base URL (default: deployed CloudBase env)")
    parser.add_argument("--token", required=True, help="Sales API Key (写入令牌), sent as `token` in body")
    parser.add_argument("--payload", required=True, help="Path to JSON payload file (classification output)")
    parser.add_argument("--timeout", type=int, default=30, help="Request timeout seconds")
    args = parser.parse_args()

    # 读取分类 payload
    try:
        with open(args.payload, "r", encoding="utf-8") as f:
            payload = json.load(f)
    except Exception as e:
        print(json.dumps({"error": "cannot read payload file: %s" % e}, ensure_ascii=False))
        sys.exit(2)

    if not isinstance(payload, dict):
        print(json.dumps({"error": "payload must be a JSON object"}, ensure_ascii=False))
        sys.exit(2)

    # 注入 token（后端鉴权字段）
    payload["token"] = args.token

    # 基本校验：name 或 customer_id 至少其一
    if not payload.get("name") and not payload.get("customer_id"):
        print(json.dumps({"error": "payload must contain `name` or `customer_id`"}, ensure_ascii=False))
        sys.exit(2)

    url = args.api_base.rstrip("/") + "/api/customer"
    data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        url,
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=args.timeout) as resp:
            body = resp.read().decode("utf-8")
            try:
                parsed = json.loads(body)
                print(json.dumps(parsed, ensure_ascii=False, indent=2))
            except Exception:
                print(body)
            sys.exit(0)
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        print(json.dumps({"http_error": e.code, "detail": detail}, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=False))
        sys.exit(2)


if __name__ == "__main__":
    main()
