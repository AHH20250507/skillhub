description: Synthesizes a WeChat official account article from a given theme and URLs. Features an intro, curated ~100-word paragraphs with #006fff bold highlights, alternating images, and an outro. Uses Humanizer-zh-main for professional, non-AI content. Strictly extracts authentic images, removes watermarks, and outputs minified HTML with zero side margins, no image effects, and 1.0/2.0 differentiated spacing.
---

# SJTW (WeChat Article Creator)

This skill creates a beautifully formatted WeChat Official Account article based on a user-provided Theme and a list of article links. It synthesizes the information from the links, formats it with specific stylistic highlights, selects authentic images, removes any watermarks, and outputs the final HTML minified for direct copy-pasting.

## Workflow

When the user provides a Theme and a list of links, **automatically start working without asking for further confirmation**. Follow these exact steps:

### 1. Humanized Synthesis (MANDATORY)
- Read the content of all provided article links.
- **LINK-ONLY CONTENT (CRITICAL)**: The output content MUST only be based on the provided links. DO NOT fabricate or add information not explicitly found in the source articles.
- **SYNC WITH HUMANIZER-ZH-MAIN**: You MUST use the `Humanizer-zh-main` skill logic during the synthesis phase. Ensure the resulting text is contextually coherent, professional, and free of typical "AI patterns" (e.g., redundant connectors, exaggerated symbolism).
- Synthesize the core text into an intro, ~100-word body paragraphs, and an outro.

### 2. Image Extraction (AUTHENTIC ONLY)
- **CRITICAL IMAGE RULE:** You MUST extract the **authentic image URLs** directly from the provided links. **NEVER generate AI images.**

### 3. Generate and Format Layout
Write the article based on the synthesized content. The structure must strictly follow these rules:
- **Header Image**: Start with the version-specific header.
- **Differentiated Spacing (CRITICAL)**:
  - **Header Gap**: Use exactly one `<p style="margin:0;line-height:1;"><br></p>` between the header and the intro.
  - **Body Gaps**: Use exactly one `<p style="margin:0;line-height:2;"><br></p>` between EVERY other element (Intro -> Placeholder, Placeholder -> Body 1, Body 1 -> Image 1, etc.).
- **Standard Formatting (CRITICAL)**:
  - **Zero Margins**: The main container MUST use `padding: 0;` for zero side margins.
  - **No Image Effects**: All images MUST have NO `border-radius` and NO `box-shadow` (square corners, no shadows).
- **Paragraph Margins**: Use `margin: 0` for ALL paragraphs (`<p style="margin:0; ...">`) to ensure spacer symmetry.
- **Body Paragraphs**: 
  - Each body paragraph must be **approximately 100 words**.
  - **HIGHLIGHT FORMATTING**: Wrap key points in `<strong style="color: {COLOR};">...</strong>`.
- **Conclusion**: The last paragraph MUST guide users to comment, followed by an image and a final `spacer2`.

### 3. Apply the Layout Template
Construct TWO complete HTML articles using the template provided in `references/layout-template.md`.
- Replace `{CONTENT}` by concatenating the header, paragraph, and image blocks.
- **CRITICAL CONTAINER SPACING**: The main container section must have `margin: 0 auto;`, `padding: 0;` (no side buffer), and the inner `div` must have NO top margin.
- **CRITICAL TEXT SPACING**: The final HTML structure MUST be completely minified. DO NOT use newlines (`\n`) or spaces between tags (e.g. `> <`). 
- **Header Images**:
  - **Blue**: `https://mmbiz.qpic.cn/mmbiz_gif/iaw9nmmHthVcNNic7B4ibFg7Ribvt2o1pTCbfFlicw8No0Spt3ic3y9BDqzHdxZYF5zPNvB6DdZUMYU0T9Wkb0IroEhA/640?wx_fmt=gif`
  - **Green**: `https://mmbiz.qpic.cn/mmbiz_gif/lfic4S7GicgmD0Ot7hgOUpfofRwogPQoaTUSkOXicuTWeETNsjdZWSyQflaVfKqAo0zakN2K0ia7PBuxj8FfG4XHNQ/640?wx_fmt=gif`
Save these as temporary files locally.

### 4. Execute Watermark Removal (MANDATORY)
**YOU MUST PROCESS THE IMAGES BEFORE YOU DELIVER THE HTML.**
You must download the raw bytes of the authentic images you extracted, locate and remove any watermarks (i.e., 'it之家' / 'ithome') using the **Surgical v4 standard (Block ROI masking)**, and securely upload the cleaned images to the FreeImage CDN.
**DO NOT just pass raw URLs into the HTML. They will break in WeChat due to hotlinking and watermarks.**
Inject the newly generated secure CDN proxy URLs into your minified HTML drafts.

### 5. Deliver the Final Output
Deliver BOTH minified HTML outputs directly to the user in **separate messages**. Specify clearly which one is the "Blue Layout (#006fff)" and which one is the "Green Layout (#00b050)".
