import cv2
import easyocr
import requests
import numpy as np
import urllib3
import re
from bs4 import BeautifulSoup
import time
import json
import argparse
import os

urllib3.disable_warnings()

def get_images_from_ithome(url):
    if not url: return []
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        resp = requests.get(url, headers=headers, verify=False, timeout=15)
        resp.encoding = 'utf-8'
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        content_div = soup.find('div', id='paragraph')
        urls = []
        if content_div:
            imgs = content_div.find_all('img')
            for img in imgs:
                img_url = img.get('data-original') or img.get('src')
                if img_url:
                    if not img_url.startswith('http'):
                        img_url = 'https:' + img_url if img_url.startswith('//') else img_url
                    urls.append(img_url)
        return urls
    except:
        return []

def upload_image_to_freeimage(img_array):
    _, buffer = cv2.imencode('.jpg', img_array)
    url = "https://freeimage.host/api/1/upload"
    data = {"key": "6d207e02198a847aa98d0a2a901485a5", "action": "upload"}
    files = {"source": ("image.jpg", buffer.tobytes(), "image/jpeg")}
    
    for attempt in range(3):
        try:
            # Recreate files dict for each attempt to reset file pointer if any
            files_attempt = {"source": ("image.jpg", buffer.tobytes(), "image/jpeg")}
            response = requests.post(url, data=data, files=files_attempt, timeout=60)
            if response.status_code == 200:
                res_json = response.json()
                if res_json.get("status_code") == 200:
                    proxy_url = f"https://i0.wp.com/{res_json['image']['url'].replace('https://', '').replace('http://', '')}"
                    print(f"Uploaded securely: {proxy_url}")
                    return proxy_url
                else:
                    print(f"Upload error JSON on attempt {attempt+1}: {res_json}")
            else:
                print(f"HTTP Error {response.status_code} on attempt {attempt+1}: {response.text}")
        except Exception as e:
            print(f"Upload exception on attempt {attempt+1}: {e}")
        time.sleep(2)
    return None

def process_image(url):
    if not url: return None
    print(f"Processing: {url}")
    if '?x-bce-process' in url:
        url = url.split('?x-bce-process')[0]
        
    header_dl = {'User-Agent': 'Mozilla/5.0'}
    try:
        r = requests.get(url, headers=header_dl, verify=False, timeout=15)
        if r.status_code != 200: return None
    except:
        return None
        
    nparr = np.frombuffer(r.content, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if img is None: return None
        
    reader = easyocr.Reader(['ch_sim', 'en'], gpu=False, verbose=False)
    results = reader.readtext(img)
    
    mask = np.zeros(img.shape[:2], dtype=np.uint8)
    height, width = img.shape[:2]
    watermark_found = False
    
    # IT之家 Watermark Keywords
    keywords = ["ithome", "it之家", "www.ithome.com", "之家", "ithome.com"]
    
    for (bbox, text, prob) in results:
        text_lower = text.lower().replace(" ", "").replace(".", "")
        is_match = any(k.replace(".", "") in text_lower for k in keywords)
        
        (tl, tr, br, bl) = bbox
        box_min_x, box_max_x = int(min(tl[0], bl[0])), int(max(tr[0], br[0]))
        box_min_y, box_max_y = int(min(tl[1], tr[1])), int(max(bl[1], br[1]))
        
        if is_match:
            watermark_found = True
            # ROI Block Masking (v4 Surgical)
            if box_max_x > width * 0.6 and box_max_y > height * 0.6:
                # Bottom Right corner
                roi_x1, roi_y1 = max(0, box_min_x - 30), max(0, box_min_y - 80)
                roi_x2, roi_y2 = width, height
            elif box_max_x > width * 0.6 and box_min_y < height * 0.4:
                # Top Right corner
                roi_x1, roi_y1 = max(0, box_min_x - 30), 0
                roi_x2, roi_y2 = width, min(height, box_max_y + 80)
            else:
                roi_x1, roi_y1 = max(0, box_min_x - 30), max(0, box_min_y - 80)
                roi_x2, roi_y2 = min(width, box_max_x + 30), min(height, box_max_y + 30)
            
            cv2.rectangle(mask, (int(roi_x1), int(roi_y1)), (int(roi_x2), int(roi_y2)), 255, -1)
            
    if watermark_found:
        # v4 Surgical Dilation: circular and small
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        mask = cv2.dilate(mask, kernel, iterations=1)
        # Use NS for surgical blending
        img = cv2.inpaint(img, mask, inpaintRadius=3, flags=cv2.INPAINT_NS)
        
    return upload_image_to_freeimage(img)

def fetch_and_clean(item_data, dummy_img):
    url = item_data.get("url")
    idx = item_data.get("img_index", 0)
    img_urls = get_images_from_ithome(url)
    
    if img_urls and len(img_urls) > idx:
        raw_img = img_urls[idx]
        res = process_image(raw_img)
        if res:
            return res
            
    # fallback to index 0 or dummy
    if img_urls:
         res = process_image(img_urls[0])
         if res: return res
         
    return dummy_img

def build_highlighted_text(text, color):
    # Regex to replace {text} with <strong style="color: COLOR;">text</strong>
    return re.sub(r'\{([^}]+)\}', f'<strong style="color: {color};">\\1</strong>', text)

def main():
    parser = argparse.ArgumentParser(description="Generate SJTW WeChat HTML")
    parser.add_argument("--input_json", required=True)
    parser.add_argument("--output_blue", required=True)
    parser.add_argument("--output_green", required=True)
    args = parser.parse_args()

    with open(args.input_json, 'r', encoding='utf-8') as f:
        data = json.load(f)

    dummy_img = "https://i0.wp.com/upload.wikimedia.org/wikipedia/commons/c/ca/1x1.png"

    print("Fetching authentic images and scrubbing watermarks for SJTW layout...")

    for b in data.get("body", []):
         b["clean_image"] = fetch_and_clean(b, dummy_img)
         
    if "outro" in data:
         data["outro"]["clean_image"] = fetch_and_clean(data["outro"], dummy_img)
    
    # Process placeholder_image if it's a raw URL from the same sources
    placeholder_img = data.get("placeholder_image")
    if placeholder_img and placeholder_img.startswith("http"):
         # We need to scrub it too. Use the same logic as fetch_and_clean but for a single URL.
         # For simplicity, we can just treat it as a body item for the sake of the function.
         placeholder_img = fetch_and_clean({"url": placeholder_img, "img_index": 0}, dummy_img)
         data["placeholder_image"] = placeholder_img

    spacer1 = '<p style="margin:0;line-height:1;"><br></p>'
    spacer2 = '<p style="margin:0;line-height:2;"><br></p>'

    wrapper = f"""<section style="margin: 0 auto; max-width: 600px; padding: 0; font-family: 'Microsoft YaHei', 'PingFang SC', -apple-system, sans-serif; font-size: 15px; color: #3f3f3f; line-height: 2; letter-spacing: 1px; background-color: #ffffff; text-align: left;"><div>{{CONTENT}}</div></section>"""
    
    intro_template = f"""<p style="margin:0; text-align: left; word-wrap: break-word;">{{TEXT}}</p>"""

    blue_header = f"""<section style="text-align:center;"><img alt="酷换机新头图.gif" src="https://mmbiz.qpic.cn/mmbiz_gif/iaw9nmmHthVcNNic7B4ibFg7Ribvt2o1pTCbfFlicw8No0Spt3ic3y9BDqzHdxZYF5zPNvB6DdZUMYU0T9Wkb0IroEhA/640?wx_fmt=gif" style="vertical-align: baseline;width: 100%;box-sizing:border-box;max-width:100% !important;" draggable="false" data-ratio="0.20074349442379183" data-w="1076"/></section>{spacer1}"""
    green_header = f"""<section style="text-align:center;"><img src="https://mmbiz.qpic.cn/mmbiz_gif/lfic4S7GicgmD0Ot7hgOUpfofRwogPQoaTUSkOXicuTWeETNsjdZWSyQflaVfKqAo0zakN2K0ia7PBuxj8FfG4XHNQ/640?wx_fmt=gif" style="width:100%;vertical-align:baseline;box-sizing:border-box;max-width:100% !important;" draggable="false" data-ratio="0.20055710306406685" data-w="1077"/></section>{spacer1}"""

    blue_color = "#006fff"
    green_color = "#00b050"

    content_blue = blue_header + intro_template.replace("{TEXT}", data.get("intro", ""))
    content_green = green_header + intro_template.replace("{TEXT}", data.get("intro", ""))

    # Automated Placeholder: Use custom if provided, else clone 2nd body image
    placeholder_img = data.get("placeholder_image")
    if not placeholder_img and len(data.get("body", [])) >= 2:
        placeholder_img = data["body"][1]["clean_image"]
    
    if placeholder_img:
        placeholder_block = f"""{spacer2}<section style="margin: 0; text-align: center; line-height: 0;"><img src="{placeholder_img}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block;" alt="article image"/></section>"""
        content_blue += placeholder_block
        content_green += placeholder_block

    for b in data.get("body", []):
        img_url = b.get("clean_image", dummy_img)
        t_blue = b.get("text", "").replace("{", '<strong style="color: #006fff;">').replace("}", "</strong>")
        t_green = b.get("text", "").replace("{", '<strong style="color: #00b050;">').replace("}", "</strong>")
        
        content_blue += f"""{spacer2}<p style="margin:0; text-align: left; word-wrap: break-word;">{t_blue}</p>{spacer2}<section style="margin: 0; text-align: center; line-height: 0;"><img src="{img_url}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block;" alt="article image"/></section>"""
        content_green += f"""{spacer2}<p style="margin:0; text-align: left; word-wrap: break-word;">{t_green}</p>{spacer2}<section style="margin: 0; text-align: center; line-height: 0;"><img src="{img_url}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block;" alt="article image"/></section>"""

    if "outro" in data:
         outro_img = data["outro"].get("clean_image", dummy_img)
         t_blue = data["outro"].get("text", "").replace("{", '<strong style="color: #006fff;">').replace("}", "</strong>")
         t_green = data["outro"].get("text", "").replace("{", '<strong style="color: #00b050;">').replace("}", "</strong>")
         
         content_blue += f"""{spacer2}<p style="margin:0; text-align: left; word-wrap: break-word;">{t_blue}</p>{spacer2}<section style="margin: 0; text-align: center; line-height: 0;"><img src="{outro_img}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block;" alt="article image"/></section>{spacer2}"""
         content_green += f"""{spacer2}<p style="margin:0; text-align: left; word-wrap: break-word;">{t_green}</p>{spacer2}<section style="margin: 0; text-align: center; line-height: 0;"><img src="{outro_img}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block;" alt="article image"/></section>{spacer2}"""

    final_blue = wrapper.replace("{CONTENT}", content_blue)
    final_green = wrapper.replace("{CONTENT}", content_green)

    blue_html_minified = re.sub(r'>\s+<', '><', re.sub(r'\n\s*', ' ', final_blue)).strip()
    green_html_minified = re.sub(r'>\s+<', '><', re.sub(r'\n\s*', ' ', final_green)).strip()

    os.makedirs(os.path.dirname(args.output_blue), exist_ok=True)
    with open(args.output_blue, "w", encoding="utf-8") as f:
        f.write(blue_html_minified)

    os.makedirs(os.path.dirname(args.output_green), exist_ok=True)
    with open(args.output_green, "w", encoding="utf-8") as f:
        f.write(green_html_minified)

    print("SJTW HTML DRAFTS PREPARED SUCCESSFULLY.")

if __name__ == "__main__":
    main()
