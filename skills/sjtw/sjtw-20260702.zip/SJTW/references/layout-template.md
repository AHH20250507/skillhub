# WeChat Article Template

This template is used for WeChat article generation. The layout needs to be consistent and visually appealing, looking like a native WeChat Official Account post.

## Full Article Wrapper

This wrapper contains the generated content blocks. **CRITICAL**: The final output MUST be entirely minified onto a single line without any newline characters (`\n`) to prevent rendering gaps in WeChat.

```html
<section style="margin: 0 auto; max-width: 600px; padding: 0; font-family: 'Microsoft YaHei', 'PingFang SC', -apple-system, sans-serif; font-size: 15px; color: #3f3f3f; line-height: 2; letter-spacing: 1px; background-color: #ffffff; text-align: left;"><div>{CONTENT}</div></section>
```

## Header Image

EVERY article MUST start with this header image based on the version.

```html
<!-- Blue Layout Header -->
<section style="text-align:center;"><img alt="酷换机新头图.gif" src="https://mmbiz.qpic.cn/mmbiz_gif/iaw9nmmHthVcNNic7B4ibFg7Ribvt2o1pTCbfFlicw8No0Spt3ic3y9BDqzHdxZYF5zPNvB6DdZUMYU0T9Wkb0IroEhA/640?wx_fmt=gif" style="vertical-align: baseline;width: 100%;box-sizing:border-box;max-width:100% !important;" draggable="false" data-ratio="0.20074349442379183" data-w="1076"/></section><p><br></p>

<!-- Green Layout Header -->
<section style="text-align:center;"><img src="https://mmbiz.qpic.cn/mmbiz_gif/lfic4S7GicgmD0Ot7hgOUpfofRwogPQoaTUSkOXicuTWeETNsjdZWSyQflaVfKqAo0zakN2K0ia7PBuxj8FfG4XHNQ/640?wx_fmt=gif" style="width:100%;vertical-align:baseline;box-sizing:border-box;max-width:100% !important;" draggable="false" data-ratio="0.20055710306406685" data-w="1077"/></section><p><br></p>
```

## Content Block (Paragraph + Image)

For each paragraph in the article, use this block format with exactly one line break (`<p><br></p>`) spacing.

```html
<p style="margin-bottom: 15px; text-align: left; word-wrap: break-word;">{PARAGRAPH_TEXT_WITH_HIGHLIGHTS}</p><p><br></p><section style="margin: 0; text-align: center; line-height: 0;"><img src="{SECURE_CDN_IMAGE_URL}" style="width: 100%; max-width: 100%; height: auto; border-radius: 8px; box-sizing: border-box; display: inline-block; box-shadow: 0 2px 10px rgba(0,0,0,0.05);" alt="article image"/></section><p><br></p>
```
*(If the paragraph is the Introduction, omit the `<section><img...></section>` portion entirely).*

## Formatting Rules

1. **Highlights**: Important phrases inside `{PARAGRAPH_TEXT_WITH_HIGHLIGHTS}` must be wrapped in `<strong style="color: {COLOR};">...</strong>`.
2. **Authentic Images ONLY**: The `SECURE_CDN_IMAGE_URL` MUST be an original image extracted from the source link that has had its watermark removed via CV2 and uploaded to the FreeImage proxy (`i0.wp.com`).
3. **Typography Rule**: Ensure the `<section>` wrapper always strictly uses `font-family: 'Microsoft YaHei'...` with `font-size: 15px;`, `line-height: 2;` and `letter-spacing: 1px;`.
4. **Spacing Rule**: The final combined string must have all `> <` empty spaces and linebreaks `\n` removed via regex or string replacement before delivering to the user.
