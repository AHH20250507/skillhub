---
name: "mobile-news-deployer"
description: "Deploys an automated mobile phone news collector on Windows with customizable schedule: daily collection time, weekly summary day/time, and on-demand date-range merging. Invoke when user asks to deploy, install, set up, or configure the mobile news auto-collection system."
---

# Mobile News Deployer

This skill deploys a complete Windows-based automated mobile phone news collection system with user-configurable schedules.

## When to Invoke

- User asks to "deploy", "install", "set up", or "配置" the mobile news collector
- User asks to make the system run automatically every day and weekly summary on a specific day
- User wants to reinstall, migrate, or change schedule of the auto-collection system
- User asks to merge news for an arbitrary date range

## What It Does

1. Checks and installs Node.js LTS (if missing)
2. Creates `C:\MobileNews` directory structure
3. Writes the daily collector script: `mobile-news-collector-fixed.js`
4. Writes the weekly summary script: `weekly-summary.js`
5. Writes the date-range merge script: `merge-date-range.js`
6. Writes VBS launcher scripts to handle Chinese paths
7. **Asks the user for schedule preferences** (daily time, weekly day/time)
8. Creates Windows Task Scheduler tasks based on user preferences
9. Runs an initial test to verify everything works
10. Supports on-demand merging of any date range

## Deployment Steps

### Step 1: Check / Install Node.js

Run in PowerShell:

```powershell
where node
```

If `node` is not found, download and install Node.js LTS from https://nodejs.org/ (use the Windows `.msi` installer).

### Step 2: Create Directory

```powershell
New-Item -ItemType Directory -Force -Path "C:\MobileNews"
New-Item -ItemType Directory -Force -Path "C:\MobileNews\mobile-news"
```

### Step 3: Write Scripts to C:\MobileNews

Write the following files using `Write` tool:

- [mobile-news-collector-fixed.js](file:///C:/MobileNews/mobile-news-collector-fixed.js) — daily RSS collector from IT之家, filters mobile news (last 24h), excludes car-related keywords, generates HTML
- [weekly-summary.js](file:///C:/MobileNews/weekly-summary.js) — aggregates last Saturday to Friday, deduplicates, sorts by brand tags, generates grouped HTML (same style as daily report) with checkboxes and drag-to-sort
- [merge-date-range.js](file:///C:/MobileNews/merge-date-range.js) — merges arbitrary date range with same output features
- [run-collector.vbs](file:///C:/MobileNews/run-collector.vbs) — VBS launcher for daily collector
- [run-weekly-summary.vbs](file:///C:/MobileNews/run-weekly-summary.vbs) — VBS launcher for weekly summary

Script contents must match the current working versions in `C:\MobileNews`. If they are missing or outdated, regenerate them based on the project templates.

### Step 4: Ask User for Schedule Preferences

Use `AskUserQuestion` to ask the user:

1. **Daily collection time**: "每天几点执行资讯收集？" (default: 09:00)
2. **Weekly summary day and time**: "每周几几点执行资讯整合？" (default: 周五 09:10)

Accept inputs in formats like:
- Time: `09:00`, `14:30`, `21:15`
- Day: `周五`, `星期五`, `FRI`, `Friday`

If user provides no preference, use defaults:
- Daily: `09:00`
- Weekly: `周五 09:10`

### Step 5: Create Scheduled Tasks

Convert user day input to `schtasks` day code:

| User Input | schtasks code |
|------------|---------------|
| 周一 / MON | MON |
| 周二 / TUE | TUE |
| 周三 / WED | WED |
| 周四 / THU | THU |
| 周五 / FRI | FRI |
| 周六 / SAT | SAT |
| 周日 / SUN | SUN |

Run in administrator PowerShell:

```powershell
schtasks /create /tn "MobileNewsCollector" /tr "wscript C:\MobileNews\run-collector.vbs" /sc daily /st <DAILY_TIME> /f
schtasks /create /tn "MobileNewsWeekly" /tr "wscript C:\MobileNews\run-weekly-summary.vbs" /sc weekly /d <WEEKLY_DAY> /st <WEEKLY_TIME> /f
```

Replace `<DAILY_TIME>`, `<WEEKLY_DAY>`, `<WEEKLY_TIME>` with user preferences.

### Step 6: Test

Run the VBS launchers manually and verify HTML files are generated in `C:\MobileNews\mobile-news\`:

```powershell
wscript C:\MobileNews\run-collector.vbs
wscript C:\MobileNews\run-weekly-summary.vbs
```

## On-Demand Date-Range Merge

If the user asks to merge news for a specific date range (e.g., "合并 6月13日到6月18日的资讯"), run:

```powershell
& "C:\Program Files\nodejs\node.exe" "C:\MobileNews\merge-date-range.js" "YYYY-MM-DD" "YYYY-MM-DD"
```

Example:

```powershell
& "C:\Program Files\nodejs\node.exe" "C:\MobileNews\merge-date-range.js" "2026-06-13" "2026-06-18"
```

Output file:

```
C:\MobileNews\mobile-news\merged-news-YYYY-MM-DD-to-YYYY-MM-DD.html
```

## Output Files

- Daily reports: `C:\MobileNews\mobile-news\mobile-news-YYYY-MM-DD.html`
- Weekly summary: `C:\MobileNews\mobile-news\weekly-summary-YYYY-MM-DD.html`
- Custom merge: `C:\MobileNews\mobile-news\merged-news-YYYY-MM-DD-to-YYYY-MM-DD.html`

## Notes

- All scripts use absolute path `C:\MobileNews` as base directory to avoid Chinese path encoding issues
- VBS wrappers are used instead of `.bat` or `.ps1` because Windows Task Scheduler handles Chinese paths better with WScript
- The daily collector fetches "past 24 hours" of news, not calendar-day news
- Weekly summary collects from last Saturday to the configured weekly summary day
