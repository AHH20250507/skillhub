#!/usr/bin/env node
// 飞书→IMA知识库 智能同步脚本 v3 (Skill版本)
// 用法: node sync.js [命令] [选项]
// 命令: check / sync / sync-one / status / add-doc / remove-doc / setup

const https = require('https');
const http = require('http');
const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');
const readline = require('readline');

// ========== 路径配置 ==========
const SKILL_DIR = path.resolve(__dirname, '..');
const WORKSPACE_DIR = process.env.WORKSPACE_DIR || path.resolve(SKILL_DIR, '../../workspace');
const CONFIG_FILE = path.join(SKILL_DIR, 'config.json');
const WATCHLIST_FILE = path.join(SKILL_DIR, 'data', 'doc_watchlist.json');
const STATE_FILE = path.join(WORKSPACE_DIR, 'kb_sync_state.json');
const LOG_FILE = path.join(WORKSPACE_DIR, 'monitor_log.txt');
const EMAIL_CONFIG_FILE = path.join(__dirname, 'email_config.json');

const IMA_MAX_CONTENT = 500000;

// ========== 配置加载 ==========
function loadConfig() {
  if (!fs.existsSync(CONFIG_FILE)) {
    console.error('❌ 配置文件不存在: ' + CONFIG_FILE);
    console.error('请先运行: node sync.js setup');
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
}

function loadWatchlist() {
  if (!fs.existsSync(WATCHLIST_FILE)) {
    console.error('❌ 监控列表不存在: ' + WATCHLIST_FILE);
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(WATCHLIST_FILE, 'utf8'));
}

// ========== 工具函数 ==========
function log(msg) {
  const ts = new Date().toISOString();
  const line = '[' + ts + '] ' + msg;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch(e) {}
}

function httpRequest(url, opts, binary) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, opts, res => {
      if (binary) {
        const chunks = [];
        res.on('data', chunk => chunks.push(chunk));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
      } else {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: data }));
      }
      res.on('error', reject);
    });
    req.on('error', reject);
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

function httpGet(token, apiPath, binary) {
  const url = 'https://open.feishu.cn/open-apis/' + apiPath;
  const opts = { method: 'GET', headers: { 'Authorization': 'Bearer ' + token } };
  return httpRequest(url, opts, binary);
}

function getIMACreds(config) {
  // 方式1: 使用 config 中的 ima_client_id / ima_api_key
  if (config.ima_client_id && config.ima_api_key) {
    return { client_id: config.ima_client_id, api_key: config.ima_api_key };
  }

  // 方式2: 尝试本地代理 (AUTH_GATEWAY_PORT)
  const gwPort = process.env.AUTH_GATEWAY_PORT || '19000';
  try {
    const ps1Path = path.join(__dirname, 'get-ima-proxy-creds.ps1');
    if (fs.existsSync(ps1Path)) {
      const proxyRes = execSync(
        'powershell.exe -NoProfile -Command "& \'' + ps1Path + '\' ' + gwPort + '"',
        { encoding: 'utf8', timeout: 12000 }
      ).trim();
      const resp = JSON.parse(proxyRes);
      if (resp.ret === 0 && resp.data && resp.data.resp && resp.data.resp.data && resp.data.resp.data.access_token) {
        return {
          client_id: resp.data.resp.data.extra_data.client_id,
          api_key: resp.data.resp.data.access_token,
        };
      }
    }
  } catch (e) { /* fallback below */ }

  // 方式3: QClaw内置 get-token.ps1
  try {
    const ps = "& 'C:\\Program Files\\QClaw\\v0.2.27.560\\resources\\openclaw\\config\\skills\\ima\\get-token.ps1' | ConvertFrom-Json | ConvertTo-Json -Compress";
    const result = execSync('powershell.exe -NoProfile -Command "' + ps + '"', { encoding: 'utf8' }).trim();
    return JSON.parse(result);
  } catch (e) {
    log('IMA凭证获取失败: ' + e.message);
    return null;
  }
}

function imaAPI(creds, endpoint, data) {
  return httpRequest('https://ima.qq.com' + endpoint, {
    method: 'POST',
    headers: {
      'ima-openapi-clientid': creds.client_id,
      'ima-openapi-apikey': creds.api_key,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(data),
  });
}

async function getFeishuToken(config) {
  const res = await httpRequest('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: config.feishu_app_id, app_secret: config.feishu_app_secret })
  });
  return JSON.parse(res.body).tenant_access_token;
}

// ========== 文档内容获取 ==========

async function getDocxRevision(token, docToken) {
  try {
    const res = await httpGet(token, 'docx/v1/documents/' + docToken);
    const d = JSON.parse(res.body);
    return (d.data && d.data.document && d.data.document.revision_id) || null;
  } catch (e) { return null; }
}

async function getDocxContent(token, docToken) {
  try {
    const res = await httpGet(token, 'docx/v1/documents/' + docToken + '/raw_content');
    const d = JSON.parse(res.body);
    return (d.data && d.data.content) || '';
  } catch (e) { return ''; }
}

async function getWikiNodeInfo(token, wikiToken) {
  try {
    const res = await httpGet(token, 'wiki/v2/spaces/get_node?token=' + wikiToken);
    const d = JSON.parse(res.body);
    if (d.code !== 0 || !d.data || !d.data.node) return null;
    return {
      obj_token: d.data.node.obj_token,
      obj_type: d.data.node.obj_type,
      space_id: d.data.node.space_id,
      obj_edit_time: d.data.node.obj_edit_time,
    };
  } catch (e) { return null; }
}

async function downloadFileDoc(token, objToken) {
  try {
    const res = await httpGet(token, 'drive/v1/files/' + objToken + '/download', true);
    if (res.status === 200 && Buffer.isBuffer(res.body)) return res.body;
    return null;
  } catch (e) { return null; }
}

function docxToMarkdown(docxBuffer) {
  const tmpDocx = path.join(WORKSPACE_DIR, '_tmp_sync.docx');
  const tmpMd = path.join(WORKSPACE_DIR, '_tmp_sync.md');
  try {
    fs.writeFileSync(tmpDocx, docxBuffer);
    const d = tmpDocx.replace(/\\/g, '/');
    const m = tmpMd.replace(/\\/g, '/');
    const cmd = 'node -e "const ma=require(\'mammoth\');ma.convertToMarkdown({path:\'' + d + '\'}).then(r=>{require(\'fs\').writeFileSync(\'' + m + '\',r.value);console.log(r.value.length)}).catch(e=>console.error(e))"';
    execSync(cmd, { cwd: WORKSPACE_DIR, encoding: 'utf-8', timeout: 60000 });
    return fs.readFileSync(tmpMd, 'utf-8');
  } catch (e) {
    log('DOCX转换失败: ' + e.message);
    return '';
  } finally {
    try { fs.unlinkSync(tmpDocx); } catch {}
    try { fs.unlinkSync(tmpMd); } catch {}
  }
}

async function getDocRevision(token, doc) {
  if (doc.obj_type === 'file' && doc.wiki_token) {
    const info = await getWikiNodeInfo(token, doc.wiki_token);
    return (info && info.obj_edit_time) || null;
  } else {
    return await getDocxRevision(token, doc.docToken);
  }
}

async function getDocContent(token, doc) {
  if (doc.obj_type === 'file' && doc.wiki_token) {
    log('  获取wiki节点信息: ' + doc.wiki_token);
    const info = await getWikiNodeInfo(token, doc.wiki_token);
    if (!info) { log('  获取wiki节点失败'); return ''; }
    log('  下载DOCX: obj_token=' + info.obj_token);
    const docxBuffer = await downloadFileDoc(token, info.obj_token);
    if (!docxBuffer) { log('  下载DOCX失败'); return ''; }
    log('  转换DOCX→Markdown (' + docxBuffer.length + ' bytes)');
    const md = docxToMarkdown(docxBuffer);
    if (!md) { log('  转换失败'); return ''; }
    log('  转换成功: ' + md.length + ' chars');
    return md.length > IMA_MAX_CONTENT ? md.substring(0, IMA_MAX_CONTENT) : md;
  } else {
    return await getDocxContent(token, doc.docToken);
  }
}

// ========== IMA 导入 ==========

async function importToIMA(creds, kbInfo, folderKey, title, content) {
  try {
    const folder = kbInfo.folders ? (kbInfo.folders[folderKey] || kbInfo.folders._root_ || {}) : {};
    const safeContent = content.length > IMA_MAX_CONTENT ? content.substring(0, IMA_MAX_CONTENT) : content;

    const res1 = await imaAPI(creds, '/openapi/note/v1/import_doc', {
      title: title, content: safeContent, content_format: 1,
    });
    const d1 = JSON.parse(res1.body);
    if (d1.code !== 0) return { success: false, error: 'import_doc: ' + d1.msg };

    const noteId = d1.data && d1.data.note_id;
    if (!noteId) return { success: false, error: 'note_id not found' };

    const res2 = await imaAPI(creds, '/openapi/wiki/v1/add_knowledge', {
      media_type: 11, title: title,
      knowledge_base_id: kbInfo.kb_id,
      folder_id: folder.folder_id || undefined,
      note_info: { content_id: noteId },
    });
    const d2 = JSON.parse(res2.body);
    if (d2.code !== 0) return { success: false, error: 'add_knowledge: ' + d2.msg };

    return { success: true, note_id: noteId, media_id: (d2.data && d2.data.media_id) };
  } catch (e) { return { success: false, error: e.message }; }
}

// ========== 状态管理 ==========

function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { return { knowledge_bases: {}, last_updated: null }; }
}

function saveState(state) {
  state.last_updated = new Date().toISOString();
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

function mergeWatchlistToState(state, watchlist) {
  for (const [kbName, wlKb] of Object.entries(watchlist.knowledge_bases || {})) {
    if (!state.knowledge_bases[kbName]) {
      state.knowledge_bases[kbName] = JSON.parse(JSON.stringify(wlKb));
      const kb = state.knowledge_bases[kbName];
      if (kb.folders) {
        for (const folder of Object.values(kb.folders)) {
          for (const doc of Object.values(folder.docs || {})) { doc.revision = null; }
        }
      } else if (kb.docs) {
        for (const doc of Object.values(kb.docs)) { doc.revision = null; }
      }
    }
  }
}

async function sendEmail(config, subject, body) {
  try {
    let emailCfg;
    if (fs.existsSync(EMAIL_CONFIG_FILE)) {
      emailCfg = JSON.parse(fs.readFileSync(EMAIL_CONFIG_FILE, 'utf8'));
    } else {
      log('email_config.json 不存在，跳过邮件通知');
      return false;
    }
    const nodemailer = require(path.join(SKILL_DIR, 'node_modules', 'nodemailer'));
    const transporter = nodemailer.createTransport({
      host: emailCfg.smtp,
      port: emailCfg.port,
      secure: emailCfg.ssl,
      auth: { user: emailCfg.from, pass: emailCfg.password },
    });
    const emailTo = config.email_to || emailCfg.from;
    const info = await transporter.sendMail({
      from: emailCfg.from, to: emailTo, subject: subject, text: body,
    });
    log('邮件已发送: ' + (info.messageId || info.response));
    return true;
  } catch (e) {
    log('邮件发送失败: ' + e.message);
    return false;
  }
}

function updateRevision(state, kbName, folderKey, docToken, newRev) {
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) return false;
  if (kbInfo.folders) {
    const folder = kbInfo.folders[folderKey];
    if (folder && folder.docs && folder.docs[docToken]) { folder.docs[docToken].revision = newRev; return true; }
    if (folderKey === '_root_' && kbInfo.folders._root_ && kbInfo.folders._root_.docs && kbInfo.folders._root_.docs[docToken]) { kbInfo.folders._root_.docs[docToken].revision = newRev; return true; }
  } else if (kbInfo.docs && kbInfo.docs[docToken]) { kbInfo.docs[docToken].revision = newRev; return true; }
  return false;
}

function collectAllDocs(state) {
  const docs = [];
  for (const [kbName, kbInfo] of Object.entries(state.knowledge_bases)) {
    if (kbInfo.folders) {
      for (const [folderKey, folderInfo] of Object.entries(kbInfo.folders)) {
        for (const [docToken, docInfo] of Object.entries(folderInfo.docs || {})) {
          docs.push({ docToken, ...docInfo, kbName, folderKey, folderName: folderKey === '_root_' ? '根目录' : folderKey });
        }
      }
    } else if (kbInfo.docs) {
      for (const [docToken, docInfo] of Object.entries(kbInfo.docs)) {
        docs.push({ docToken, ...docInfo, kbName, folderKey: kbInfo.folder_name, folderName: kbInfo.folder_name });
      }
    }
  }
  return docs;
}

// ========== 命令实现 ==========

async function cmdStatus() {
  const state = loadState();
  const watchlist = loadWatchlist();
  mergeWatchlistToState(state, watchlist);
  const docs = collectAllDocs(state);
  const output = {
    total_docs: docs.length,
    knowledge_bases: Object.keys(state.knowledge_bases),
    last_updated: state.last_updated,
    docs: docs.map(d => ({ title: d.title, kb: d.kbName, folder: d.folderName, type: d.obj_type || 'docx', rev: d.revision, token: d.docToken }))
  };
  console.log(JSON.stringify(output, null, 2));
}

async function cmdCheck() {
  const config = loadConfig();
  const state = loadState();
  const watchlist = loadWatchlist();
  mergeWatchlistToState(state, watchlist);
  const feishuToken = await getFeishuToken(config);
  const docs = collectAllDocs(state);
  const changes = [];
  for (const doc of docs) {
    const newRev = await getDocRevision(feishuToken, doc);
    if (newRev !== null && newRev !== doc.revision) {
      changes.push({ title: doc.title, oldRev: doc.revision, newRev: newRev, kb: doc.kbName, folder: doc.folderName, token: doc.docToken, type: doc.obj_type || 'docx' });
    }
  }
  console.log(JSON.stringify({ total: docs.length, changed: changes.length, changes: changes }, null, 2));
}

async function cmdSync(skipEmail) {
  log('===== 开始同步检查 =====');
  const config = loadConfig();
  const state = loadState();
  const watchlist = loadWatchlist();
  mergeWatchlistToState(state, watchlist);
  const feishuToken = await getFeishuToken(config);
  const imaCreds = getIMACreds(config);
  if (!imaCreds) { log('❌ 无法获取IMA凭证'); process.exit(1); }
  const docs = collectAllDocs(state);
  const updates = [];

  for (const doc of docs) {
    const newRev = await getDocRevision(feishuToken, doc);
    if (newRev !== null && newRev !== doc.revision) {
      log('📝 更新: ' + doc.title + ' (' + doc.revision + ' → ' + newRev + ')');
      updates.push({ ...doc, newRev: newRev });
    } else {
      log('✓ 无变化: ' + doc.title + ' (rev=' + (newRev || doc.revision) + ')');
    }
  }

  const kbStats = {};
  for (const doc of docs) { kbStats[doc.kbName] = (kbStats[doc.kbName] || 0) + 1; }
  log('===== 检查完毕: 共' + docs.length + '篇 | 更新' + updates.length + '篇 =====');

  if (updates.length === 0) {
    log('无更新');
    console.log(JSON.stringify({ synced: 0, message: '无更新' }));
    return;
  }

  const results = [];
  for (const u of updates) {
    log('同步: ' + u.title + ' (type=' + (u.obj_type || 'docx') + ')');
    const content = await getDocContent(feishuToken, u);
    if (!content) { results.push({ title: u.title, synced: false, error: '获取文档内容为空' }); continue; }
    const kbInfo = state.knowledge_bases[u.kbName];
    const result = await importToIMA(imaCreds, kbInfo, u.folderKey, u.title, content);
    if (result.success) {
      log('✓ 同步成功: ' + u.title + ' (note_id=' + result.note_id + ')');
      updateRevision(state, u.kbName, u.folderKey, u.docToken, u.newRev);
      results.push({ title: u.title, synced: true, note_id: result.note_id, oldRev: u.revision, newRev: u.newRev });
    } else {
      log('✗ 同步失败: ' + u.title + ' - ' + result.error);
      results.push({ title: u.title, synced: false, error: result.error });
    }
    await wait(2000);
  }

  saveState(state);

  const successCount = results.filter(r => r.synced).length;
  const failCount = results.filter(r => !r.synced).length;

  if (!skipEmail && (successCount > 0 || failCount > 0)) {
    const lines = [
      '📄 飞书文档同步报告',
      '时间：' + new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' }),
      '结果：✅' + successCount + '成功' + (failCount > 0 ? ' ❌' + failCount + '失败' : ''),
      ''
    ];
    results.forEach(r => {
      lines.push((r.synced ? '✅' : '❌') + ' ' + r.title + (r.oldRev ? ' (' + r.oldRev + '→' + r.newRev + ')' : ''));
      if (!r.synced) lines.push('   原因：' + r.error);
    });
    sendEmail(config, '飞书文档同步报告 - ' + new Date().toISOString().slice(0,10), lines.join('\n'));
  }

  console.log(JSON.stringify({ synced: successCount, failed: failCount, results: results }, null, 2));
}

async function cmdSyncOne(docToken) {
  const config = loadConfig();
  const state = loadState();
  const watchlist = loadWatchlist();
  mergeWatchlistToState(state, watchlist);
  const feishuToken = await getFeishuToken(config);
  const imaCreds = getIMACreds(config);
  if (!imaCreds) { console.log(JSON.stringify({ error: '无法获取IMA凭证' })); return; }
  const docs = collectAllDocs(state);
  const doc = docs.find(d => d.docToken === docToken);
  if (!doc) { console.log(JSON.stringify({ error: '文档 ' + docToken + ' 不在监控列表中' })); return; }

  log('强制同步: ' + doc.title);
  const content = await getDocContent(feishuToken, doc);
  if (!content) { console.log(JSON.stringify({ error: '获取文档内容为空' })); return; }

  const kbInfo = state.knowledge_bases[doc.kbName];
  const result = await importToIMA(imaCreds, kbInfo, doc.folderKey, doc.title, content);
  if (result.success) {
    const newRev = await getDocRevision(feishuToken, doc);
    if (newRev) updateRevision(state, doc.kbName, doc.folderKey, doc.docToken, newRev);
    saveState(state);
    console.log(JSON.stringify({ success: true, note_id: result.note_id, media_id: result.media_id }));
  } else {
    console.log(JSON.stringify({ success: false, error: result.error }));
  }
}

async function cmdAddDoc(kbName, folderKey, docToken, title, wikiToken, objType) {
  const config = loadConfig();
  const state = loadState();
  const watchlist = loadWatchlist();
  mergeWatchlistToState(state, watchlist);
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) { console.log(JSON.stringify({ error: '知识库 "' + kbName + '" 不存在' })); return; }

  const feishuToken = await getFeishuToken(config);
  let revision;
  let docObjType = objType || 'docx';
  let docWikiToken = wikiToken || null;

  if (docWikiToken) {
    const info = await getWikiNodeInfo(feishuToken, docWikiToken);
    revision = (info && info.obj_edit_time) || null;
    docObjType = (info && info.obj_type) || 'file';
  } else {
    revision = await getDocxRevision(feishuToken, docToken);
  }

  const docEntry = { title: title, revision: revision };
  if (docWikiToken) docEntry.wiki_token = docWikiToken;
  if (docObjType !== 'docx') docEntry.obj_type = docObjType;

  if (kbInfo.folders) {
    const folder = kbInfo.folders[folderKey];
    if (!folder) { console.log(JSON.stringify({ error: '文件夹 "' + folderKey + '" 不存在' })); return; }
    if (!folder.docs) folder.docs = {};
    folder.docs[docToken] = docEntry;
  } else if (kbInfo.docs) {
    kbInfo.docs[docToken] = docEntry;
  }

  saveState(state);
  console.log(JSON.stringify({ success: true, title: title, revision: revision, kb: kbName, folder: folderKey, type: docObjType }));
}

async function cmdRemoveDoc(kbName, folderKey, docToken) {
  const state = loadState();
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) { console.log(JSON.stringify({ error: '知识库 "' + kbName + '" 不存在' })); return; }
  let removed = false;
  if (kbInfo.folders && kbInfo.folders[folderKey] && kbInfo.folders[folderKey].docs && kbInfo.folders[folderKey].docs[docToken]) {
    delete kbInfo.folders[folderKey].docs[docToken]; removed = true;
  } else if (kbInfo.docs && kbInfo.docs[docToken]) {
    delete kbInfo.docs[docToken]; removed = true;
  }
  if (removed) { saveState(state); console.log(JSON.stringify({ success: true })); }
  else { console.log(JSON.stringify({ error: '文档不存在' })); }
}

// ========== 首次配置向导 ==========
async function cmdSetup() {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const question = (q) => new Promise(r => rl.question(q, r));

  console.log('=== 飞书→IMA同步 首次配置 ===\n');

  let existing = {};
  if (fs.existsSync(CONFIG_FILE)) {
    existing = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
    console.log('检测到已有配置，将使用当前值作为默认值。\n');
  }

  const feishu_app_id = (await question('飞书 App ID [' + (existing.feishu_app_id || '') + ']: ')) || existing.feishu_app_id || '';
  const feishu_app_secret = (await question('飞书 App Secret [' + (existing.feishu_app_secret ? '***' : '') + ']: ')) || existing.feishu_app_secret || '';
  const ima_client_id = (await question('IMA Client ID [' + (existing.ima_client_id || '留空则自动获取') + ']: ')) || existing.ima_client_id || '';
  const ima_api_key = (await question('IMA API Key [' + (existing.ima_api_key ? '***' : '留空则自动获取') + ']: ')) || existing.ima_api_key || '';
  const email_to = (await question('邮件通知收件人 [' + (existing.email_to || '') + ']: ')) || existing.email_to || '';

  const config = { feishu_app_id: feishu_app_id, feishu_app_secret: feishu_app_secret, ima_client_id: ima_client_id, ima_api_key: ima_api_key, email_to: email_to };
  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
  console.log('\n✅ 配置已保存到: ' + CONFIG_FILE);

  if (!fs.existsSync(EMAIL_CONFIG_FILE)) {
    console.log('\n--- 邮件发送配置 ---');
    const email_from = (await question('发件邮箱 [' + email_to + ']: ')) || email_to;
    const email_password = await question('SMTP授权码: ');
    const email_smtp = (await question('SMTP服务器 [smtp.qq.com]: ')) || 'smtp.qq.com';
    const email_port = (await question('端口 [465]: ')) || '465';

    const emailCfg = {
      from: email_from, password: email_password,
      smtp: email_smtp, port: parseInt(email_port), ssl: parseInt(email_port) === 465
    };
    fs.writeFileSync(EMAIL_CONFIG_FILE, JSON.stringify(emailCfg, null, 2), 'utf8');
    console.log('✅ 邮件配置已保存到: ' + EMAIL_CONFIG_FILE);
  } else {
    console.log('\n邮件配置已存在: ' + EMAIL_CONFIG_FILE + '（如需修改请直接编辑）');
  }

  rl.close();
  console.log('\n🎉 配置完成！可以运行: node sync.js sync');
}

// ========== 主入口 ==========
async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0] || 'sync';
  const getArg = (name) => { const i = args.indexOf(name); return i >= 0 && i + 1 < args.length ? args[i + 1] : null; };

  switch (cmd) {
    case 'status': await cmdStatus(); break;
    case 'check': await cmdCheck(); break;
    case 'sync': await cmdSync(args.includes('--no-email')); break;
    case 'sync-one': {
      const token = getArg('--doc-token');
      if (!token) { console.log(JSON.stringify({ error: '需要 --doc-token 参数' })); process.exit(1); }
      await cmdSyncOne(token); break;
    }
    case 'add-doc': {
      const aKb = getArg('--kb-name'), aFolder = getArg('--folder-key'), aToken = getArg('--doc-token'), aTitle = getArg('--title'), aWiki = getArg('--wiki-token'), aType = getArg('--obj-type');
      if (!aKb || !aFolder || !aToken || !aTitle) { console.log(JSON.stringify({ error: '需要 --kb-name --folder-key --doc-token --title' })); process.exit(1); }
      await cmdAddDoc(aKb, aFolder, aToken, aTitle, aWiki, aType); break;
    }
    case 'remove-doc': {
      const rKb = getArg('--kb-name'), rFolder = getArg('--folder-key'), rToken = getArg('--doc-token');
      if (!rKb || !rFolder || !rToken) { console.log(JSON.stringify({ error: '需要 --kb-name --folder-key --doc-token' })); process.exit(1); }
      await cmdRemoveDoc(rKb, rFolder, rToken); break;
    }
    case 'setup': await cmdSetup(); break;
    default:
      console.log('用法: node sync.js [status|check|sync|sync-one|add-doc|remove-doc|setup] [选项]');
      process.exit(1);
  }
}

main().catch(e => { console.error(JSON.stringify({ error: e.message })); process.exit(1); });
