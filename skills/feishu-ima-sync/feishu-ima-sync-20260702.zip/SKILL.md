---
name: feishu-ima-sync
description: 飞书文档自动同步到IMA知识库。支持检查文档更新、自动同步、邮件通知、文档管理。当用户提到飞书文档同步、知识库更新、IMA同步、检查飞书更新时触发。
---

# 飞书→IMA知识库 智能同步

自动监控飞书文档更新，同步到IMA知识库，并发邮件通知。

## 首次配置

### 1. 运行配置向导

```powershell
node scripts/sync.js setup
```

交互式输入以下信息：
- **飞书 App ID / App Secret** — 飞书开放平台应用凭证
- **IMA Client ID / API Key** — IMA开放平台凭证（留空则自动通过QClaw获取）
- **邮件收件人** — 同步报告接收邮箱
- **SMTP配置** — 发件邮箱、授权码、服务器、端口

配置保存在：
- `config.json` — 飞书/IMA凭证 + 收件人
- `scripts/email_config.json` — SMTP邮件配置

### 2. 自定义监控文档列表

编辑 `data/doc_watchlist.json`，按格式添加需要监控的飞书文档。

## 命令用法

```powershell
# 查看同步状态
node scripts/sync.js status

# 检查是否有更新（不同步）
node scripts/sync.js check

# 检查并同步更新
node scripts/sync.js sync

# 同步但不发邮件
node scripts/sync.js sync --no-email

# 强制同步单篇文档
node scripts/sync.js sync-one --doc-token <TOKEN>

# 添加监控文档
node scripts/sync.js add-doc --kb-name "知识库名" --folder-key "文件夹名" --doc-token <TOKEN> --title "标题"

# 移除监控文档
node scripts/sync.js remove-doc --kb-name "知识库名" --folder-key "文件夹名" --doc-token <TOKEN>

# 重新配置
node scripts/sync.js setup
```

## 同步流程

1. 获取飞书 tenant_access_token
2. 遍历监控文档，比较 revision_id
3. 有更新 → 获取文档内容
   - docx类型：通过 raw_content API 获取
   - file类型：下载DOCX → 转Markdown（需mammoth）
4. `import_doc` → 创建IMA笔记
5. `add_knowledge` → 关联到知识库
6. 更新状态文件中的 revision
7. 发邮件通知

## 定时任务

可设置 Windows 任务计划程序每日定时运行：

```powershell
# 创建每日17:00运行的任务
schtasks /create /tn "FeishuIMASync" /tr "node <skill路径>/scripts/sync.js sync" /sc daily /st 17:00
```

## 关键约束

- **import_doc 创建笔记类型**（media_type=11），AI可检索
- **不要用 import_urls**，创建网址类型无法被AI检索
- IMA API 不支持删除/覆盖，只能追加
- IMA API quota 每日 16:00-17:00 重置
- 内容超过 500000 字符会自动截断

## 文件说明

| 文件 | 用途 |
|------|------|
| `scripts/sync.js` | 主同步脚本 |
| `data/doc_watchlist.json` | 监控文档列表模板 |
| `scripts/email_config.json.example` | 邮件配置模板 |
| `config.json` | 运行时生成的凭证配置（gitignore） |
| `scripts/email_config.json` | 运行时生成的邮件配置（gitignore） |

## 依赖

- Node.js 14+
- nodemailer（已包含在 node_modules 中）
- mammoth（用于DOCX→Markdown转换，file类型文档需要）
