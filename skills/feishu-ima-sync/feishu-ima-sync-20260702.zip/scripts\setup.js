#!/usr/bin/env node
// 飞书→IMA同步 Skill 首次配置向导

const fs = require('fs');
const path = require('path');
const readline = require('readline');

const SKILL_DIR = path.resolve(__dirname, '..');
const CONFIG_FILE = path.join(SKILL_DIR, 'config.json');
const EMAIL_CONFIG_FILE = path.join(SKILL_DIR, 'email_config.json');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function question(prompt) {
  return new Promise(resolve => {
    rl.question(prompt, answer => resolve(answer.trim()));
  });
}

async function main() {
  console.log('========================================');
  console.log('  飞书→IMA 同步 Skill 配置向导');
  console.log('========================================\n');

  // 检查是否已配置
  if (fs.existsSync(CONFIG_FILE)) {
    const overwrite = await question('检测到已存在 config.json，是否覆盖？(y/N): ');
    if (overwrite.toLowerCase() !== 'y') {
      console.log('已取消配置');
      rl.close();
      return;
    }
  }

  console.log('\n>>> 飞书应用配置 <<<');
  console.log('请在飞书开放平台获取 App ID 和 App Secret');
  console.log('地址: https://open.feishu.cn/app\n');

  const feishuAppId = await question('飞书 App ID [默认: cli_a9668450f3781cd5]: ') || 'cli_a9668450f3781cd5';
  const feishuAppSecret = await question('飞书 App Secret: ');

  if (!feishuAppSecret) {
    console.error('错误: App Secret 不能为空');
    rl.close();
    return;
  }

  console.log('\n>>> IMA 知识库配置 <<<');
  console.log('请在 IMA 开放平台获取 client_id 和 api_key');
  console.log('地址: https://ima.qq.com/openapi\n');

  const imaClientId = await question('IMA Client ID: ');
  const imaApiKey = await question('IMA API Key (access_token): ');

  if (!imaClientId || !imaApiKey) {
    console.error('错误: IMA 配置不完整');
    rl.close();
    return;
  }

  console.log('\n>>> 邮件通知配置 (可选) <<<');
  console.log('用于同步结果邮件通知，可跳过\n');

  const emailFrom = await question('发件邮箱 [默认: 2101006618@qq.com]: ') || '2101006618@qq.com';
  const emailPassword = await question('SMTP 授权码 (QQ邮箱为SMTP授权码): ');
  const emailTo = await question('收件邮箱 [默认同发件邮箱]: ') || emailFrom;

  // 生成 config.json
  const config = {
    feishu_app_id: feishuAppId,
    feishu_app_secret: feishuAppSecret,
    ima_client_id: imaClientId,
    ima_api_key: imaApiKey,
    email_to: emailTo
  };

  fs.writeFileSync(CONFIG_FILE, JSON.stringify(config, null, 2), 'utf8');
  console.log(`\n✓ 已生成配置文件: ${CONFIG_FILE}`);

  // 生成 email_config.json (如果提供了邮件配置)
  if (emailFrom && emailPassword) {
    const emailConfig = {
      smtp: 'smtp.qq.com',
      port: 465,
      ssl: true,
      from: emailFrom,
      password: emailPassword,
      to: emailTo
    };

    fs.writeFileSync(EMAIL_CONFIG_FILE, JSON.stringify(emailConfig, null, 2), 'utf8');
    console.log(`✓ 已生成邮件配置: ${EMAIL_CONFIG_FILE}`);
  } else {
    console.log('提示: 未配置邮件，将创建 email_config.json.example 作为模板');
    const exampleConfig = {
      smtp: 'smtp.qq.com',
      port: 465,
      ssl: true,
      from: 'your_email@qq.com',
      password: 'your_smtp_password',
      to: 'recipient@example.com'
    };
    fs.writeFileSync(
      path.join(SKILL_DIR, 'email_config.json.example'),
      JSON.stringify(exampleConfig, null, 2),
      'utf8'
    );
  }

  console.log('\n========================================');
  console.log('  配置完成！');
  console.log('========================================');
  console.log('\n接下来的步骤:');
  console.log('  1. 检查 data/doc_watchlist.json 中文档列表');
  console.log('  2. 运行 node scripts/sync.js status 查看状态');
  console.log('  3. 运行 node scripts/sync.js check 检查更新');
  console.log('  4. 运行 node scripts/sync.js sync 执行同步');
  console.log('\n定时任务:');
  console.log('  - 默认每天 17:00 自动执行同步');
  console.log('  - 可在 QClaw 中配置 cron 任务\n');

  rl.close();
}

main().catch(e => {
  console.error('配置失败:', e.message);
  rl.close();
  process.exit(1);
});
