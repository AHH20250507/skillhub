const fs = require('fs');
const state = JSON.parse(fs.readFileSync('C:\\Users\\EDY\\.qclaw\\workspace\\kb_sync_state.json', 'utf8'));
const docs = [];

for (const [kbName, kb] of Object.entries(state.knowledge_bases || {})) {
  for (const [folderName, folder] of Object.entries(kb.folders || {})) {
    for (const [docId, doc] of Object.entries(folder.docs || {})) {
      docs.push({
        title: doc.title,
        wiki_token: doc.wiki_token,
        obj_type: doc.obj_type,
        kb_name: kbName,
        kb_id: kb.kb_id,
        folder_name: folderName,
        folder_id: folder.folder_id,
        doc_token: docId
      });
    }
  }
}

fs.writeFileSync('D:\\feishu-ima-sync-skill\\data\\doc_watchlist.json', JSON.stringify(docs, null, 2), 'utf8');
console.log(`已导出 ${docs.length} 篇文档到 doc_watchlist.json`);
console.log('前3篇：', docs.slice(0, 3).map(d => d.title).join(', '));
