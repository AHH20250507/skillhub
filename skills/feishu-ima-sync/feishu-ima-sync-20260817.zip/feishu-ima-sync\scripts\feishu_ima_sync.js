#!/usr/bin/env node
// 飞书→IMA知识库 智能同步脚本 v2
// 支持两种文档类型:
//   - docx: 飞书新版文档，通过 raw_content API 获取内容
//   - file: 飞书旧版/wiki文档，通过 drive/v1/files/download 下载DOCX后转换
// 用法: node feishu_ima_sync.js [命令] [选项]
// 命令:
//   check        - 检查所有文档是否有更新（不同步）
//   sync         - 检查并同步更新的文档
//   sync-one     - 同步单篇文档 (需 --doc-token)
//   status       - 显示当前监控状态概览
//   add-doc      - 添加监控文档 (需 --kb-name --folder-key --doc-token --title)
//   remove-doc   - 移除监控文档 (需 --kb-name --folder-key --doc-token)

const https = require('https');
const http = require('http');
const fs = require('fs');
const { execSync } = require('child_process');
const path = require('path');
const os = require('os');

// ========== 配置 ==========
const SKILL_DIR = path.resolve(__dirname, '..');
const WORKSPACE_DIR = process.env.WORKSPACE_DIR || path.resolve(SKILL_DIR, '../../workspace');
const STATE_FILE = path.join(WORKSPACE_DIR, 'kb_sync_state.json');
const LOG_FILE = path.join(WORKSPACE_DIR, 'monitor_log.txt');
const EMAIL_TO = process.env.SYNC_EMAIL || '2101006618@qq.com';
const EMAIL_SCRIPT = 'C:\\Users\\EDY\\.qclaw\\skills\\imap-smtp-email\\scripts\\windows\\email_gateway.cmd';

// 飞书 App 凭证
const FEISHU_APP_ID = process.env.FEISHU_APP_ID || 'cli_a9668450f3781cd5';
const FEISHU_APP_SECRET = process.env.FEISHU_APP_SECRET || 'AHAc5feYv3kjFWW6wyDL01dZD4XlrjpB';

// IMA 内容长度限制
const IMA_MAX_CONTENT = 500000;

// ========== 工具函数 ==========
function log(msg) {
  const ts = new Date().toISOString();
  const line = `[${ts}] ${msg}`;
  console.log(line);
  try { fs.appendFileSync(LOG_FILE, line + '\n', 'utf8'); } catch(e) {}
}

function httpRequest(url, opts, binary) {
  return new Promise((resolve, reject) => {
    const req = https.request(url, opts, res => {
      if (binary) {
        const chunks = [];
        res.on('data', chunk => chunks.push(chunk));
        res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
      } else {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => resolve({ status: res.statusCode, body: data }));
      }
      res.on('error', reject);
    });
    req.on('error', reject);
    if (opts.body) req.write(opts.body);
    req.end();
  });
}

function httpGet(token, apiPath, binary) {
  const url = `https://open.feishu.cn/open-apis/${apiPath}`;
  const opts = {
    method: 'GET',
    headers: { 'Authorization': `Bearer ${token}` }
  };
  return httpRequest(url, opts, binary);
}

function getIMACreds() {
  // Try environment variables first
  if (process.env.IMA_OPENAPI_CLIENTID && process.env.IMA_OPENAPI_APIKEY) {
    return {
      client_id: process.env.IMA_OPENAPI_CLIENTID,
      api_key: process.env.IMA_OPENAPI_APIKEY,
    };
  }

  // Try local proxy (AUTH_GATEWAY_PORT, default 19000) for fresh creds
  const gwPort = process.env.AUTH_GATEWAY_PORT || '19000';
  try {
    const ps1Path = path.join(__dirname, 'get-ima-proxy-creds.ps1');
    const proxyRes = execSync(
      `powershell.exe -NoProfile -Command "& '${ps1Path}' ${gwPort}"`,
      { encoding: 'utf8', timeout: 12000 }
    ).trim();
    const resp = JSON.parse(proxyRes);
    if (resp.ret === 0 && resp.data && resp.data.resp && resp.data.resp.data && resp.data.resp.data.access_token) {
      return {
        client_id: resp.data.resp.data.extra_data.client_id,
        api_key: resp.data.resp.data.access_token,
      };
    }
  } catch (e) { /* fallback below */ }

  // Fallback: get-token.ps1 (local credentials) - try dynamic QClaw path
  const qclawPaths = [
    'C:\\Users\\EDY\\.qclaw\\skills\\ima\\get-token.ps1',
    'C:\\Program Files\\QClaw\\resources\\openclaw\\config\\skills\\ima\\get-token.ps1',
    'C:\\Program Files\\QClaw\\v0.2.29.592\\resources\\openclaw\\config\\skills\\ima\\get-token.ps1',
  ];
  for (const ps1Path of qclawPaths) {
    try {
      if (fs.existsSync(ps1Path)) {
        const ps = `& '${ps1Path}' | ConvertFrom-Json | ConvertTo-Json -Compress`;
        const result = execSync(`powershell.exe -NoProfile -Command "${ps}"`, { encoding: 'utf8' }).trim();
        return JSON.parse(result);
      }
    } catch (e) { /* try next path */ }
  }
  throw new Error('Failed to get IMA credentials. Please set IMA_OPENAPI_CLIENTID and IMA_OPENAPI_APIKEY environment variables.');
}

function imaAPI(creds, endpoint, data) {
  return httpRequest(`https://ima.qq.com${endpoint}`, {
    method: 'POST',
    headers: {
      'ima-openapi-clientid': creds.client_id,
      'ima-openapi-apikey': creds.api_key,
      'Content-Type': 'application/json; charset=utf-8',
    },
    body: JSON.stringify(data),
  });
}

async function getFeishuToken() {
  const res = await httpRequest('https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ app_id: FEISHU_APP_ID, app_secret: FEISHU_APP_SECRET })
  });
  return JSON.parse(res.body).tenant_access_token;
}

// ========== 文档内容获取（支持多种类型） ==========

// 获取 docx 类型文档的 revision
async function getDocxRevision(token, docToken) {
  try {
    const res = await httpGet(token, `docx/v1/documents/${docToken}`);
    const d = JSON.parse(res.body);
    return d.data?.document?.revision_id || null;
  } catch (e) { return null; }
}

// 获取 docx 类型文档的 raw_content
async function getDocxContent(token, docToken) {
  try {
    const res = await httpGet(token, `docx/v1/documents/${docToken}/raw_content`);
    const d = JSON.parse(res.body);
    return d.data?.content || '';
  } catch (e) { return ''; }
}

// 通过 wiki token 获取 obj_token 和 obj_type
async function getWikiNodeInfo(token, wikiToken) {
  try {
    const res = await httpGet(token, `wiki/v2/spaces/get_node?token=${wikiToken}`);
    const d = JSON.parse(res.body);
    if (d.code !== 0 || !d.data?.node) return null;
    return {
      obj_token: d.data.node.obj_token,
      obj_type: d.data.node.obj_type,
      space_id: d.data.node.space_id,
      obj_edit_time: d.data.node.obj_edit_time,
    };
  } catch (e) { return null; }
}

// 下载 file 类型文档为 DOCX
async function downloadFileDoc(token, objToken) {
  try {
    const res = await httpGet(token, `drive/v1/files/${objToken}/download`, true);
    if (res.status === 200 && Buffer.isBuffer(res.body)) {
      return res.body;
    }
    return null;
  } catch (e) { return null; }
}

// DOCX 转 Markdown（使用 mammoth）
function docxToMarkdown(docxBuffer) {
  const tmpDocx = path.join(WORKSPACE_DIR, '_tmp_sync.docx');
  const tmpMd = path.join(WORKSPACE_DIR, '_tmp_sync.md');
  try {
    fs.writeFileSync(tmpDocx, docxBuffer);
    // Use mammoth programmatically
    const mammoth = require('mammoth');
    // mammoth is async, use execSync with node -e as fallback
    const cmd = `node -e "const m=require('mammoth');m.convertToMarkdown({path:'${tmpDocx.replace(/\\/g, '/')}'}).then(r=>{require('fs').writeFileSync('${tmpMd.replace(/\\/g, '/')}',r.value);console.log(r.value.length)}).catch(e=>console.error(e))"`;
    const output = execSync(cmd, { cwd: WORKSPACE_DIR, encoding: 'utf-8', timeout: 60000 });
    const content = fs.readFileSync(tmpMd, 'utf-8');
    return content;
  } catch (e) {
    log(`DOCX转换失败: ${e.message}`);
    return '';
  } finally {
    try { fs.unlinkSync(tmpDocx); } catch {}
    try { fs.unlinkSync(tmpMd); } catch {}
  }
}

// 统一获取文档 revision（根据类型）
async function getDocRevision(token, doc) {
  if (doc.obj_type === 'file' && doc.wiki_token) {
    // file 类型：通过 wiki API 获取 obj_edit_time 作为版本标识
    const info = await getWikiNodeInfo(token, doc.wiki_token);
    return info?.obj_edit_time || null;
  } else {
    // docx 类型：通过 docx API 获取 revision_id
    return await getDocxRevision(token, doc.docToken);
  }
}

// 统一获取文档内容（根据类型）
async function getDocContent(token, doc) {
  if (doc.obj_type === 'file' && doc.wiki_token) {
    // file 类型：wiki → obj_token → 下载DOCX → 转Markdown
    log(`  获取wiki节点信息: ${doc.wiki_token}`);
    const info = await getWikiNodeInfo(token, doc.wiki_token);
    if (!info) { log(`  获取wiki节点失败`); return ''; }
    
    log(`  下载DOCX: obj_token=${info.obj_token}`);
    const docxBuffer = await downloadFileDoc(token, info.obj_token);
    if (!docxBuffer) { log(`  下载DOCX失败`); return ''; }
    
    log(`  转换DOCX→Markdown (${docxBuffer.length} bytes)`);
    const md = docxToMarkdown(docxBuffer);
    if (!md) { log(`  转换失败`); return ''; }
    
    log(`  转换成功: ${md.length} chars`);
    return md.length > IMA_MAX_CONTENT ? md.substring(0, IMA_MAX_CONTENT) : md;
  } else {
    // docx 类型
    return await getDocxContent(token, doc.docToken);
  }
}

// ========== IMA 导入 ==========

async function importToIMA(creds, kbInfo, folderKey, title, content, explicitFolderId) {
  try {
    // 优先使用显式传入的folderId，其次从kbInfo.folders中查找
    let folderId = explicitFolderId;
    if (!folderId && kbInfo.folders) {
      const folder = kbInfo.folders[folderKey] || kbInfo.folders._root_ || {};
      folderId = folder.folder_id;
    }
    if (!folderId && kbInfo.folder_id) {
      folderId = kbInfo.folder_id;
    }
    
    log(`  IMA导入: kb=${kbInfo.kb_id}, folder_id=${folderId || 'null(根目录)'}`);
    
    // 截断过长内容
    const safeContent = content.length > IMA_MAX_CONTENT ? content.substring(0, IMA_MAX_CONTENT) : content;
    
    const res1 = await imaAPI(creds, '/openapi/note/v1/import_doc', {
      title: title,
      content: safeContent,
      content_format: 1,
    });
    const d1 = JSON.parse(res1.body);
    if (d1.code !== 0) return { success: false, error: `import_doc: ${d1.msg}` };
    
    const noteId = d1.data?.note_id;
    if (!noteId) return { success: false, error: 'note_id not found' };
    
    const addKnowledgePayload = {
      media_type: 11,
      title: title,
      knowledge_base_id: kbInfo.kb_id,
      note_info: { content_id: noteId },
    };
    // 只有明确有folderId时才添加folder_id参数
    if (folderId) {
      addKnowledgePayload.folder_id = folderId;
    }
    
    const res2 = await imaAPI(creds, '/openapi/wiki/v1/add_knowledge', addKnowledgePayload);
    const d2 = JSON.parse(res2.body);
    if (d2.code !== 0) return { success: false, error: `add_knowledge: ${d2.msg}` };
    
    return { success: true, note_id: noteId, media_id: d2.data?.media_id };
  } catch (e) { return { success: false, error: e.message }; }
}

// ========== 状态管理 ==========

function wait(ms) { return new Promise(r => setTimeout(r, ms)); }

function loadState() {
  try { return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8')); }
  catch { return { knowledge_bases: {}, last_updated: null }; }
}

function saveState(state) {
  state.last_updated = new Date().toISOString();
  fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function sendEmail(subject, body) {
  const MAX_RETRIES = 3;
  const { spawnSync } = require('child_process');
  // 直接调用 agently-cli 底层的 run.js（用 node.exe + 参数数组），完全不走 cmd.exe，
  // 避免 Windows 下单引号失效导致带空格参数被拆断（历史报错：unknown command "-"）
  const nodeExe = process.env.AGENTLY_NODE_BINARY || 'C:\\Program Files\\nodejs\\node.exe';
  const runJs = 'C:\\Users\\EDY\\AppData\\Roaming\\QClaw\\npm-global\\node_modules\\@tencent-qqmail\\agently-cli\\scripts\\run.js';

  function runCli(extraArgs) {
    const args = [runJs, 'message', '+send', '--to', '2101006618@qq.com',
      '--subject', subject, '--body', body, ...extraArgs];
    const res = spawnSync(nodeExe, args, { shell: false, encoding: 'utf8', timeout: 30000 });
    if (res.error) throw res.error;
    if (typeof res.stdout !== 'string') throw new Error('无输出');
    return res.stdout;
  }

  for (let attempt = 1; attempt <= MAX_RETRIES; attempt++) {
    try {
      // 第1步：发起发送请求，获取确认令牌
      const step1 = runCli([]);
      const resp1 = JSON.parse(step1.trim());

      // 如果需要确认令牌，第2步确认发送
      if (resp1.ok && resp1.data?.confirmation_required && resp1.data?.confirmation_token) {
        const token = resp1.data.confirmation_token;
        const step2 = runCli(['--confirmation-token', token]);
        const resp2 = JSON.parse(step2.trim());
        if (resp2.ok && resp2.data?.queued) {
          log(`邮件已发送 (发件人: ahaha2333@agent.qq.com)`);
          return true;
        }
        log(`邮件确认发送失败: ${step2.trim()}`);
        if (attempt < MAX_RETRIES) await sleep(5000);
        continue;
      }

      if (resp1.ok && resp1.data?.queued) {
        log(`邮件已发送 (发件人: ahaha2333@agent.qq.com)`);
        return true;
      }

      log(`邮件发送失败 (第${attempt}次尝试): ${step1.trim()}`);
      if (attempt < MAX_RETRIES) await sleep(5000);
    } catch (e) {
      log(`邮件发送失败 (第${attempt}次尝试): ${e.message}`);
      if (attempt < MAX_RETRIES) await sleep(5000);
    }
  }
  log(`邮件发送彻底失败，已重试 ${MAX_RETRIES} 次`);
  return false;
}

function updateRevision(state, kbName, folderKey, docToken, newRev) {
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) return false;
  if (kbInfo.folders) {
    const folder = kbInfo.folders[folderKey];
    if (folder?.docs?.[docToken]) { folder.docs[docToken].revision = newRev; return true; }
    if (folderKey === '_root_' && kbInfo.folders._root_?.docs?.[docToken]) { kbInfo.folders._root_.docs[docToken].revision = newRev; return true; }
  } else if (kbInfo.docs?.[docToken]) { kbInfo.docs[docToken].revision = newRev; return true; }
  return false;
}

// 收集所有文档
function collectAllDocs(state) {
  const docs = [];
  for (const [kbName, kbInfo] of Object.entries(state.knowledge_bases)) {
    if (kbInfo.folders) {
      for (const [folderKey, folderInfo] of Object.entries(kbInfo.folders)) {
        for (const [docToken, docInfo] of Object.entries(folderInfo.docs || {})) {
          docs.push({ docToken, ...docInfo, kbName, folderKey, folderName: folderKey === '_root_' ? '根目录' : folderKey, folderId: folderInfo.folder_id });
        }
      }
    } else if (kbInfo.docs) {
      for (const [docToken, docInfo] of Object.entries(kbInfo.docs)) {
        docs.push({ docToken, ...docInfo, kbName, folderKey: kbInfo.folder_name, folderName: kbInfo.folder_name, folderId: kbInfo.folder_id });
      }
    }
  }
  return docs;
}

// 收集指定知识库的所有文档（用于sync-one时按知识库分组）
function collectKBDocs(state, kbName) {
  const docs = [];
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) return docs;
  
  if (kbInfo.folders) {
    for (const [folderKey, folderInfo] of Object.entries(kbInfo.folders)) {
      for (const [docToken, docInfo] of Object.entries(folderInfo.docs || {})) {
        docs.push({ docToken, ...docInfo, kbName, folderKey, folderName: folderKey === '_root_' ? '根目录' : folderKey, folderId: folderInfo.folder_id });
      }
    }
  } else if (kbInfo.docs) {
    for (const [docToken, docInfo] of Object.entries(kbInfo.docs)) {
      docs.push({ docToken, ...docInfo, kbName, folderKey: kbInfo.folder_name, folderName: kbInfo.folder_name, folderId: kbInfo.folder_id });
    }
  }
  return docs;
}

// ========== 命令实现 ==========

async function cmdStatus() {
  const state = loadState();
  const docs = collectAllDocs(state);
  const output = {
    total_docs: docs.length,
    knowledge_bases: Object.keys(state.knowledge_bases),
    last_updated: state.last_updated,
    docs: docs.map(d => ({ 
      title: d.title, 
      kb: d.kbName, 
      folder: d.folderName, 
      type: d.obj_type || 'docx',
      rev: d.revision, 
      token: d.docToken 
    }))
  };
  console.log(JSON.stringify(output, null, 2));
}

async function cmdCheck() {
  const state = loadState();
  const feishuToken = await getFeishuToken();
  const docs = collectAllDocs(state);
  const changes = [];
  
  for (const doc of docs) {
    const newRev = await getDocRevision(feishuToken, doc);
    if (newRev !== null && newRev !== doc.revision) {
      changes.push({ title: doc.title, oldRev: doc.revision, newRev, kb: doc.kbName, folder: doc.folderName, token: doc.docToken, type: doc.obj_type || 'docx' });
    }
  }
  
  console.log(JSON.stringify({ total: docs.length, changed: changes.length, changes }, null, 2));
}

async function cmdSync(skipEmail) {
  log('===== 开始同步检查 =====');
  const state = loadState();
  const feishuToken = await getFeishuToken();
  const imaCreds = getIMACreds();
  const docs = collectAllDocs(state);
  const updates = [];
  
  // 检查更新
  for (const doc of docs) {
    const newRev = await getDocRevision(feishuToken, doc);
    if (newRev !== null && newRev !== doc.revision) {
      log(`📝 更新: ${doc.title} (${doc.revision} → ${newRev})`);
      updates.push({ ...doc, newRev });
    } else {
      log(`✓ 无变化: ${doc.title} (rev=${newRev || doc.revision})`);
    }
  }
  
  // 汇总统计
  const kbStats = {};
  for (const doc of docs) { kbStats[doc.kbName] = (kbStats[doc.kbName] || 0) + 1; }
  log(`===== 检查完毕: 共${docs.length}篇 | ${Object.entries(kbStats).map(([k,v])=>`${k}=${v}篇`).join(' | ')} | 更新${updates.length}篇 =====`);
  
  if (updates.length === 0) {
    log('无更新');
    console.log(JSON.stringify({ synced: 0, message: '无更新' }));
    return;
  }
  
  // 同步
  const results = [];
  for (const u of updates) {
    log(`同步: ${u.title} (type=${u.obj_type || 'docx'})`);
    const content = await getDocContent(feishuToken, u);
    if (!content) {
      results.push({ title: u.title, synced: false, error: '获取文档内容为空' });
      continue;
    }
    const kbInfo = state.knowledge_bases[u.kbName];
    const result = await importToIMA(imaCreds, kbInfo, u.folderKey, u.title, content, u.folderId);
    if (result.success) {
      log(`✓ 同步成功: ${u.title} (note_id=${result.note_id})`);
      updateRevision(state, u.kbName, u.folderKey, u.docToken, u.newRev);
      results.push({ title: u.title, synced: true, note_id: result.note_id, oldRev: u.revision, newRev: u.newRev });
    } else {
      log(`✗ 同步失败: ${u.title} - ${result.error}`);
      results.push({ title: u.title, synced: false, error: result.error });
    }
    await wait(2000);
  }
  
  saveState(state);
  
  // 邮件通知
  const successCount = results.filter(r => r.synced).length;
  const failCount = results.filter(r => !r.synced).length;
  
  if (!skipEmail && (successCount > 0 || failCount > 0)) {
    const lines = [
      `📄 飞书文档同步报告`,
      `时间：${new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' })}`,
      `结果：✅${successCount}成功${failCount > 0 ? ` ❌${failCount}失败` : ''}`,
      ''
    ];
    results.forEach(r => {
      lines.push(`${r.synced ? '✅' : '❌'} ${r.title}${r.oldRev ? ` (${r.oldRev}→${r.newRev})` : ''}`);
      if (!r.synced) lines.push(`   原因：${r.error}`);
    });
    sendEmail(`飞书文档同步报告 - ${new Date().toISOString().slice(0,10)}`, lines.join('\n'));
  }
  
  console.log(JSON.stringify({ synced: successCount, failed: failCount, results }, null, 2));
}

async function cmdSyncOne(docToken) {
  const state = loadState();
  const feishuToken = await getFeishuToken();
  const imaCreds = getIMACreds();
  
  // 遍历所有知识库，找到包含该文档的知识库分别同步
  const results = [];
  for (const kbName of Object.keys(state.knowledge_bases)) {
    const kbDocs = collectKBDocs(state, kbName);
    const doc = kbDocs.find(d => d.docToken === docToken);
    if (!doc) continue;
    
    log(`强制同步: ${doc.title} → ${doc.kbName}/${doc.folderName}`);
    const content = await getDocContent(feishuToken, doc);
    if (!content) {
      results.push({ kb: doc.kbName, folder: doc.folderName, error: '获取文档内容为空' });
      continue;
    }
    
    const kbInfo = state.knowledge_bases[doc.kbName];
    const result = await importToIMA(imaCreds, kbInfo, doc.folderKey, doc.title, content, doc.folderId);
    
    if (result.success) {
      const newRev = await getDocRevision(feishuToken, doc);
      if (newRev) updateRevision(state, doc.kbName, doc.folderKey, doc.docToken, newRev);
      results.push({ kb: doc.kbName, folder: doc.folderName, success: true, note_id: result.note_id, media_id: result.media_id });
    } else {
      results.push({ kb: doc.kbName, folder: doc.folderName, success: false, error: result.error });
    }
  }
  
  if (results.length === 0) {
    console.log(JSON.stringify({ error: `文档 ${docToken} 不在监控列表中` }));
    return;
  }
  
  saveState(state);
  console.log(JSON.stringify({ success: results.every(r => r.success), results }, null, 2));
}

async function cmdAddDoc(kbName, folderKey, docToken, title, wikiToken, objType) {
  const state = loadState();
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) {
    console.log(JSON.stringify({ error: `知识库 "${kbName}" 不存在，可用: ${Object.keys(state.knowledge_bases).join(', ')}` }));
    return;
  }
  
  const feishuToken = await getFeishuToken();
  
  let revision;
  let docObjType = objType || 'docx';
  let docWikiToken = wikiToken || null;
  
  if (docWikiToken) {
    // wiki/file 类型文档
    const info = await getWikiNodeInfo(feishuToken, docWikiToken);
    revision = info?.obj_edit_time || null;
    docObjType = info?.obj_type || 'file';
  } else {
    // docx 类型
    revision = await getDocxRevision(feishuToken, docToken);
  }
  
  const docEntry = { title, revision };
  if (docWikiToken) docEntry.wiki_token = docWikiToken;
  if (docObjType !== 'docx') docEntry.obj_type = docObjType;
  
  if (kbInfo.folders) {
    const folder = kbInfo.folders[folderKey];
    if (!folder) {
      console.log(JSON.stringify({ error: `文件夹 "${folderKey}" 不存在，可用: ${Object.keys(kbInfo.folders).filter(k => k !== '_root_').join(', ')}` }));
      return;
    }
    if (!folder.docs) folder.docs = {};
    folder.docs[docToken] = docEntry;
  } else if (kbInfo.docs) {
    kbInfo.docs[docToken] = docEntry;
  }
  
  saveState(state);
  console.log(JSON.stringify({ success: true, title, revision, kb: kbName, folder: folderKey, type: docObjType }));
}

async function cmdRemoveDoc(kbName, folderKey, docToken) {
  const state = loadState();
  const kbInfo = state.knowledge_bases[kbName];
  if (!kbInfo) { console.log(JSON.stringify({ error: `知识库 "${kbName}" 不存在` })); return; }
  
  let removed = false;
  if (kbInfo.folders?.[folderKey]?.docs?.[docToken]) {
    delete kbInfo.folders[folderKey].docs[docToken];
    removed = true;
  } else if (kbInfo.docs?.[docToken]) {
    delete kbInfo.docs[docToken];
    removed = true;
  }
  
  if (removed) { saveState(state); console.log(JSON.stringify({ success: true })); }
  else { console.log(JSON.stringify({ error: '文档不存在' })); }
}

// ========== 主入口 ==========
async function main() {
  const args = process.argv.slice(2);
  const cmd = args[0] || 'sync';
  
  const getArg = (name) => {
    const i = args.indexOf(name);
    return i >= 0 && i + 1 < args.length ? args[i + 1] : null;
  };
  
  switch (cmd) {
    case 'status':
      await cmdStatus();
      break;
    case 'check':
      await cmdCheck();
      break;
    case 'sync':
      await cmdSync(args.includes('--no-email'));
      break;
    case 'sync-one':
      const token = getArg('--doc-token');
      if (!token) { console.log(JSON.stringify({ error: '需要 --doc-token 参数' })); process.exit(1); }
      await cmdSyncOne(token);
      break;
    case 'add-doc':
      const aKb = getArg('--kb-name');
      const aFolder = getArg('--folder-key');
      const aToken = getArg('--doc-token');
      const aTitle = getArg('--title');
      const aWiki = getArg('--wiki-token');
      const aType = getArg('--obj-type');
      if (!aKb || !aFolder || !aToken || !aTitle) {
        console.log(JSON.stringify({ error: '需要 --kb-name --folder-key --doc-token --title [--wiki-token] [--obj-type]' }));
        process.exit(1);
      }
      await cmdAddDoc(aKb, aFolder, aToken, aTitle, aWiki, aType);
      break;
    case 'remove-doc':
      const rKb = getArg('--kb-name');
      const rFolder = getArg('--folder-key');
      const rToken = getArg('--doc-token');
      if (!rKb || !rFolder || !rToken) {
        console.log(JSON.stringify({ error: '需要 --kb-name --folder-key --doc-token' }));
        process.exit(1);
      }
      await cmdRemoveDoc(rKb, rFolder, rToken);
      break;
    default:
      console.log(`用法: node feishu_ima_sync.js [status|check|sync|sync-one|add-doc|remove-doc] [选项]`);
      process.exit(1);
  }
}

main().catch(e => { console.error(JSON.stringify({ error: e.message })); process.exit(1); });
