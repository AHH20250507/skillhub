---
name: feishu-ima-sync
description: 飞书文档自动同步到IMA知识库的智能Agent。支持检查文档更新、自动同步、邮件通知、文档管理。当用户提到飞书文档同步、知识库更新、IMA同步、检查飞书更新时触发。支持命令：查看同步状态、检查更新、立即同步、添加/移除监控文档。
---

# 飞书→IMA知识库 智能同步

自动监控飞书文档更新，同步到IMA知识库，并发邮件通知。

## 核心脚本

脚本位置: `scripts/feishu_ima_sync.js`

运行前需设置环境变量:
```powershell
$env:AW_CLI_NODE_BINARY = 'C:\Program Files\QClaw\resources\openclaw\config\bin\node.exe'
```

## 命令用法

```powershell
# 查看同步状态（文档列表、revision、知识库映射）
node scripts/feishu_ima_sync.js status

# 检查是否有更新（不同步）
node scripts/feishu_ima_sync.js check

# 检查并同步更新（默认发邮件）
node scripts/feishu_ima_sync.js sync

# 同步但不发邮件
node scripts/feishu_ima_sync.js sync --no-email

# 强制同步单篇文档
node scripts/feishu_ima_sync.js sync-one --doc-token <TOKEN>

# 添加监控文档
node scripts/feishu_ima_sync.js add-doc --kb-name "知识库名" --folder-key "文件夹名" --doc-token <TOKEN> --title "标题"

# 移除监控文档
node scripts/feishu_ima-sync.js remove-doc --kb-name "知识库名" --folder-key "文件夹名" --doc-token <TOKEN>
```

## 知识库映射（共24篇文档）

| 知识库名 | KB ID | 文件夹 | 文档数 |
|---------|-------|--------|--------|
| 壹准智能问答助手 | `xEm9eiOeSw9z2oWisrwFp-wElFkB2rzvB2YPO7OIMjU=` | 平台规则说明（10篇）、验机中心运营相关（3篇）、_root_（1篇） | 14篇 |
| 智能问答助手 | `pT9qktKE2I5K3djfXQoNHIsgOkfLrmwh-hmTSt2kUps=` | 请点击下方对话框开始提问 | 10篇 |

### 壹准智能问答助手（14篇）

**平台规则说明（10篇）**

- 壹准保卖商家交易规范规则
- 壹准保卖商家取消代卖规则
- 壹准保卖商家违规处罚规则
- 壹准拍机保证金管理规则
- 壹准拍机买家交易规则规范（暗拍）
- 壹准拍机买家交易规则规范（直拍）
- 壹准拍机违规处罚说明
- 壹准拍机买家端售后规范规则
- 壹准业务FAQ
- 壹准BOT速收回收流程及规则指南

**验机中心运营相关（3篇）**

- 壹准验机中心运营SOP
- 验机中心业务[商户]操作指引
- 壹准验机中心SOP附录教程

**_root_（1篇）**

- 平台优势卖点提炼内容

### 智能问答助手（10篇）

- 壹准保卖商家交易规范规则
- 壹准保卖商家取消代卖规则
- 壹准保卖商家违规处罚规则
- 壹准拍机保证金管理规则
- 壹准拍机买家交易规则规范（暗拍）
- 壹准拍机买家交易规则规范（直拍）
- 壹准拍机违规处罚说明
- 壹准拍机买家端售后规范规则
- 壹准业务FAQ
- 壹准BOT速收回收流程及规则指南

## 同步流程

1. 获取飞书 tenant_access_token
2. 遍历监控文档，比较 revision_id
3. 有更新 → 获取 raw_content (Markdown)
4. `import_doc` → 创建IMA笔记
5. `add_knowledge` → 关联到知识库（含folder_id）
6. 更新 `kb_sync_state.json` 中的 revision
7. 发邮件通知到 2101006618@qq.com

## 关键约束

- **import_doc 创建笔记类型**（media_type=11），AI可检索
- **不要用 import_urls**，创建网址类型（media_type=2），AI无法检索
- IMA API 不支持删除/覆盖，只能追加
- 飞书 raw_content 不含图片（需 drive:file:download 权限，当前未实现图片同步）
- IMA API quota 每日 16:00-17:00 重置

## 状态文件

`kb_sync_state.json` 位于 workspace 目录，记录每篇文档的 revision_id。仅推送有变更的文档。

## 定时任务

Windows 任务计划程序 `FeishuMonitor`，每日 17:00 运行。包装脚本 `run_monitor.cmd` 在 workspace 目录。

## 飞书 API

- 文档信息: `GET /docx/v1/documents/{token}`
- 文档内容: `GET /docx/v1/documents/{token}/raw_content`
- 认证: `POST /auth/v3/tenant_access_token/internal`

## IMA API

- 导入笔记: `POST /openapi/note/v1/import_doc`
- 添加知识: `POST /openapi/wiki/v1/add_knowledge`
- 凭证: 通过 `ima/get-token.ps1` 获取 client_id/api_key
- 域名: `ima.qq.com`
