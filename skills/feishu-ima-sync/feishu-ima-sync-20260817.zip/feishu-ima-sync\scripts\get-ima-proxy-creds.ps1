# get-ima-proxy-creds.ps1 — Retrieve IMA OpenAPI credentials via local proxy service
# Usage: & '<SCRIPT_PATH>\get-ima-proxy-creds.ps1' [port]
# Default port: 19000

$ErrorActionPreference = "Stop"

$ProxyPort = if ($args[0]) { $args[0] } else { $env:AUTH_GATEWAY_PORT }
if (-not $ProxyPort) { $ProxyPort = '19000' }

$ProxyBase = "http://localhost:${ProxyPort}"

# BUILD_ENV=test uses test env; otherwise uses production
$RemoteBase = if ($env:BUILD_ENV -eq "test") { "https://jprx.sparta.html5.qq.com" } else { "https://jprx.m.qq.com" }

$Platform = if ($env:CREDENTIAL_PLATFORM) { $env:CREDENTIAL_PLATFORM } else { "ima" }
$body = @{ platform = $Platform } | ConvertTo-Json -Compress
$RemoteUrl = "${RemoteBase}/data/4164/forward"

try {
    $response = Invoke-RestMethod -Uri "${ProxyBase}/proxy/api" `
        -Method Post `
        -Headers @{ "Remote-URL" = $RemoteUrl; "Content-Type" = "application/json" } `
        -Body $body `
        -TimeoutSec 10
} catch {
    [Console]::Error.WriteLine("ERROR: $_")
    exit 1
}

if ($response.ret -ne 0) {
    [Console]::Error.WriteLine("ERROR: ret=$($response.ret)")
    exit 1
}

# access_token → api_key, extra_data.client_id → client_id
$apiKey = $response.data.resp.data.access_token
$clientId = $response.data.resp.data.extra_data.client_id

if (-not $clientId -or $clientId -eq "null" -or -not $apiKey -or $apiKey -eq "null") {
    [Console]::Error.WriteLine("ERROR: failed to retrieve IMA credentials, please complete IMA authorization in the integration panel first")
    exit 1
}

Write-Output (@{ client_id = $clientId; api_key = $apiKey } | ConvertTo-Json -Compress)
exit 0
