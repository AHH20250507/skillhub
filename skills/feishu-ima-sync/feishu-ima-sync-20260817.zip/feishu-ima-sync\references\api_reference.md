# 飞书 & IMA API 参考

## 飞书 API

### 获取 tenant_access_token
```
POST https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal
Content-Type: application/json

{"app_id": "cli_a9668450f3781cd5", "app_secret": "..."}
```

### 获取文档信息（含 revision_id）
```
GET https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}
Authorization: Bearer {token}

Response: { "data": { "document": { "revision_id": "123" } } }
```

### 获取文档纯文本内容
```
GET https://open.feishu.cn/open-apis/docx/v1/documents/{doc_token}/raw_content
Authorization: Bearer {token}

Response: { "data": { "content": "markdown text..." } }
```

## IMA API

### 导入笔记
```
POST https://ima.qq.com/openapi/note/v1/import_doc
Headers: ima-openapi-clientid, ima-openapi-apikey

{"title": "标题", "content": "markdown内容", "content_format": 1}
```

### 添加到知识库
```
POST https://ima.qq.com/openapi/wiki/v1/add_knowledge
Headers: ima-openapi-clientid, ima-openapi-apikey

{
  "media_type": 11,
  "title": "标题",
  "knowledge_base_id": "kb_id",
  "folder_id": "folder_id (可选)",
  "note_info": { "content_id": "note_id" }
}
```

### 搜索知识库
```
POST https://ima.qq.com/openapi/wiki/v1/search_knowledge_base
Headers: ima-openapi-clientid, ima-openapi-apikey

{"knowledge_base_id": "kb_id", "query": "关键词"}
```
