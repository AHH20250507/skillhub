# HTML Reader - 项目上下文

## 项目简介

一个 Web 端 HTML 阅读器/书架应用，用于管理和阅读 HTML 文档。

## 技术架构

- **纯前端单页应用**，所有逻辑在 `index.html` 一个文件中（~65KB）
- **存储后端**：GitHub 仓库，通过 GitHub REST API 读写文件
- **部署**：GitHub Pages（自动从 main 分支部署）
- **无后端、无构建工具、无依赖**

## GitHub 信息

- **仓库**：`AHH20250507/html-reader`
- **Pages 地址**：`https://ahh20250507.github.io/html-reader/`
- **Token**：用户在 app 设置界面输入 GitHub Personal Access Token（需 `repo` 权限），存储在浏览器 localStorage
- **Token key**：`hr_gh_token`

## 仓库结构

```
/
├── index.html              # 主应用（单文件）
├── reader-metadata.json    # 书籍元数据 + 分类配置
├── books/                  # 导入的 HTML 文件
│   ├── book_xxx.html
│   └── ...
└── README.md
```

## 数据结构

### reader-metadata.json
```json
{
  "version": 1,
  "updatedAt": 1782791022446,
  "categories": [
    {"id": "uncategorized", "name": "未分类", "color": "#86868b"},
    {"id": "tech", "name": "技术文档", "color": "#007aff"}
  ],
  "books": [
    {
      "id": "book_1782797067266_gbhra6",
      "title": "文档标题",
      "filename": "book_1782797067266_gbhra6.html",
      "category": "uncategorized",
      "pinned": false,
      "importDate": 1782797067266,
      "lastRead": 1782797067266
    }
  ]
}
```

## 已实现功能

| 功能 | 状态 | 说明 |
|------|------|------|
| 书架浏览 | ✅ | 网格/列表两种视图 |
| 导入 HTML | ✅ | 支持文件选择、拖放、批量导入 |
| 新标签页打开 | ✅ | 点击文档通过 Blob URL 在新标签页打开 |
| 阅读进度记忆 | ✅ | 注入滚动追踪脚本到 HTML 中，用 localStorage 保存滚动位置 |
| 搜索 | ✅ | 按标题实时搜索 |
| 分类管理 | ✅ | 自定义分类（新建/删除），带颜色标记 |
| 修改分类 | ✅ | 右键菜单 → 更改分类（模态弹窗选择） |
| 置顶 | ✅ | 单个文档置顶 |
| 下载 | ✅ | 下载原始 HTML 文件（Blob URL） |
| 删除 | ✅ | 自定义确认弹窗 |
| 侧边栏折叠 | ✅ | 可折叠，localStorage 记住状态 |
| 自定义弹窗 | ✅ | 居中模态弹窗，替代浏览器原生 confirm/prompt |
| 临时登录 | ✅ | 公共电脑场景，token 仅存内存，关闭页面即失效 |
| Favicon | ✅ | 白底蓝色文档叠层图标 |
| GitHub 存储 | ✅ | 通过 API 读写，支持中文内容（b64Encode/b64Decode） |
| Token 安全 | ✅ | cleanToken 去除不可见字符，token 不硬编码 |
| 临时登录 | ✅ | 公共电脑场景，token 仅存内存，关闭页面即失效 |

## 关键技术细节

### HTML 渲染方式
- 用 `<iframe srcdoc>` 渲染（之前用 `raw.githubusercontent.com`，国内被墙，已改为 API 获取内容 + srcdoc）
- 内容缓存在 `contentCache` Map 中，避免重复 API 请求

### 阅读进度注入
打开文档时，在 HTML 的 `</body>` 前注入滚动追踪脚本：
```javascript
// 监听滚动，300ms 防抖保存到 localStorage
// key: hr_scroll_{bookId}
// value: {y: scrollTop, t: timestamp}
```

### GitHub API 封装
- `ghFetch(path, opts)` - 通用请求
- `getFile(path)` - 获取文件内容（base64 解码）
- `putFile(path, content, sha, message)` - 创建/更新文件
- `deleteFile(path, sha, message)` - 删除文件
- `cleanToken(t)` - 清理 token 中的不可见字符和 Unicode 省略号
- `b64Encode(str)` / `b64Decode(b64)` - 安全的 Unicode Base64 编解码

### 移动端适配
- 列表模式：隐藏左侧预览图标，标题最多 2 行
- 侧边栏：固定定位，可折叠
- 搜索框和内容区有移动端 padding 调整

## 已知限制

- **GitHub 仓库上限**：推荐 1GB，硬上限 5GB
- **API 限流**：5000 次/小时（认证用户）
- **单文件上限**：100MB
- **Token 安全**：GitHub 会自动吊销暴露的 token（之前的 token 被吊销过多次）

### Token 存储
- 永久保存：`localStorage` key `hr_gh_token`
- 临时登录：`sessionToken` 变量（内存），关闭页面即丢失
- `getGHToken()` 优先返回 `sessionToken`
- `isSessionOnly()` 判断是否为临时登录模式

## 后续可优化方向

- [ ] 暗色模式
- [ ] 文档排序（按名称、日期、大小）
- [ ] 批量删除/批量移动分类
- [ ] 文档预览卡片（首屏截图）
- [ ] 迁移到云存储（突破 1GB 限制）
- [ ] 离线支持（Service Worker）
