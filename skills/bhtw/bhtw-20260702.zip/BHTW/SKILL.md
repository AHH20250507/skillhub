---
name: bhtw
description: Synthesizes a WeChat Official Account article based on a specific theme (e.g., product launch) and reference URLs. Extracts content, organizes it into logical point-by-point feature introductions (e.g., by individual products for launches, or by upgraded features for leak articles), embeds relevant authentic images from the references, and outputs locally saved HTML files matching precise WeChat layout constraints (Blue/Green styles, number headers, zero-margins, 1.0/2.0 spacing). Use when a user provides a topic and links and wants to generate a WeChat push article with a layout.
---

# BHTW (Event Article Generator)

This skill creates a beautifully formatted WeChat Official Account article based on a user-provided Theme and a list of reference links. It synthesizes the information into a highly logical structure, extracting content by product or feature, embeds authentic images from the source, applies strict visual layout formatting with numbered headers, and outputs the final HTML minified for WeChat copy-pasting.

## Workflow

When the user provides a Theme and reference links, **automatically start working**. Follow these exact steps:

### 1. Fetch and Read All Reference Content (MANDATORY)
- Use available web tools to fetch the text and media content from **ALL** provided reference links.
- You must read all information thoroughly. Do not miss any links.
- **CRITICAL ANTI-HALLUCINATION RULE**: You can **ONLY** use the content explicitly provided in the reference links to perform your integration. You must never fabricate specs, dates, statements, or product details. All content must stem directly from the provided materials.

### 2. Synthesize and Structure Content Logically
- Organize the extracted content logically based on the Theme:
  - If it's a **Launch Event**, split the points by **individual products** announced (e.g., Point 1: Phone A, Point 2: Phone B, Point 3: Watch C).
  - If it's an **Upcoming Device Leak**, split the points by **upgraded features** (e.g., Point 1: Screen, Point 2: Camera, Point 3: Battery).
- **Introduction**: Provide an overarching introductory paragraph before starting the formal bullet points. This should serve as a brief opening/hook for the article.
- **Detailed Points**: Within each organized bullet point, attempt to write **2 paragraphs**, accompanied by **1 corresponding image for each paragraph** (i.e. 2 paragraphs and 2 images total). If the reference material is too scarce, you may fallback to 1 paragraph and 1 image.
- **Text Styling**: In EVERY paragraph (including Introduction and Detailed Points), identify the most important key sentence or phrase and wrap it in a bold tag with the layout color. Format: `<strong style="color: {COLOR};">Your Key Phrase Here</strong>`.
- Maintain a professional tone. **CRITICAL INTEGRATION**: You MUST explicitly run all your drafted textual content through the `Humanizer-zh-main` skill logic (or instruct the user to do so in the same turn, or apply its guidelines natively if it's implicitly triggered) to completely remove AI-generated phrasing and ensure a formal, human-written tone.
  - Blue layout color: `#006fff`
  - Green layout color: `#00b050`
- Prepare a concise Title for each subpoint (e.g., "iPhone 17e") to be used as `{BULLET_POINT_TITLE}` in the template. And set it a 2-digit index like "01", "02" as `{INDEX_NUMBER}`.

### 3. Image Extraction and Mapping
- Locate **authentic image URLs** within the reference links that logically correspond to each organized bullet point.
- **NEVER generate AI images**. Do not invent URLs. Use the original image URLs found in the source text.
- **CRITICAL**: Every single bullet point MUST have AT LEAST 1 image. Do not create a bullet point if you cannot find a relevant image for it. Map the relevant images into the layout template under their respective bullet points.

### 4. Build Layout from Template
- Read and strictly apply the formatting rules in `references/layout-template.md`.
- You MUST construct TWO complete versions of the article (Blue layout and Green layout).
- Concatenate the HTML strings for each bullet point to form the `{CONTENT}`. 
- At the very end of `{CONTENT}`, before the final wrapper closes, use the Conclusion / Interactive Block template to append a short conclusion paragraph wrapping up the article's core message. Ensure you use the exact body text layout `<p>` tags and wrap the interactive call-to-action part in `<strong style="color: {COLOR};">`.
- Wrap the full string in the Full Article Wrapper.
- Strip all literal newline characters `\n` or `> <` empty gaps from your final string to create a fully minified, 1-line HTML structure. This is required for WeChat to ensure line-height logic isn't broken.

### 5. Export Local HTML and Remove Watermarks (MANDATORY)
- Write the final minified HTML strings to two separate local `.html` files in the current workspace (e.g., `event_article_blue.html` and `event_article_green.html`).
- **You MUST process the newly created HTML files to seamlessly remove IT之家 watermarks and re-host the images.**
- Run this exact command on your workspace to automatically clean both files:
  `python scripts/remove_watermark.py --input_html <your_file_name>.html`
- Report back to the user about your logic grouping (explain what points you chose to use and why), then confirm that the local files are successfully cleaned and ready.
