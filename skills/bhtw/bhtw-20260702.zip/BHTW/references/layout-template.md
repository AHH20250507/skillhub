# WeChat Article Layout Template

This template is used for formatting the bullet-point themed articles securely for WeChat Official Accounts.

## Full Article Wrapper

This wrapper contains the generated content blocks. **CRITICAL**: The final output MUST be entirely minified onto a single line without any newline characters (`\n` or `> <` gaps) to prevent rendering gaps in WeChat.

```html
<section style="margin: 0 auto; max-width: 600px; padding: 0; font-family: 'Microsoft YaHei', 'PingFang SC', -apple-system, sans-serif; font-size: 15px; color: #3f3f3f; line-height: 2; letter-spacing: 1px; background-color: #ffffff; text-align: left;"><div>{CONTENT}</div></section>
```

## Header Image

EVERY article MUST start with this header image based on the chosen color theme. Notice the `<p style="margin:0;line-height:1;"><br></p>` spacing immediately following.

```html
<!-- Blue Layout Header -->
<section style="text-align:center;"><img alt="header" src="https://files.catbox.moe/0zl6rm" style="vertical-align: baseline;width: 100%;box-sizing:border-box;max-width:100% !important;" draggable="false"/></section><p style="margin:0;line-height:1;"><br></p>

<!-- Green Layout Header -->
<section style="text-align:center;"><img src="https://files.catbox.moe/n5tst9" style="width:100%;vertical-align:baseline;box-sizing:border-box;max-width:100% !important;" draggable="false"/></section><p style="margin:0;line-height:1;"><br></p>
```

## Introduction Block

Immediately following the Header, insert an introductory paragraph serving as the article's opening.

```html
<p style="margin:0; text-align: left; word-wrap: break-word;">{INTRODUCTION_TEXT}</p><p style="margin:0;line-height:2;"><br></p>
```

## Content Block (Bullet Point Header + Paragraphs/Images)

For each bullet point feature extracted from references, use this block format exactly. This creates a stylish section header featuring an italic background number (e.g., "01"), surrounded by blue/green squares (`■`), followed by the description and an image.

```html
<section style="margin: 30px 0 20px 0; border: 0; padding: 0; box-sizing: border-box;"><section style="text-align: center; margin-bottom: -32px; justify-content: center; align-items: center; display: flex; transform: translateZ(0); -webkit-transform: translateZ(0);"><span style="font-family: Arial, sans-serif; font-size: 55px; font-weight: 900; font-style: italic; color: {COLOR}; opacity: 0.1; letter-spacing: 2px;">{INDEX_NUMBER}</span></section><section style="text-align: center; display: flex; justify-content: center; align-items: center; position: relative; z-index: 1;"><span style="display: inline-block; width: 6px; height: 6px; background-color: {COLOR}; margin-right: 15px;"></span><strong style="font-size: 18px; color: #333333; letter-spacing: 2px;">{BULLET_POINT_TITLE}</strong><span style="display: inline-block; width: 6px; height: 6px; background-color: {COLOR}; margin-left: 15px;"></span></section></section><p style="margin:0;line-height:2;"><br></p>

<!-- Repeat the following paragraph + image block 1 or 2 times per bullet point according to your gathered content -->
<p style="margin:0; text-align: left; word-wrap: break-word;">{BULLET_POINT_CONTENT_PARAGRAPH}</p><p style="margin:0;line-height:2;"><br></p><section style="margin: 0; text-align: center; line-height: 0;"><img src="{IMAGE_URL}" style="width: 100%; max-width: 100%; height: auto; box-sizing: border-box; display: inline-block; border-radius: 0; box-shadow: none;" alt="feature image"/></section><p style="margin:0;line-height:2;"><br></p>
```
*(Aim for 2 paragraphs and 2 images per bullet point. If content is scarce, use 1 paragraph and 1 image. Each bullet point MUST have at least 1 image.)*

## Conclusion / Interactive Block

Append this at the very end of `{CONTENT}`. It uses the same layout style as the body text, with the interaction call-to-action text wrapped in `<strong style="color: {COLOR};">`.

```html
<p style="margin:0; text-align: left; word-wrap: break-word;">{ARTICLE_SUMMARY_TEXT} <strong style="color: {COLOR};">{CALL_TO_ACTION_TEXT}</strong></p><p style="margin:0;line-height:2;"><br></p>
```

## Formatting Rules

1. **Variables**: 
    - `{INDEX_NUMBER}` must be "01", "02", "03", etc.
    - `{BULLET_POINT_TITLE}` must be concise (e.g., "iPhone 17e").
    - `{COLOR}` is `#006fff` for Blue, `#00b050` for Green.
2. **Authentic Images ONLY**: The `IMAGE_URL` MUST be an original image extracted from the source link that explicitly fits the point.
3. **Typography Rule**: Ensure the `<section>` wrapper always strictly uses `font-family: 'Microsoft YaHei'...` with `font-size: 15px;`, `line-height: 2;` and `letter-spacing: 1px;`.
4. **No Image Styles**: All images MUST have NO `border-radius` and NO `box-shadow` (square corners, no shadows), strictly matching the specified native layout style.
