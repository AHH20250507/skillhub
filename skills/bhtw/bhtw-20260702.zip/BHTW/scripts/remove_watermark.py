import argparse
import os
import sys
import subprocess

def install_and_import(package, import_name):
    try:
        __import__(import_name)
    except ImportError:
        print(f"Installing missing dependency: {package}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
    finally:
        globals()[import_name] = __import__(import_name)

# Auto-install dependencies if running externally
install_and_import('opencv-python', 'cv2')
install_and_import('easyocr', 'easyocr')
install_and_import('requests', 'requests')
install_and_import('numpy', 'numpy')

import cv2
import easyocr
import requests
import numpy as np
import re

def upload_image_to_freeimage(img_array):
    _, buffer = cv2.imencode('.jpg', img_array, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    url = "https://freeimage.host/api/1/upload"
    data = {
        "key": "6d207e02198a847aa98d0a2a901485a5",
        "action": "upload"
    }
    files = {
        "source": ("image.jpg", buffer.tobytes(), "image/jpeg")
    }
    try:
        response = requests.post(url, data=data, files=files, timeout=30)
        if response.status_code == 200:
            res_json = response.json()
            if res_json.get("status_code") == 200:
                original_url = res_json["image"]["url"]
                url_no_proto = original_url.replace("https://", "").replace("http://", "")
                return f"https://i0.wp.com/{url_no_proto}"
        return None
    except Exception as e:
        print(f"Upload exception: {e}")
        return None

def remove_watermark_from_image(image_bytes, watermark_texts=["it之家", "ithome", "www.ithome.com"]):
    nparr = np.frombuffer(image_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    if img is None:
        return None
    
    # Init OCR
    reader = easyocr.Reader(['ch_sim', 'en'], gpu=False, verbose=False)
    results = reader.readtext(img)
    
    mask = np.zeros(img.shape[:2], dtype=np.uint8)
    height, width = img.shape[:2]
    watermark_found = False
    
    for (bbox, text, prob) in results:
        is_watermark = False
        text_lower = text.lower().replace(" ", "")
        
        for w in watermark_texts:
            if w.lower() in text_lower:
                is_watermark = True
                break
                
        (tl, tr, br, bl) = bbox
        box_min_x, box_max_x = int(min(tl[0], bl[0])), int(max(tr[0], br[0]))
        box_min_y, box_max_y = int(min(tl[1], tr[1])), int(max(bl[1], br[1]))
        
        # Aggressive checking for IT Home structure and location
        if not is_watermark:
            if box_min_x > width * 0.65 and ((box_max_y < height * 0.3) or (box_min_y > height * 0.7)):
                is_watermark = True
        
        if is_watermark:
            watermark_found = True
            pad_x = 20
            pad_y_bottom = 20
            # Expand significantly upwards for IT Home because of the graphic logo above text
            pad_top = 110 if any(w in text_lower for w in ["ithome", "it之家", "www"]) else 20
            
            pts = np.array([
                [max(0, box_min_x - pad_x), max(0, box_min_y - pad_top)],
                [min(width, box_max_x + pad_x), max(0, box_min_y - pad_top)],
                [min(width, box_max_x + pad_x), min(height, box_max_y + pad_y_bottom)],
                [max(0, box_min_x - pad_x), min(height, box_max_y + pad_y_bottom)]
            ], np.int32)
            
            cv2.fillPoly(mask, [pts], 255)
            
    if watermark_found:
        # Refine mask and inpaint
        kernel = np.ones((5,5), np.uint8)
        mask = cv2.dilate(mask, kernel, iterations=1)
        result_img = cv2.inpaint(img, mask, inpaintRadius=9, flags=cv2.INPAINT_TELEA)
        return upload_image_to_freeimage(result_img)
    else:
        return upload_image_to_freeimage(img)

def process_html_file(input_html, output_html=None):
    if not output_html:
        output_html = input_html
        
    print(f"Processing HTML file: {input_html}")
    
    with open(input_html, 'r', encoding='utf-8', errors='replace') as f:
        html_content = f.read()
        
    img_tags = re.findall(r'<img[^>]+src=[\'"]([^\'"]+)[\'"]', html_content)
    
    print(f"Found {len(img_tags)} images in {input_html}")
    
    for idx, src in enumerate(set(img_tags)):
        if src.startswith('data:') or not src.startswith('http'):
            continue
            
        # Clean URL if it contains BCE watermark process before downloading
        clean_src = src.split('?x-bce-process')[0]
        if 'x-bce-process=image/watermark' in src and '/format' in src:
            parts = src.split('x-bce-process=image/watermark')
            rest = parts[1]
            if '/format' in rest:
                clean_src = f"{parts[0]}x-bce-process=image{rest[rest.index('/format'):]}"

        lower_src = clean_src.lower()
        if any(x in lower_src for x in ['logo', 'icon', 'avatar', '.gif']):
            continue
            
        print(f"[{idx+1}/{len(img_tags)}] Unwatermarking: {clean_src}")
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Referer': 'https://www.ithome.com/'
        }
        
        try:
            import urllib3
            urllib3.disable_warnings()
            response = requests.get(clean_src, headers=headers, timeout=15, verify=False)
            if response.status_code == 200:
                new_src = remove_watermark_from_image(response.content)
                if new_src:
                    html_content = html_content.replace(src, new_src)
                    print(f" -> Success! Uploaded to {new_src}")
                else:
                    print(f" -> Failed to upload cleaned image.")
            else:
                print(f" -> Failed to download.")
        except Exception as e:
            print(f" -> Error: {e}")
            
    with open(output_html, 'w', encoding='utf-8') as f:
        f.write(html_content)
    print(f"Saved modified HTML to: {output_html}")
    return output_html

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_html', required=True)
    parser.add_argument('--output_html')
    args = parser.parse_args()
    process_html_file(args.input_html, args.output_html)
