# XD 知识库技能 · 分发说明

一个把本地 PDF 文档集变成可检索 RAG 知识库的 WorkBuddy/通用 skill。被触发后先检索原文片段、再只依据片段作答并标注出处，不编造。

## 一键安装（给需要安装的 agent）

把下面这句发给对方即可（只需这一句，无需第二句）：

```bash
curl -fsSL "https://raw.githubusercontent.com/<你的用户名>/<仓库>/main/skills/xd/xd-skill.zip" -o /tmp/xd-skill.zip && unzip -o /tmp/xd-skill.zip -d ~/.qoderworkcn/skills/xd && rm /tmp/xd-skill.zip
```

- 解压后技能位于 `~/.qoderworkcn/skills/xd/`
- **首次使用时，技能会自动下载并准备好运行环境（Python 依赖 + 约 184M 中文模型，需联网，一次性，约几分钟）**，之后即可直接提问，无需人工干预。
- 把 `<你的用户名>/<仓库>` 换成你 GitHub 上实际存放 zip 的路径。

## 使用

```bash
# 在技能目录内
python xd.py query "你的问题" --k 6
# 或从任意目录用绝对路径
python ~/.qoderworkcn/skills/xd/xd.py query "你的问题" --k 6
```

Agent 视角：当问题涉及知识库主题时，运行上面的 `query` 命令，依据返回片段（每条带 `来源` 文件名+页码）作答，并标注出处。

## 更新（已安装的 agent 如何同步最新知识库）

知识库索引（`kb_data/`）随 zip 一起分发。**作者改了 PDF 并重新上传 zip 后，已安装的 agent 只需刷新一次即可**，无需重装、无需重新下载模型：

**方式 A（最简单，推荐）**：把安装那句 curl 原样再发一次。

```bash
curl -fsSL "https://raw.githubusercontent.com/<你的用户名>/<仓库>/main/skills/xd/xd-skill.zip" -o /tmp/xd-skill.zip && unzip -o /tmp/xd-skill.zip -d ~/.qoderworkcn/skills/xd && rm /tmp/xd-skill.zip
```

`unzip -o` 会覆盖 `kb_data/` 与脚本，但 **不动** `.venv`、模型、`~/.workbuddy/kb_models`、`.xd_ready`——所以覆盖后直接 `query` 即可，环境仍在。

**方式 B（自更新）**：作者先在 `xd_update_url.txt` 写入稳定 zip 地址（或装好环境变量 `XD_ZIP_URL`），之后 agent 执行：

```bash
python xd.py update
```

该命令下载最新 zip 并就地覆盖（`kb_data/` + 代码），同样保留运行环境与模型。

> 注意：更新地址必须是「稳定」URL（文件名不要带日期，如 `xd-skill.zip`），否则 `update` 会指向旧文件。

## 作者重发流程（你改了 PDF / 脚本后）

```bash
# 1. 改 PDF 后重建索引（知识库内容变化必须重建）
python xd.py build --rebuild

# 2. 重新打包（生成 6.5M 的 xd-skill.zip，不含模型/venv）
python package.py

# 3. 把新的 xd-skill.zip 上传到 GitHub 同一稳定地址
# 4. 通知已安装的 agent 跑一次「方式 A」或「方式 B」
```

## 重新打包（你更新了 PDF 或脚本后）

```bash
python XD/package.py --output XD/xd-skill.zip
```

`package.py` 会把技能目录打成扁平 zip，**自动排除** `.venv`、`models/`、缓存、`.xd_ready` 等运行时产物，只保留可分发文件（约 10M），适合上传 GitHub。

> 为什么 zip 里不含模型（184M）和依赖？
> - GitHub 对单文件大小有限制，184M 的包不利于分发；
> - 模型与依赖在首次使用时按需下载，既保证 zip 小巧，又保证跨平台（Windows/macOS/Linux 的依赖轮子不同，不能预先打成一个包）。

## 离线部署（可选）

若目标机器完全无法联网，标准包不可用。此时需另行生成离线包：把 `models/bge-small-zh-v1.5/` 嵌入技能目录，并打包与目标系统匹配的依赖轮子，再让 `setup.py` 从本地安装。该场景需分平台制作，默认不提供，按需处理。

## 维护

源 PDF 目录通过环境变量 `XD_PDF_DIR` 指定。改动 PDF 后：

```bash
python xd.py build          # 增量更新
python xd.py build --rebuild # 全量重建
```

已删除文件的旧片段会被自动清理。
