"""Package the XD skill into a flat, distribution-ready zip.

The zip contains only the skill source + index (kb_data), and EXCLUDES all
runtime artifacts (.venv, downloaded model, caches, markers). The model and
Python deps are fetched automatically on first use via setup.py, so they must
NOT be baked into the distributable.

The archive is FLAT (skill files at the root) so that
    unzip -d ~/.qoderworkcn/skills/xd xd-skill.zip
places SKILL.md directly at ~/.qoderworkcn/skills/xd/SKILL.md.

Usage:
    python package.py [--source DIR] [--output PATH]
"""
import os
import sys
import zipfile
import argparse
import fnmatch

EXCLUDE_DIRS = {".venv", "models", "__pycache__", ".cache", ".git",
                "dist", "build", ".idea", ".vscode"}
EXCLUDE_FILES = {".xd_ready", ".xd_ready.txt"}
EXCLUDE_PATTERNS = ["*.pyc", "*.pyo", "*.zip", "*.tmp", "*.log",
                    "Thumbs.db", ".DS_Store", "*.egg-info"]


def should_exclude(name, is_dir):
    if is_dir and name in EXCLUDE_DIRS:
        return True
    if not is_dir and name in EXCLUDE_FILES:
        return True
    if not is_dir:
        for pat in EXCLUDE_PATTERNS:
            if fnmatch.fnmatch(name, pat):
                return True
    return False


def main():
    ap = argparse.ArgumentParser()
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--source", default=here,
                    help="skill source directory (default: this script's dir)")
    ap.add_argument("--output", default=os.path.join(here, "..", "xd-skill.zip"),
                    help="output zip path (default: ../xd-skill.zip)")
    args = ap.parse_args()

    src = os.path.abspath(args.source)
    out = os.path.abspath(args.output)
    if not os.path.isdir(src):
        sys.stderr.write(f"source not found: {src}\n")
        sys.exit(1)
    if os.path.exists(out):
        os.remove(out)

    total = 0
    count = 0
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for root, dirs, files in os.walk(src):
            dirs[:] = [d for d in dirs if not should_exclude(d, True)]
            for f in files:
                if should_exclude(f, False):
                    continue
                full = os.path.join(root, f)
                arc = os.path.relpath(full, src)
                if arc.startswith(".."):
                    continue
                z.write(full, arc)
                total += os.path.getsize(full)
                count += 1

    size_mb = os.path.getsize(out) / 1e6
    print(f"[package] wrote {out}")
    print(f"[package] {count} files, {total/1e6:.1f} MB uncompressed, "
          f"{size_mb:.1f} MB zipped")
    print("[package] runtime (.venv / model / caches) excluded by design; "
          "fetched automatically on first use.")


if __name__ == "__main__":
    main()
