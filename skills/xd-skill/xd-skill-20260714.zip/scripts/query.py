"""Query the XD knowledge base and print the most relevant PDF passages.

Usage:
    python query.py "你的问题"
    python query.py "你的问题" --k 6
    python query.py "你的问题" --json

Output: the top-K passages, each with its source PDF file name and page number,
so the agent can answer strictly from these snippets and cite them.
Hybrid retrieval = BM25 keyword score + semantic vector score (when available).
"""
import os
import sys
import json
import pickle
import argparse
import warnings

warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    BM25_PATH, EMB_PATH, EMB_META_PATH, EMB_MODEL_NAME,
    tokenize, load_chunks,
)


def _minmax(scores):
    lo, hi = min(scores), max(scores)
    if hi - lo < 1e-9:
        return [0.0 for _ in scores]
    return [(s - lo) / (hi - lo) for s in scores]


def bm25_scores(query, n):
    if not os.path.exists(BM25_PATH):
        return None
    with open(BM25_PATH, "rb") as f:
        data = pickle.load(f)
    bm25 = data.get("bm25")
    if bm25 is None:
        return None
    return list(bm25.get_scores(tokenize(query)))


def vector_scores(query, n):
    if not (os.path.exists(EMB_PATH) and os.path.exists(EMB_META_PATH)):
        return None
    try:
        import numpy as np
        from sentence_transformers import SentenceTransformer
    except Exception:
        return None
    try:
        with open(EMB_META_PATH, "r", encoding="utf-8") as f:
            meta = json.load(f)
        emb = np.load(EMB_PATH)
        if emb.shape[0] != n:
            return None
        # Always encode the query with the model resolved by common.py
        # (not the path baked into emb_meta.json, which may not exist after
        # the skill is moved to another machine).
        model = SentenceTransformer(EMB_MODEL_NAME)
        q = model.encode([query], normalize_embeddings=True)
        sims = (emb @ q[0].astype("float32"))
        return list(map(float, sims))
    except Exception:
        return None


def search(query, k=5):
    chunks = load_chunks()
    n = len(chunks)
    if n == 0:
        return [], "empty"

    bm = bm25_scores(query, n)
    vec = vector_scores(query, n)

    if bm is not None and vec is not None:
        bm_n, vec_n = _minmax(bm), _minmax(vec)
        combined = [0.5 * a + 0.5 * b for a, b in zip(bm_n, vec_n)]
        mode = "hybrid (bm25+vector)"
    elif bm is not None:
        combined = bm
        mode = "bm25 only"
    elif vec is not None:
        combined = vec
        mode = "vector only"
    else:
        return [], "no-index"

    order = sorted(range(n), key=lambda i: combined[i], reverse=True)[:k]
    results = []
    for rank, i in enumerate(order, start=1):
        c = chunks[i]
        results.append({
            "rank": rank,
            "score": round(float(combined[i]), 4),
            "source": c["source"],
            "page": c["page"],
            "text": c["text"],
        })
    return results, mode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("question")
    ap.add_argument("--k", type=int, default=5)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    results, mode = search(args.question, args.k)

    if args.json:
        print(json.dumps({"mode": mode, "results": results},
                         ensure_ascii=False, indent=2))
        return

    if not results:
        print(f"(no results; retrieval mode = {mode}) "
              f"Run build_index.py first if the index is empty.")
        return

    print(f"# 检索模式: {mode} | 问题: {args.question}\n")
    for r in results:
        print(f"--- [{r['rank']}] 来源: {r['source']} · 第 {r['page']} 页 "
              f"(score {r['score']}) ---")
        print(r["text"])
        print()


if __name__ == "__main__":
    main()
