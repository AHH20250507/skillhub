"""Build / update the XD knowledge base index from a folder of PDFs.

Usage:
    python build_index.py                 # incremental update (default folder)
    python build_index.py --rebuild       # full rebuild from scratch
    python build_index.py --pdf-dir PATH  # use a different PDF folder

What it does:
  1. Scans the PDF folder, compares file hashes against the manifest.
  2. Extracts text from new/changed PDFs (page-aware), splits into chunks.
  3. Drops chunks belonging to removed/changed files (clean delete).
  4. Rebuilds the BM25 index over all chunks.
  5. Tries to build a semantic vector index; skips gracefully if unavailable.
"""
import os
import sys
import glob
import pickle
import argparse
import warnings

warnings.filterwarnings("ignore")

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import (  # noqa: E402
    DEFAULT_PDF_DIR, KB_DIR, BM25_PATH, EMB_PATH, EMB_META_PATH, EMB_MODEL_NAME,
    file_md5, tokenize, load_chunks, save_chunks, load_manifest, save_manifest,
)

CHUNK_SIZE = 480      # target characters per chunk
CHUNK_OVERLAP = 80    # overlap between consecutive chunks
MIN_CHUNK = 30        # ignore chunks shorter than this


def extract_pages(path):
    """Return list of (page_number, text) with 1-based page numbers."""
    import pdfplumber
    out = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            txt = page.extract_text() or ""
            out.append((i, txt))
    return out


def clean(text):
    lines = [ln.strip() for ln in text.splitlines()]
    lines = [ln for ln in lines if ln]
    return "\n".join(lines)


def chunk_page(text):
    """Split a page's text into overlapping chunks by paragraph boundaries."""
    text = clean(text)
    if not text:
        return []
    paras = [p.strip() for p in text.split("\n") if p.strip()]
    chunks, buf = [], ""
    for p in paras:
        if len(buf) + len(p) + 1 <= CHUNK_SIZE:
            buf = (buf + "\n" + p) if buf else p
        else:
            if buf:
                chunks.append(buf)
            if len(p) <= CHUNK_SIZE:
                buf = p
            else:
                # hard-split an over-long paragraph
                for i in range(0, len(p), CHUNK_SIZE - CHUNK_OVERLAP):
                    chunks.append(p[i:i + CHUNK_SIZE])
                buf = ""
    if buf:
        chunks.append(buf)
    return [c for c in chunks if len(c) >= MIN_CHUNK]


def build_chunks_for_file(path):
    fname = os.path.basename(path)
    result = []
    for page_no, text in extract_pages(path):
        for c in chunk_page(text):
            result.append({"source": fname, "page": page_no, "text": c})
    return result


def build_bm25(chunks):
    from rank_bm25 import BM25Okapi
    corpus = [tokenize(c["text"]) for c in chunks]
    bm25 = BM25Okapi(corpus) if corpus else None
    with open(BM25_PATH, "wb") as f:
        pickle.dump({"bm25": bm25, "n": len(chunks)}, f)
    print(f"[bm25] indexed {len(chunks)} chunks -> {BM25_PATH}")


def build_vectors(chunks):
    """Try to build semantic embeddings. Returns True on success."""
    if os.environ.get("XD_SKIP_VECTORS") == "1":
        print("[vector] XD_SKIP_VECTORS=1 set; skipping semantic index this run.")
        return False
    try:
        import numpy as np
        from sentence_transformers import SentenceTransformer
    except Exception as e:
        print(f"[vector] sentence-transformers unavailable ({e}); "
              f"skipping semantic index. BM25 keyword search will still work.")
        _clear_vectors()
        return False
    try:
        print(f"[vector] loading model {EMB_MODEL_NAME} (first run may download)...")
        model = SentenceTransformer(EMB_MODEL_NAME)
        texts = [c["text"] for c in chunks]
        emb = model.encode(texts, batch_size=32, show_progress_bar=True,
                           normalize_embeddings=True)
        emb = np.asarray(emb, dtype="float32")
        np.save(EMB_PATH, emb)
        import json
        with open(EMB_META_PATH, "w", encoding="utf-8") as f:
            json.dump({"model": EMB_MODEL_NAME, "n": len(chunks),
                       "dim": int(emb.shape[1])}, f, ensure_ascii=False, indent=2)
        print(f"[vector] embedded {len(chunks)} chunks, dim={emb.shape[1]}")
        return True
    except Exception as e:
        print(f"[vector] embedding failed ({e}); falling back to BM25 only.")
        _clear_vectors()
        return False


def _clear_vectors():
    for p in (EMB_PATH, EMB_META_PATH):
        if os.path.exists(p):
            os.remove(p)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--pdf-dir", default=DEFAULT_PDF_DIR)
    ap.add_argument("--rebuild", action="store_true",
                    help="ignore manifest and rebuild everything")
    args = ap.parse_args()

    os.makedirs(KB_DIR, exist_ok=True)
    pdf_dir = args.pdf_dir
    if not os.path.isdir(pdf_dir):
        print(f"ERROR: PDF folder not found: {pdf_dir}")
        sys.exit(1)

    files = sorted(glob.glob(os.path.join(pdf_dir, "*.pdf")))
    print(f"[scan] {len(files)} PDF(s) in {pdf_dir}")

    manifest = {} if args.rebuild else load_manifest()
    chunks = [] if args.rebuild else load_chunks()

    current = {}
    for f in files:
        current[os.path.basename(f)] = file_md5(f)

    # Determine what to (re)process and what to drop.
    to_process, unchanged, removed = [], [], []
    for name, h in current.items():
        if manifest.get(name) == h:
            unchanged.append(name)
        else:
            to_process.append(name)
    for name in list(manifest.keys()):
        if name not in current:
            removed.append(name)

    if removed:
        print(f"[delete] removing chunks of {len(removed)} deleted file(s): {removed}")
    # Drop chunks of removed OR changed files, then re-add fresh ones.
    drop = set(removed) | set(to_process)
    if drop:
        chunks = [c for c in chunks if c["source"] not in drop]

    skipped_scanned = []
    for name in to_process:
        path = os.path.join(pdf_dir, name)
        print(f"[extract] {name}")
        new_chunks = build_chunks_for_file(path)
        if not new_chunks:
            skipped_scanned.append(name)
            print(f"    ! no extractable text (likely scanned image PDF) -> skipped")
        chunks.extend(new_chunks)

    # Reassign stable ids.
    for i, c in enumerate(chunks):
        c["id"] = i

    save_chunks(chunks)
    # Manifest reflects only files we actually kept (present + extractable or not).
    new_manifest = {name: current[name] for name in current}
    save_manifest(new_manifest)

    print(f"[chunks] total {len(chunks)} chunks from "
          f"{len(current) - len(skipped_scanned)} readable file(s)")

    build_bm25(chunks)
    build_vectors(chunks)

    print("\n=== BUILD SUMMARY ===")
    print(f"PDF folder     : {pdf_dir}")
    print(f"Files total    : {len(current)}")
    print(f"Newly processed: {len(to_process)}  Unchanged: {len(unchanged)}  "
          f"Removed: {len(removed)}")
    print(f"Total chunks   : {len(chunks)}")
    if skipped_scanned:
        print(f"Scanned/empty (no text, need OCR): {skipped_scanned}")
    print("Done.")


if __name__ == "__main__":
    main()
