"""Shared helpers for the XD knowledge-base skill."""
import os
import re
import json
import hashlib

# Resolve important paths relative to this script, so the skill is portable.
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SKILL_ROOT = os.path.dirname(SCRIPT_DIR)
KB_DIR = os.path.join(SKILL_ROOT, "kb_data")

# Default source folder for the PDFs. Can be overridden via env var XD_PDF_DIR.
DEFAULT_PDF_DIR = os.environ.get(
    "XD_PDF_DIR", r"C:\Users\21010\Desktop\PDF"
)

CHUNKS_PATH = os.path.join(KB_DIR, "chunks.jsonl")
MANIFEST_PATH = os.path.join(KB_DIR, "manifest.json")
BM25_PATH = os.path.join(KB_DIR, "bm25.pkl")
EMB_PATH = os.path.join(KB_DIR, "embeddings.npy")
EMB_META_PATH = os.path.join(KB_DIR, "emb_meta.json")

# Model resolution order (to keep the skill package small, prefer a single
# shared model copy over a per-skill duplicate):
#   1. explicit env override XD_EMB_MODEL
#   2. shared model at ~/.workbuddy/kb_models (used by the 知识库创建skill too)
#   3. local models/ folder bundled with this skill
#   4. HF hub id (will try to download)
_APP_DATA = os.path.join(os.path.expanduser("~"), ".workbuddy")
_SHARED_MODEL_DIR = os.path.join(_APP_DATA, "kb_models", "BAAI_bge-small-zh-v1.5")
_LOCAL_MODEL_DIR = os.path.join(SKILL_ROOT, "models", "bge-small-zh-v1.5")
if os.environ.get("XD_EMB_MODEL"):
    EMB_MODEL_NAME = os.environ["XD_EMB_MODEL"]
elif os.path.isdir(_SHARED_MODEL_DIR):
    EMB_MODEL_NAME = _SHARED_MODEL_DIR
elif os.path.isdir(_LOCAL_MODEL_DIR):
    EMB_MODEL_NAME = _LOCAL_MODEL_DIR
else:
    EMB_MODEL_NAME = "BAAI/bge-small-zh-v1.5"


def file_md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


_tokenizer = None


def tokenize(text):
    """Chinese-friendly tokenizer using jieba, falling back to char/space split."""
    global _tokenizer
    if _tokenizer is None:
        try:
            import jieba
            jieba.initialize()
            _tokenizer = lambda s: [w for w in jieba.lcut(s) if w.strip()]
        except Exception:
            _tokenizer = lambda s: re.findall(r"[\u4e00-\u9fff]|[a-zA-Z0-9]+", s)
    return _tokenizer(text)


def load_chunks():
    chunks = []
    if os.path.exists(CHUNKS_PATH):
        with open(CHUNKS_PATH, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    chunks.append(json.loads(line))
    return chunks


def save_chunks(chunks):
    os.makedirs(KB_DIR, exist_ok=True)
    with open(CHUNKS_PATH, "w", encoding="utf-8") as f:
        for c in chunks:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")


def load_manifest():
    if os.path.exists(MANIFEST_PATH):
        with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_manifest(m):
    os.makedirs(KB_DIR, exist_ok=True)
    with open(MANIFEST_PATH, "w", encoding="utf-8") as f:
        json.dump(m, f, ensure_ascii=False, indent=2)
