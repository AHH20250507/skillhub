"""One-time setup for the XD knowledge-base skill.

Makes the skill self-contained on a new machine:
  1. creates a local Python venv (.venv) and installs dependencies
  2. makes sure the Chinese embedding model is available
     (reuses a shared copy if present, otherwise downloads it)

Idempotent: safe to run again. After this, use `xd.bat` / `xd.sh` to query/build.

Usage:
    python setup.py          # or:  python3 setup.py
"""
import os
import sys
import subprocess

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(SKILL_DIR, ".venv")
if os.name == "nt":
    VENV_PY = os.path.join(VENV, "Scripts", "python.exe")
else:
    VENV_PY = os.path.join(VENV, "bin", "python")

# Convenience: on the original machine a prebuilt venv already exists under
# ~/.workbuddy. Reusing it avoids a second multi-GB torch install.
SHARED_VENV = os.path.expanduser(
    "~/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe"
)

DEPS = [
    "pdfplumber", "jieba", "rank_bm25", "numpy", "tqdm",
    "sentence-transformers", "torch",
]


def log(msg):
    print(f"[setup] {msg}")


def ensure_venv():
    if os.path.exists(VENV_PY):
        log(f"venv already present: {VENV_PY}")
        return VENV_PY
    if os.path.exists(SHARED_VENV):
        log(f"reusing prebuilt venv on this machine: {SHARED_VENV}")
        return SHARED_VENV
    log("creating local venv...")
    subprocess.run([sys.executable, "-m", "venv", VENV], check=True)
    log("installing dependencies (this downloads torch, may take a while)...")
    subprocess.run([VENV_PY, "-m", "pip", "install", "-q", "--upgrade", "pip"], check=True)
    subprocess.run([VENV_PY, "-m", "pip", "install", "-q"] + DEPS, check=True)
    return VENV_PY


def ensure_model():
    shared = os.path.expanduser("~/.workbuddy/kb_models/BAAI_bge-small-zh-v1.5")
    local = os.path.join(SKILL_DIR, "models", "bge-small-zh-v1.5")
    if os.path.isdir(shared):
        log("embedding model found in shared location; will be reused.")
        return
    if os.path.isdir(local):
        log("embedding model already bundled with the skill.")
        return
    log("downloading Chinese embedding model (BAAI/bge-small-zh-v1.5)...")
    os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
    os.environ["HF_HUB_DISABLE_XET"] = "1"
    try:
        from huggingface_hub import snapshot_download
        snapshot_download(
            "BAAI/bge-small-zh-v1.5",
            local_dir=local,
            local_dir_use_symlinks=False,
        )
    except Exception as e:  # pragma: no cover
        log(f"model download failed: {e}")
        log("You can set XD_EMB_MODEL to a local model dir, or run with internet access.")
        raise


def main():
    py = ensure_venv()
    ensure_model()
    # sanity check that retrieval imports work
    subprocess.run(
        [py, "-c", "import pdfplumber, jieba, rank_bm25, numpy, sentence_transformers; print('deps OK')"],
        check=True,
    )
    # write a marker so the launcher can skip re-checking on future runs
    try:
        with open(os.path.join(SKILL_DIR, ".xd_ready"), "w", encoding="utf-8") as f:
            f.write("1\n")
    except Exception:
        pass
    log("setup complete. Use xd.bat (Windows) or xd.sh (mac/linux) to query/build.")


if __name__ == "__main__":
    main()
