@echo off
chcp 65001 >nul
set "DIR=%~dp0"
if exist "%DIR%.venv\Scripts\python.exe" (set "PY=%DIR%.venv\Scripts\python.exe") else if exist "%USERPROFILE%\.workbuddy\binaries\python\envs\pdfkb\Scripts\python.exe" (set "PY=%USERPROFILE%\.workbuddy\binaries\python\envs\pdfkb\Scripts\python.exe") else (set "PY=python")
"%PY%" "%DIR%xd.py" %*
