#!/usr/bin/env bash
# Thin POSIX wrapper: run the Python launcher with the system python3.
set -euo pipefail
DIR="$(cd "$(dirname "$0")" && pwd)/"
exec python3 "${DIR}xd.py" "$@"
