"""Cross-platform launcher for the XD knowledge-base skill.

Resolves (or bootstraps) the Python environment that has the dependencies,
then dispatches to the requested script. Path-agnostic: the skill folder can
live anywhere -- e.g. unzipped into any agent's skills directory.

On first use, if the runtime is not ready, it automatically runs setup.py
(which creates a local .venv and downloads the Chinese model). This makes a
plain "download + unzip" install fully functional with no extra command.

The knowledge-base index lives in kb_data/ and ships inside the zip. When the
author updates the KB, they repackage + re-upload; installed agents refresh
with a single command:

    python xd.py update        # pulls the latest zip and overwrites kb_data + code
                               # (.venv / model / .xd_ready are preserved)

Usage:
    python xd.py query "你的问题" --k 6
    python xd.py build
    python xd.py build --rebuild
    python xd.py setup
    python xd.py update
"""
import os
import sys
import subprocess
import urllib.request
import tempfile
import zipfile

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
READY_MARKER = os.path.join(SKILL_DIR, ".xd_ready")
UPDATE_URL_FILE = os.path.join(SKILL_DIR, "xd_update_url.txt")

if os.name == "nt":
    VENV_PY = os.path.join(SKILL_DIR, ".venv", "Scripts", "python.exe")
    SHARED_PY = os.path.expanduser(
        "~/.workbuddy/binaries/python/envs/pdfkb/Scripts/python.exe"
    )
else:
    VENV_PY = os.path.join(SKILL_DIR, ".venv", "bin", "python")
    SHARED_PY = os.path.expanduser(
        "~/.workbuddy/binaries/python/envs/pdfkb/bin/python"
    )


def resolve_py():
    if os.path.exists(VENV_PY):
        return VENV_PY
    if os.path.exists(SHARED_PY):
        return SHARED_PY
    return None


def runtime_ready(py):
    """True if `py` can import all required dependencies."""
    if not py or not os.path.exists(py):
        return False
    try:
        subprocess.run(
            [py, "-c",
             "import pdfplumber, jieba, rank_bm25, numpy, sentence_transformers"],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        return True
    except Exception:
        return False


def ensure_ready():
    """Return a python that can run the skill, bootstrapping if needed.

    Trust the .xd_ready marker (fast path). Fall back to a live import check
    for environments that already have the deps (e.g. this machine's shared
    venv). If neither, run the one-time setup.
    """
    py = resolve_py()
    if py and (os.path.exists(READY_MARKER) or runtime_ready(py)):
        return py
    sys.stderr.write(
        "[xd] 首次使用，正在准备 Python 环境与中文模型"
        "（需联网，一次性，约几分钟）...\n"
    )
    subprocess.run([sys.executable, os.path.join(SKILL_DIR, "setup.py")], check=True)
    py = resolve_py()
    if not (py and (os.path.exists(READY_MARKER) or runtime_ready(py))):
        sys.stderr.write(
            "[xd] 环境准备失败。请检查网络后重试，或手动运行：python setup.py\n"
        )
        sys.exit(2)
    return py


def get_update_url():
    """Update URL precedence: env XD_ZIP_URL > xd_update_url.txt > none."""
    url = os.environ.get("XD_ZIP_URL")
    if url:
        return url.strip()
    if os.path.exists(UPDATE_URL_FILE):
        with open(UPDATE_URL_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#"):
                    return line
    return None


def cmd_update():
    """Download the latest zip and extract it over this skill folder.

    Only files present in the zip are overwritten (code + kb_data). Runtime
    artifacts that are NOT in the zip (.venv, models, .xd_ready) survive, so
    no re-setup is needed after an update.
    """
    url = get_update_url()
    if not url or url.upper().startswith("REPLACE"):
        sys.stderr.write(
            "[xd] 未配置更新地址。请二选一：\n"
            "  1) 在 xd_update_url.txt 中填写稳定的 zip 下载地址；\n"
            "  2) 设置环境变量 XD_ZIP_URL=https://.../xd-skill.zip ；\n"
            "  或重新执行安装命令（curl ... && unzip -o ...）完成更新。\n"
        )
        sys.exit(3)

    sys.stderr.write(f"[xd] 正在从 {url} 拉取更新...\n")
    tmp_path = tempfile.NamedTemporaryFile(delete=False, suffix=".zip").name
    try:
        urllib.request.urlretrieve(url, tmp_path)
        with zipfile.ZipFile(tmp_path, "r") as z:
            z.extractall(SKILL_DIR)
        sys.stderr.write(
            "[xd] 更新完成：知识库与代码已覆盖；Python 环境与模型已保留，"
            "无需重新 setup。\n"
        )
    finally:
        if os.path.exists(tmp_path):
            os.remove(tmp_path)


def main():
    args = sys.argv[1:]
    if not args:
        print("Usage: xd.py [query | build | setup | update] [args...]")
        sys.exit(1)

    cmd = args[0]
    rest = args[1:]

    if cmd == "setup":
        rc = subprocess.run(
            [sys.executable, os.path.join(SKILL_DIR, "setup.py")]
        ).returncode
        sys.exit(rc)

    if cmd == "update":
        cmd_update()
        sys.exit(0)

    if cmd not in ("query", "build"):
        sys.stderr.write(f"Unknown command: {cmd}\n")
        sys.stderr.write("Usage: xd.py [query | build | setup | update] [args...]\n")
        sys.exit(1)

    py = ensure_ready()

    if cmd == "query":
        target = os.path.join(SKILL_DIR, "scripts", "query.py")
    else:
        target = os.path.join(SKILL_DIR, "scripts", "build_index.py")

    rc = subprocess.run([py, target] + rest).returncode
    sys.exit(rc)


if __name__ == "__main__":
    main()
