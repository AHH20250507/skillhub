---
name: ZXTW
description: A two-in-one skill that curates mobile tech news from links into specific WeChat article layouts (Blue and Green exact layouts), with ML-based watermark removal and CDN image hosting.
---

# ZXTW (Watermark-Free News Curator)

This is an advanced composite skill designed for WeChat official account editors. It transforms a raw list of mobile tech news links into professionally formatted, ready-to-publish WeChat article compilations.

## Key Features
- **Exact Layout Replication**: Mirrors provided reference styles (Blue and Green) with 100% fidelity.
- **Optimized Spacing**: The Green layout features a single blank line between the title and body, as requested.
- **Surgical Watermark Removal (v4)**: Uses high-precision block-based ROI (Region of Interest) masking to ensure 100% removal of IT之家 branding with seamless inpainting.
- **Cloud-Ready**: Uploads all cleaned images to a high-speed CDN for immediate use in any editor.

## Workflow

When provided with a list of links, **automatically start working without asking for further confirmation**. Follow these steps:

### 1. Analysis and Synthesis
- Read the content of the provided articles.
- Extract core info and source URLs.
- **Constraint**: Strictly exclude "it之家", "IT之家", or "ITHOME" from all generated text.
- **Humanization**: For all titles and summaries, you MUST invoke the `Humanizer-zh-main` skill to remove AI-generated traces and ensure a **formal** (正式) tone before proceeding to JSON export.

### 2. Export to Structured JSON
Summarize the news into a JSON file at `scratch/news_data.json`:
```json
[
  {
    "index": "01",
    "title": "[Engaging Title]",
    "summary": "[Concise Summary]",
    "source_url": "[Original Link]"
  }
]
```

### 3. Generate Final HTML Drafts
Run the core generation script. This script handles:
- Authentic image fetching
- Surgical v4 watermark scrubbing (block ROI masking)
- CDN upload
- Formulation of minified HTML to prevent editor spacing issues.

```bash
python scripts/generate_wechat_html.py --input_json scratch/news_data.json --output_blue scratch/blue.html --output_green scratch/green.html
```

### 4. Deliver Outputs (Two-Stage Delivery)
Deliver the results in **two separate messages** to ensure clarity:
1. **Message 1**: Provide the **Blue Layout** HTML. Ask the user to reply "继续" or "next" for the Green layout.
2. **Message 2**: Provide the **Green Layout** HTML.

## Coze Import
To use this skill in Coze (扣子), simply upload the packaged ZIP file. The agent will then have access to the optimized Python scripts and layout templates defined in this repository.
