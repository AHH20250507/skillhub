import cv2
import easyocr
import requests
import numpy as np
import urllib3
import re
from bs4 import BeautifulSoup
import time
import json
import argparse
import os

urllib3.disable_warnings()

# Global reader to avoid re-initializing in every loop
_ocr_reader = None

def get_ocr_reader():
    global _ocr_reader
    if _ocr_reader is None:
        print("Initializing OCR Reader (this may take a moment)...")
        try:
            _ocr_reader = easyocr.Reader(['ch_sim', 'en'], gpu=False, verbose=False)
        except Exception as e:
            print(f"OCR Init Error: {e}")
    return _ocr_reader

def get_image_from_ithome(url):
    if not url: return None
    headers = {'User-Agent': 'Mozilla/5.0'}
    try:
        resp = requests.get(url, headers=headers, verify=False, timeout=15)
        resp.encoding = 'utf-8'
        soup = BeautifulSoup(resp.text, 'html.parser')
        
        # Priority 1: div#paragraph (most common)
        content_div = soup.find('div', id='paragraph')
        if content_div:
            img = content_div.find('img')
            if img:
                src = img.get('data-original') or img.get('src')
                if src: return src
        
        # Priority 2: img.lazy (slideshow/list articles)
        img = soup.find('img', class_='lazy')
        if img:
            src = img.get('data-original') or img.get('src')
            if src: return src

        # Priority 3: any image with 'newsuploadfiles' (the IT之家 CDN string)
        for img in soup.find_all('img'):
            src = img.get('data-original') or img.get('src') or ""
            if 'newsuploadfiles' in src:
                return src

        return None
    except:
        return None

def verify_url(url):
    if not url: return False
    if 'mmbiz' in url: return True 
    try:
        # Some CDNs block HEAD, use GET with small range
        r = requests.get(url, timeout=5, stream=True)
        return r.status_code == 200
    except:
        return False

def upload_to_freeimage(img_array, retries=3):
    """Primary hosting: FreeImage.host"""
    url = "https://freeimage.host/api/1/upload"
    _, buffer = cv2.imencode('.jpg', img_array, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    data = {"key": "6d207e02198a847aa98d0a2a901485a5", "action": "upload"}
    files = {"source": ("image.jpg", buffer.tobytes(), "image/jpeg")}
    
    for attempt in range(retries):
        try:
            response = requests.post(url, data=data, files=files, timeout=45)
            if response.status_code == 200:
                res_json = response.json()
                if res_json.get("status_code") == 200:
                    direct_url = res_json['image']['url']
                    print(f"Uploaded to FreeImage (Attempt {attempt+1}): {direct_url}")
                    return direct_url
            print(f"FreeImage failed (Attempt {attempt+1}): {response.text[:100]}")
        except Exception as e:
            print(f"FreeImage Upload error (Attempt {attempt+1}): {e}")
        time.sleep(2) # Small backoff
    return None

def upload_to_catbox(img_array):
    """Fallback: Catbox"""
    _, buffer = cv2.imencode('.jpg', img_array, [int(cv2.IMWRITE_JPEG_QUALITY), 95])
    try:
        r = requests.post("https://catbox.moe/user/api.php", 
                         data={"reqtype": "fileupload"}, 
                         files={"fileToUpload": ("image.jpg", buffer.tobytes(), "image/jpeg")}, 
                         timeout=45)
        if r.status_code == 200 and r.text.startswith('http'):
            url = r.text.strip()
            print(f"Uploaded to Catbox (Emergency Fallback): {url}")
            return url
    except Exception as e:
        print(f"Catbox Upload error: {e}")
    return None

def process_image(url):
    if not url: return None
    print(f"Processing: {url}")
    if '?x-bce-process' in url:
        url = url.split('?x-bce-process')[0]
        
    header_dl = {'User-Agent': 'Mozilla/5.0'}
    try:
        r = requests.get(url, headers=header_dl, verify=False, timeout=15)
        if r.status_code != 200: return None
    except:
        return None
        
    nparr = np.frombuffer(r.content, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    if img is None: return None
        
    height, width = img.shape[:2]
    reader = get_ocr_reader()
    mask = np.zeros((height, width), dtype=np.uint8)
    
    if reader:
        results = reader.readtext(img)
        watermark_found = False
        
        # IT之家 Watermark Keywords
        keywords = ["ithome", "it之家", "www.ithome.com", "之家", "ithome.com"]
        
        for (bbox, text, prob) in results:
            text_lower = text.lower().replace(" ", "").replace(".", "")
            is_match = any(k.replace(".", "") in text_lower for k in keywords)
            
            (tl, tr, br, bl) = bbox
            box_min_x, box_max_x = int(min(tl[0], bl[0])), int(max(tr[0], br[0]))
            box_min_y, box_max_y = int(min(tl[1], tr[1])), int(max(bl[1], br[1]))
            
            # Corner Heuristic removed as per user feedback to preserve non-IT之家 watermarks
            pass
            
            if is_match:
                watermark_found = True
                # ROI Block Masking (v4 Surgical)
                # Instead of individual fragments, we identify the full corner block.
                # IT之家 logos are predictable in size and placement.
                
                # Default watermark block size (approximate for IT之家 stack)
                blk_w = 260
                blk_h = 100
                
                # Expand to encompass the entire likely watermark region in this corner
                if box_max_x > width * 0.6 and box_max_y > height * 0.6:
                    # Bottom Right corner
                    roi_x1 = max(0, box_min_x - 30)
                    roi_y1 = max(0, box_min_y - 80) # Capture the logo above the text
                    roi_x2 = width
                    roi_y2 = height
                elif box_max_x > width * 0.6 and box_min_y < height * 0.4:
                    # Top Right corner
                    roi_x1 = max(0, box_min_x - 30)
                    roi_y1 = 0
                    roi_x2 = width
                    roi_y2 = min(height, box_max_y + 80)
                else:
                    # Fallback to local expansion if not in standard corners
                    roi_x1 = max(0, box_min_x - 30)
                    roi_x2 = min(width, box_max_x + 30)
                    roi_y1 = max(0, box_min_y - 80)
                    roi_y2 = min(height, box_max_y + 30)
                
                cv2.rectangle(mask, (int(roi_x1), int(roi_y1)), (int(roi_x2), int(roi_y2)), 255, -1)
        
            # v4 Surgical Dilation: circular and small
            kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
            mask = cv2.dilate(mask, kernel, iterations=1)
            # Use NS with minimal radius for local blending
            img = cv2.inpaint(img, mask, inpaintRadius=3, flags=cv2.INPAINT_NS)
            # Final slight blur on the edges of the inpainted area for "trace-free" blending
            # (only if mask is not too large)
            
    # Primary: FreeImage with Retries
    final_url = upload_to_freeimage(img, retries=5)
    
    if not final_url:
        print("FreeImage totally failed after 5 attempts. Trying Catbox as last resort...")
        final_url = upload_to_catbox(img)
    
    # Verify the URL is reachable (Optional GET check)
    if final_url and not verify_url(final_url):
        print(f"Warning: {final_url} verify failed. Retrying FreeImage one last time...")
        final_url = upload_to_freeimage(img, retries=2)
        
    return final_url
        
    return final_url

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input_json", required=True)
    parser.add_argument("--output_blue", required=True)
    parser.add_argument("--output_green", required=True)
    args = parser.parse_args()

    # Pre-warm OCR
    get_ocr_reader()

    with open(args.input_json, "r", encoding="utf-8") as f:
        data = json.load(f)

    dummy_img = "https://mmbiz.qpic.cn/mmbiz_png/iaw9nmmHthVdVciafviaiacviaiacviaiacviaiacviaiac/640?wx_fmt=png"
    
    print(f"Refining {len(data)} items for seamless results...")
    for i, item in enumerate(data):
        if "clean_image" in item and item["clean_image"] and item["clean_image"] != dummy_img and "iili.io" in item["clean_image"]:
            print(f"Skipping {i+1}, already has clean image: {item['clean_image']}")
            continue
            
        url = item.get("source_url")
        raw_img = get_image_from_ithome(url)
        clean_url = dummy_img
        if raw_img:
            res = process_image(raw_img)
            if res:
                clean_url = res
        data[i]['clean_image'] = clean_url

    # Exact Layout Templates
    # Exact Layout Templates
    # Master Templates (Fixed Gold Standard)
    blue_header = """<div class="rich_media_content js_underline_content autoTypeSetting24psection" id="js_content"><section data-role="outer" label="edit by 135editor"><section nodeleaf="" style="text-align:center;"><img alt="酷换机新头图.gif" class="rich_pages wxw-img" data-aistatus="1" src="https://mmbiz.qpic.cn/mmbiz_gif/iaw9nmmHthVcNNic7B4ibFg7Ribvt2o1pTCbfFlicw8No0Spt3ic3y9BDqzHdxZYF5zPNvB6DdZUMYU0T9Wkb0IroEhA/640?wx_fmt=gif" style="vertical-align: baseline;width: 100%;box-sizing:border-box;max-width:100% !important;"/></section>"""
    blue_item_template = """<section data-id="{SECTION_ID1}"><section style="margin: 10px auto;transform-style: preserve-3d;padding-bottom: 13px;box-sizing:border-box;"><section style="display: flex;justify-content: center;transform: translateZ(10px);-webkit-transform: translateZ(10px);-moz-transform: translateZ(10px);-o-transform: translateZ(10px);"><section style="background-color: #0c7ffd;display: flex;"><section style="flex-shrink: 0;"><section style="width: 0px;height: 1px;border-top: 10px solid #ffffff;border-right: 10px solid transparent;overflow: hidden;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section></section><section style="font-size: 16px;color: #ffffff;text-align: center;padding: 4px 5px;box-sizing:border-box;"><strong><span leaf="">{INDEX}</span></strong></section></section></section><section data-width="100%" style="width: 100%;border-top: 1px solid #0c7ffd;margin-top: -15px;height: 1px;overflow: hidden;max-width:100% !important;box-sizing:border-box;transform: translateZ(5px);-webkit-transform: translateZ(5px);-moz-transform: translateZ(5px);-o-transform: translateZ(5px);"><p><span leaf=""><br/></span></p></section><section style="display: flex;justify-content: flex-end;margin-top: -10px;padding-right: 15px;box-sizing:border-box;"><section style="font-size: 12px;color: #0c7ffd;background-color: #ffffff;padding-right: 5px;padding-left: 5px;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section></section></section></section><section data-id="{SECTION_ID2}" data-width="91%" style="margin-left: auto;margin-right: auto;width: 91%;flex: 0 0 91%;box-sizing:border-box;max-width:91% !important;"><section style="margin: 10px auto;"><section style="padding: 15px 10px;border-width: 1px;border-style: solid;border-color: #0c7ffd;box-sizing:border-box;"><section style="line-height: 1.75em;letter-spacing: 1.5px;font-size: 14px;color: #333333;background-image: initial;background-position: initial;background-size: initial;background-repeat: initial;background-attachment: initial;background-origin: initial;background-clip: initial;"><p style="line-height: normal;margin-top: -13px;"><strong style='caret-color: red;font-size: 19px;letter-spacing: 2px;line-height: 1.84em;font-family:微软雅黑, "Microsoft YaHei";'><span style="white-space-collapse: preserve;outline: 0px;color: #262626;line-height: 1.87em;"><span leaf="">{TITLE}</span></span></strong></p><p style="line-height: normal;margin-top: -13px;"><span leaf=""><br/></span></p><p style="line-height: normal;margin-top: -13px;"><span leaf=""><br/></span></p><p style="line-height: normal;margin-top: -13px;"><span leaf=""><br/></span></p><p style="line-height: normal;margin-top: -13px;"><span leaf=""><br/></span></p><p style="line-height: normal;margin-top: -13px;"><span leaf=""><br/></span></p><p><span style="text-align: center;caret-color: red;font-family:等线;"><span leaf="">{SUMMARY}</span></span></p><p><span leaf=""><br/></span></p><section nodeleaf=""><img class="rich_pages wxw-img" data-aistatus="1" src="{IMG_SRC}" style="vertical-align:baseline;width:100%;box-sizing:border-box;max-width:100% !important;"/></section></section></section><section style="display: flex;justify-content: flex-end;margin-top: -10px;padding-right: 15px;box-sizing:border-box;"><section style="font-size: 12px;color: #0c7ffd;background-color: #ffffff;padding-right: 5px;padding-left: 5px;box-sizing:border-box;"><span leaf="">三分钟检测 回收秒到账</span></section></section></section></section><p style="text-align:center;"><span leaf=""><br/></span></p>"""
    blue_footer = """<p style="text-align:center;"><span leaf=""><br/></span></p><section data-width="93%" style="margin-left: auto;margin-right: auto;width: 93%;flex: 0 0 93%;box-sizing:border-box;max-width:93% !important;"><section nodeleaf="" style="text-align:center;"><img alt="C端底图.jpg" class="rich_pages wxw-img" data-aistatus="1" src="https://mmbiz.qpic.cn/mmbiz_jpg/iaw9nmmHthVcNNic7B4ibFg7Ribvt2o1pTCbTNbOdgQ6GfBxjxiaHncPLnqDchF4CvYsibrPdiaMEiba1xgcxvkst08SKg/640?wx_fmt=jpeg" style="vertical-align: baseline;width: 100%;box-sizing:border-box;max-width:100% !important;"/></section></section></section></div>"""
    
    green_header = """<div class="rich_media_content js_underline_content autoTypeSetting24psection" id="js_content"><section data-role="outer" label="edit by 135editor"><section nodeleaf="" style="text-align:center;"><img class="rich_pages wxw-img" data-aistatus="1" src="https://mmbiz.qpic.cn/mmbiz_gif/lfic4S7GicgmD0Ot7hgOUpfofRwogPQoaTUSkOXicuTWeETNsjdZWSyQflaVfKqAo0zakN2K0ia7PBuxj8FfG4XHNQ/640?wx_fmt=gif" style="width:100%;vertical-align:baseline;box-sizing:border-box;max-width:100% !important;"/></section><section data-role="paragraph"><p><span leaf=""><br/></span></p></section>"""
    green_item_template = """<section data-id="{SECTION_ID1}"><section style="margin: 10px auto;display: flex;justify-content: center;"><section><section style="display: flex;justify-content: flex-end;margin: 0 0 -15px 0;"><section style="width: 15px;box-sizing:border-box;"><svg style="display: block;transform: rotateY(180deg);-webkit-transform: rotateY(180deg);-moz-transform: rotateY(180deg);-o-transform: rotateY(180deg);" viewbox="0 0 40.28 53.83" xmlns="http://www.w3.org/2000/svg"><path d="M408.52,452.1a51.12,51.12,0,0,1,36.38-50.87" style="fill:none;stroke:#fabb11;stroke-miterlimit:10;stroke-width:6px;" transform="translate(-405.5 -398.36)"></path></svg></section></section><section style="padding: 0px 8px;box-sizing: border-box;"><section style="font-size: 16px;color: #ffffff;background-color: #26b240;width: 35px;height: 35px;border-radius: 100%;text-align: center;line-height: 35px;box-sizing:border-box;"><strong><span leaf="">{INDEX1}</span></strong><strong title=""><span leaf="">{INDEX2}</span></strong></section></section><section style="display: flex;justify-content: flex-start;margin: -15px 0 0;"><section style="width: 15px;box-sizing:border-box;"><svg style="display: block;transform: rotateY(180deg);-webkit-transform: rotateY(180deg);-moz-transform: rotateY(180deg);-o-transform: rotateY(180deg);" viewbox="0 0 40.28 53.83" xmlns="http://www.w3.org/2000/svg"><path d="M442.75,398.46a51.12,51.12,0,0,1-36.38,50.87" style="fill:none;stroke:#fabb11;stroke-miterlimit:10;stroke-width:6px;" transform="translate(-405.5 -398.36)"></path></svg></section></section></section></section></section><section data-id="{SECTION_ID2}" data-width="94%" style="margin-left: auto;margin-right: auto;width: 94%;flex: 0 0 94%;max-width: 100% !important;box-sizing:border-box;"><section style="margin: 10px auto;"><section style="background-color: #26b240;display: flex;justify-content: flex-start;padding: 10px 0px;box-sizing: border-box;"><section style="display: flex;align-items: center;"><section style="width: 7px;height: 7px;background-color: #fabb11;border-radius: 100%;margin: 0px 0px 0px 10px;overflow: hidden;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section><section style="width: 7px;height: 7px;background-color: #89ddd0;border-radius: 100%;margin: 0px 0px 0px 10px;overflow: hidden;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section><section style="width: 7px;height: 7px;background-color: #fafffa;border-radius: 100%;margin: 0px 0px 0px 10px;overflow: hidden;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section></section></section><section style="background-color: #fafffa;"><section style="padding: 20px 15px 0px;box-sizing: border-box;"><p style="margin-top: -13px;line-height: 2em;"><strong style='caret-color: red;letter-spacing: 1.5px;font-size: 19px;line-height: 1.79em;overflow-wrap: break-word !important;'><span style="color: #262626;white-space: pre-wrap;overflow-wrap: break-word !important;"><span style='outline: 0px;max-width: 100%;visibility: visible;overflow-wrap: break-word !important;font-family:微软雅黑, "Microsoft YaHei";'><strong style="outline: 0px;max-width: 100%;visibility: visible;overflow-wrap: break-word !important;"><span leaf="">{TITLE}</span></strong></span></span></strong></p><p style="margin-top: -13px;line-height: 2em;"><span leaf=""><br/></span></p><p style="text-align:justify;line-height: 2em;"><span style='max-inline-size: 100%;margin: 0px;padding: 0px;box-sizing: border-box !important;overflow-wrap: break-word !important;cursor: text;color: #262626;text-align: justify;white-space: pre-wrap;line-height: 2em;font-size: 15px;letter-spacing: 1px;display: inline !important;font-family:微软雅黑, "Microsoft YaHei";'><span leaf="">{SUMMARY}</span></span></p><p style="text-align:center;line-height: 2em;"><span leaf=""><img src="{IMG_SRC}" style="width:100%;vertical-align:baseline;box-sizing:border-box;max-width:100% !important;"/></span></p></section><section style="display: flex;justify-content: flex-end;transform: translateZ(10px);-webkit-transform: translateZ(10px);-moz-transform: translateZ(10px);-o-transform: translateZ(10px);"><section><section style="width: 0px;height: 1px;border-right: 15px solid transparent;border-top: 15px solid #26b240;overflow: hidden;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section><section style="width: 0;height: 1px;border-left: 15px solid transparent;border-bottom: 15px solid #fafffa;margin: -15px 0 0;box-sizing:border-box;"><p><span leaf=""><br/></span></p></section></section></section></section></section></section><section data-role="paragraph"><p><span leaf=""><br/></span></p></section>"""
    green_footer = """<section data-role="paragraph"><section nodeleaf="" style="text-align:center;"><img class="rich_pages wxw-img" data-aistatus="1" src="https://mmbiz.qpic.cn/sz_mmbiz_jpg/lfic4S7GicgmCibzqTlnDyYSRq4Fy8iaVqxpKW0GQ9IZTuvqRwASdM7K3QSibWURDTssLy7Tkr9BeTDeZnXibp1qchzA/640?wx_fmt=jpeg" style="outline:0px;text-align:center;font-size:17px;letter-spacing:0.034em;width:100%;vertical-align:baseline;visibility:visible !important;box-sizing:border-box;max-width:100% !important;font-family:mp-quote, -apple-system-font, BlinkMacSystemFont, Arial, sans-serif;"/></section></section></section></div>"""
    green_footer = """<section data-role="paragraph"><section nodeleaf="" style="text-align:center;"><img class="rich_pages wxw-img" data-aistatus="1" src="https://mmbiz.qpic.cn/sz_mmbiz_jpg/lfic4S7GicgmCibzqTlnDyYSRq4Fy8iaVqxpKW0GQ9IZTuvqRwASdM7K3QSibWURDTssLy7Tkr9BeTDeZnXibp1qchzA/640?wx_fmt=jpeg" style="outline:0px;text-align:center;font-size:17px;letter-spacing:0.034em;width:100%;vertical-align:baseline;visibility:visible !important;box-sizing:border-box;max-width:100% !important;font-family:mp-quote, -apple-system-font, BlinkMacSystemFont, Arial, sans-serif;"/></section></section></section></div>"""

    blue_html = blue_header
    green_html = green_header

    for i, item in enumerate(data):
        index_str = str(i + 1).zfill(2)
        sid1 = str(120800 + i)
        sid2 = str(119700 + i)
        
        # Blue Item
        b_item = blue_item_template.replace("{INDEX}", index_str)
        b_item = b_item.replace("{TITLE}", item["title"])
        b_item = b_item.replace("{SUMMARY}", item["summary"])
        b_item = b_item.replace("{IMG_SRC}", item["clean_image"])
        b_item = b_item.replace("{SECTION_ID1}", sid1)
        b_item = b_item.replace("{SECTION_ID2}", sid2)
        blue_html += b_item

        # Green Item
        gsid1 = str(120300 + i)
        gsid2 = str(120200 + i)
        g_item = green_item_template.replace("{INDEX1}", index_str[0]).replace("{INDEX2}", index_str[1])
        g_item = g_item.replace("{TITLE}", item["title"])
        g_item = g_item.replace("{SUMMARY}", item["summary"])
        g_item = g_item.replace("{IMG_SRC}", item["clean_image"])
        g_item = g_item.replace("{SECTION_ID1}", gsid1)
        g_item = g_item.replace("{SECTION_ID2}", gsid2)
        green_html += g_item

    blue_html += blue_footer
    green_html += green_footer

    # Minify
    blue_html_min = re.sub(r'>\s+<', '><', re.sub(r'\n\s*', ' ', blue_html)).strip()
    green_html_min = re.sub(r'>\s+<', '><', re.sub(r'\n\s*', ' ', green_html)).strip()

    with open(args.output_blue, "w", encoding="utf-8") as f: f.write(blue_html_min)
    with open(args.output_green, "w", encoding="utf-8") as f: f.write(green_html_min)
    print(f"Data processed successfully.")

if __name__ == "__main__":
    main()
