# WeChat Article Layout Template

When formatting the curated mobile tech news, use the following HTML structure for each news item. Replace the placeholders (`{INDEX}`, `{TITLE}`, `{SUMMARY_CONTENT}`, `{IMAGE_URL}`) with the extracted data.

```html
<section style="margin-bottom: 30px; margin-top: 25px;">
  <section style="text-align: center; margin-bottom: -15px;">
    <span style="background-color: #0056b3; color: white; padding: 2px 10px; font-weight: bold; border-radius: 4px; font-size: 16px;">
      {INDEX}
    </span>
  </section>
  <section style="border: 1px solid #d0e3ff; padding: 25px 15px 15px; border-radius: 8px;">
    <section style="font-size: 15px; line-height: 1.6; color: #333; margin-bottom: 15px;">
      {SUMMARY_CONTENT}
    </section>
    <section style="text-align: center; margin: 15px 0;">
      <img src="{IMAGE_URL}" alt="Featured Image" style="max-width: 100%; border-radius: 4px; display: block; margin: 0 auto;" />
    </section>
  </section>
  <section style="text-align: right; margin-top: -10px; margin-right: 20px;">
    <span style="background-color: white; padding: 0 8px; color: #0056b3; font-size: 12px;">
      三分钟检测 回收秒到账
    </span>
  </section>
</section>
```

**Notes on variables:**
- `{INDEX}`: The sequential number of the item in the format "01", "02", "03", etc.
- `{SUMMARY_CONTENT}`: The 100-word summary of the article.
- `{IMAGE_URL}`: The direct URL to the image extracted from the original article.
