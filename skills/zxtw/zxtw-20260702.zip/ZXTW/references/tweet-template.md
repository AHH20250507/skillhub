# WeChat Tweet Style Layout Template

When formatting the curated mobile tech news using the secondary tweet layout, use the following HTML structure for each news item. Replaces the placeholders (`{INDEX}`, `{TITLE}`, `{SUMMARY_CONTENT}`, `{IMAGE_URL}`) with the extracted data.

```html
<section style="margin: 20px auto; max-width: 100%; box-sizing: border-box; font-family: 'Microsoft YaHei', sans-serif;">
  <section style="display: flex; justify-content: center; margin-bottom: -18px; position: relative; z-index: 1;">
    <section style="font-size: 16px; color: #ffffff; background-color: #26b240; width: 35px; height: 35px; border-radius: 100%; text-align: center; line-height: 35px; box-sizing: border-box; border: 3px solid #ffffff; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <strong>{INDEX}</strong>
    </section>
  </section>
  <section style="border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 12px rgba(0,0,0,0.08);">
    <section style="background-color: #26b240; display: flex; justify-content: flex-start; padding: 10px 0px; box-sizing: border-box;">
      <section style="display: flex; align-items: center;">
        <section style="width: 7px; height: 7px; background-color: #fabb11; border-radius: 100%; margin: 0px 0px 0px 10px;"></section>
        <section style="width: 7px; height: 7px; background-color: #89ddd0; border-radius: 100%; margin: 0px 0px 0px 10px;"></section>
        <section style="width: 7px; height: 7px; background-color: #fafffa; border-radius: 100%; margin: 0px 0px 0px 10px;"></section>
      </section>
    </section>
    <section style="background-color: #fafffa; padding: 20px 15px; box-sizing: border-box;">
      <p style="color: #3e3e3e; font-size: 15px; line-height: 1.8; text-align: justify; margin-bottom: 15px;">
        {SUMMARY_CONTENT}
      </p>
      <section style="text-align: center; margin-top: 10px;">
        <img src="{IMAGE_URL}" alt="article image" style="max-width: 100%; height: auto; border-radius: 4px; display: block; margin: 0 auto; box-shadow: 0 2px 6px rgba(0,0,0,0.1);">
      </section>
    </section>
  </section>
</section>
```

**Notes on variables:**
- `{INDEX}`: The sequential number of the item in the format "01", "02", "03", etc.
- `{SUMMARY_CONTENT}`: The 100-word summary of the article.
- `{IMAGE_URL}`: The direct URL to the image extracted from the original article.
